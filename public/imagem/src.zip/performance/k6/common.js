import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE_URL = (__ENV.BASE_URL || 'http://localhost:8080').replace(/\/$/, '');
const TOKEN = __ENV.TOKEN;
const TERMINAL = __ENV.TERMINAL;
const ENDPOINT = (__ENV.ENDPOINT || 'pf').toLowerCase();
const THINK_TIME = Number(__ENV.THINK_TIME || 0);

if (!TOKEN) throw new Error('Informe TOKEN: -e TOKEN=...');
if (!TERMINAL) throw new Error('Informe TERMINAL: -e TERMINAL=...');
if (!['pf', 'pj'].includes(ENDPOINT)) {
  throw new Error('ENDPOINT deve ser pf ou pj');
}

const paths = {
  pf: '/v1/analise-renda-pf',
  pj: '/v1/analise-faturamento-pj',
};

const payloads = {
  pf: {
    controle: { centroDeCusto: __ENV.CENTRO_CUSTO || 'CC001', club: __ENV.CLUB || 'CLUB001' },
    tipoPessoa: 'PF',
    cpf: __ENV.CPF || '52998224725',
    valorRendaMensalDeclarada: Number(__ENV.VALOR_RENDA || 5500.00),
  },
  pj: {
    controle: { centroDeCusto: __ENV.CENTRO_CUSTO || 'CC001', club: __ENV.CLUB || 'CLUB001' },
    cnpj: __ENV.CNPJ || '11222333000181',
    periodicidade: Number(__ENV.PERIODICIDADE || 4),
    anoReferencia: Number(__ENV.ANO_REFERENCIA || 2024),
    valorFaturamentoDeclarado: Number(__ENV.VALOR_FATURAMENTO || 100000.00),
  },
};

// Gera um UUID v4 novo para CADA requisição, evitando colisões entre VUs/iterações.
function newCorrelationId() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = Math.floor(Math.random() * 16);
    const v = c === 'x' ? r : ((r & 0x3) | 0x8);
    return v.toString(16);
  });
}

export default function () {
  const correlationId = newCorrelationId();
  const url = `${BASE_URL}${paths[ENDPOINT]}`;
  const headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Authorization': TOKEN.startsWith('Bearer ') ? TOKEN : `Bearer ${TOKEN}`,
    'terminal': TERMINAL,
    'correlation-Id': correlationId,
  };

  const response = http.post(url, JSON.stringify(payloads[ENDPOINT]), {
    headers,
    tags: { endpoint: ENDPOINT },
    timeout: __ENV.REQUEST_TIMEOUT || '60s',
  });

  check(response, {
    'HTTP status 2xx': (r) => r.status >= 200 && r.status < 300,
    'resposta não vazia': (r) => r.body !== null && r.body.length > 0,
  });

  if (response.status >= 400) {
    console.error(`Falha status=${response.status} correlationId=${correlationId} body=${response.body}`);
  }

  if (THINK_TIME > 0) sleep(THINK_TIME);
}

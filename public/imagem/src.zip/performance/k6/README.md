1. Instalar o k6
O k6 é a ferramenta que vai simular vários usuários acessando simultaneamente seu serviço.

Abra o PowerShell e execute:
winget install k6 --source winget

Depois, feche e abra novamente o PowerShell.

Verifique a instalação:
k6 version

Se aparecer a versão instalada, está pronto.

Documentação: Instalação do k6
2. Extrair o projeto
Baixe o projeto atualizado:

processamento-service-java17-com-testes-carga-stress.zip

Extraia o ZIP.

Os arquivos estarão nesta estrutura:
processamento-service-java17/
│
├── src/
├── pom.xml
├── README.md
│
└── performance/
    └── k6/
        ├── common.js
        ├── load-test.js
        ├── stress-test.js
        └── README.md

3. Iniciar o processamento-service
Antes de executar os testes, inicie sua aplicação Java.

Pelo terminal, na raiz do projeto:
mvn spring-boot:run

Ou execute pelo Eclipse.

Confirme que a aplicação está funcionando.

Exemplo:
http://localhost:8080

Utilize a porta configurada no seu projeto.
4. Executar teste de carga
Abra outro PowerShell e entre na pasta:
cd C:\projetos\processamento-service-java17\performance\k6

Crie a pasta de relatórios:
New-Item -ItemType Directory -Force reports

Configure os parâmetros:
$env:BASE_URL="http://localhost:8080"
$env:TOKEN="SEU_TOKEN_JWT"
$env:TERMINAL="SEU_TERMINAL"
$env:ENDPOINT="pf"

Execute:
k6 run load-test.js
package br.com.bradesco.srv.hex.application.service;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

import java.time.Instant;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

import br.com.bradesco.srv.hex.application.model.Processamento;
import br.com.bradesco.srv.hex.application.port.out.mongo.ProcessamentoRepositoryPort;

class RegistrarStepServiceImplTest {

    private final ProcessamentoRepositoryPort repositorio = mock(ProcessamentoRepositoryPort.class);

    private final RegistrarStepServiceImpl servico = new RegistrarStepServiceImpl(repositorio);

    private static Processamento.StepProcessamento step(String nome) {
        return new Processamento.StepProcessamento(nome, "PROCESSANDO", Instant.now(), "mensagem");
    }

    @Test
    void registraEtapaNoRepositorio() {
        var etapa = step("STEP1");

        servico.executar("id-1", "correlacao-1", etapa);

        verify(repositorio).registrarStep("id-1", "correlacao-1", etapa);
    }

    @ParameterizedTest
    @NullAndEmptySource
    @ValueSource(strings = {" "})
    void rejeitaIdProcessamentoAusente(String idProcessamento) {
        assertThatThrownBy(() -> servico.executar(idProcessamento, "correlacao-1", step("STEP1")))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("idProcessamento obrigatório");

        verifyNoInteractions(repositorio);
    }

    @ParameterizedTest
    @NullAndEmptySource
    @ValueSource(strings = {" "})
    void rejeitaCorrelationIdAusente(String correlationId) {
        assertThatThrownBy(() -> servico.executar("id-1", correlationId, step("STEP1")))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("correlationId obrigatório");

        verifyNoInteractions(repositorio);
    }

    @Test
    void rejeitaEtapaNula() {
        assertThatThrownBy(() -> servico.executar("id-1", "correlacao-1", null))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("Step e nome do step são obrigatórios");

        verifyNoInteractions(repositorio);
    }

    @ParameterizedTest
    @NullAndEmptySource
    @ValueSource(strings = {" "})
    void rejeitaEtapaSemNome(String nome) {
        assertThatThrownBy(() -> servico.executar("id-1", "correlacao-1", step(nome)))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("Step e nome do step são obrigatórios");

        verifyNoInteractions(repositorio);
    }
}

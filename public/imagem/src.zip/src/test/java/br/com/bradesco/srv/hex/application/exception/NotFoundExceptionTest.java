package br.com.bradesco.srv.hex.application.exception;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import br.com.bradesco.srv.hex.application.exception.InfraErrorCode;
import br.com.bradesco.srv.hex.application.exception.NotFoundException;

import static org.assertj.core.api.Assertions.assertThat;

@DisplayName("NotFoundException Unit Tests - Target Constructors Only")
class NotFoundExceptionTest {

    @Nested
    @DisplayName("Constructor: NotFoundException(String, String, String, Throwable)")
    class ConstructorWithAllParameters {

        @Test
        @DisplayName("Should create exception with all parameters")
        void shouldCreateExceptionWithAllParameters() {
            // Given
            String origin = "UserService";
            String method = "findUserById";
            String message = "User not found with id: 123";
            Throwable cause = new RuntimeException("Database connection failed");

            // When
            NotFoundException exception = new NotFoundException(origin, method, message, cause);

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).contains(origin);
            assertThat(exception.getErrorCode()).contains(method);
            assertThat(exception.getErrorMessage()).isEqualTo(message);
            assertThat(exception.getCause()).isEqualTo(cause);
            assertThat(exception.getMessage()).isEqualTo(message);
        }

        @Test
        @DisplayName("Should use default message when message is null")
        void shouldUseDefaultMessageWhenMessageIsNull() {
            // Given
            String origin = "AccountService";
            String method = "getAccount";
            String message = null;
            Throwable cause = new IllegalStateException("Invalid state");

            // When
            NotFoundException exception = new NotFoundException(origin, method, message, cause);

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).contains(origin);
            assertThat(exception.getErrorCode()).contains(method);
            assertThat(exception.getErrorMessage()).isEqualTo(InfraErrorCode.NOT_FOUND.getMessage());
            assertThat(exception.getMessage()).isEqualTo(InfraErrorCode.NOT_FOUND.getMessage());
            assertThat(exception.getCause()).isEqualTo(cause);
        }

        @Test
        @DisplayName("Should handle null method parameter")
        void shouldHandleNullMethod() {
            // Given
            String origin = "DepositService";
            String method = null;
            String message = "Deposit not found";
            Throwable cause = new NullPointerException("Null deposit ID");

            // When
            NotFoundException exception = new NotFoundException(origin, method, message, cause);

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).contains(origin);
            assertThat(exception.getErrorMessage()).isEqualTo(message);
            assertThat(exception.getCause()).isEqualTo(cause);
        }

        @Test
        @DisplayName("Should handle null cause parameter")
        void shouldHandleNullCause() {
            // Given
            String origin = "WithdrawalService";
            String method = "findWithdrawal";
            String message = "Withdrawal not found";
            Throwable cause = null;

            // When
            NotFoundException exception = new NotFoundException(origin, method, message, cause);

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).contains(origin);
            assertThat(exception.getErrorCode()).contains(method);
            assertThat(exception.getErrorMessage()).isEqualTo(message);
            assertThat(exception.getCause()).isNull();
        }

        @Test
        @DisplayName("Should handle both method and cause as null")
        void shouldHandleBothMethodAndCauseAsNull() {
            // Given
            String origin = "TransactionService";
            String method = null;
            String message = "Transaction not found";
            Throwable cause = null;

            // When
            NotFoundException exception = new NotFoundException(origin, method, message, cause);

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).contains(origin);
            assertThat(exception.getErrorMessage()).isEqualTo(message);
            assertThat(exception.getCause()).isNull();
        }

        @Test
        @DisplayName("Should handle all nullable parameters as null")
        void shouldHandleAllNullableParametersAsNull() {
            // Given
            String origin = "PaymentService";
            String method = null;
            String message = null;
            Throwable cause = null;

            // When
            NotFoundException exception = new NotFoundException(origin, method, message, cause);

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).contains(origin);
            assertThat(exception.getErrorMessage()).isEqualTo(InfraErrorCode.NOT_FOUND.getMessage());
            assertThat(exception.getCause()).isNull();
        }

        @Test
        @DisplayName("Should format error code correctly with origin and method")
        void shouldFormatErrorCodeCorrectlyWithOriginAndMethod() {
            // Given
            String origin = "CustomerService";
            String method = "findCustomer";
            String message = "Customer not found";
            Throwable cause = new Exception("Database error");

            // When
            NotFoundException exception = new NotFoundException(origin, method, message, cause);

            // Then
            assertThat(exception.getErrorCode()).isNotEmpty();
            assertThat(exception.getErrorCode()).contains(origin);
            assertThat(exception.getErrorCode()).contains(method);
            assertThat(exception.getErrorCode()).contains(InfraErrorCode.NOT_FOUND.getCode());
        }

        @Test
        @DisplayName("Should handle empty message string")
        void shouldHandleEmptyMessageString() {
            // Given
            String origin = "ProductService";
            String method = "getProduct";
            String message = "";
            Throwable cause = new RuntimeException("Error");

            // When
            NotFoundException exception = new NotFoundException(origin, method, message, cause);

            // Then
            assertThat(exception.getErrorMessage()).isEmpty();
            assertThat(exception.getMessage()).isEmpty();
        }

        @Test
        @DisplayName("Should handle whitespace message string")
        void shouldHandleWhitespaceMessageString() {
            // Given
            String origin = "OrderService";
            String method = "findOrder";
            String message = "   ";
            Throwable cause = null;

            // When
            NotFoundException exception = new NotFoundException(origin, method, message, cause);

            // Then
            assertThat(exception.getErrorMessage()).isEqualTo("   ");
        }

        @Test
        @DisplayName("Should handle long origin and method names")
        void shouldHandleLongOriginAndMethodNames() {
            // Given
            String origin = "Very".repeat(100) + "LongOriginName";
            String method = "veryLongMethodNameWith".repeat(50) + "Parameters";
            String message = "Resource not found";
            Throwable cause = new Exception("Cause");

            // When
            NotFoundException exception = new NotFoundException(origin, method, message, cause);

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).isNotEmpty();
            assertThat(exception.getErrorMessage()).isEqualTo(message);
        }

        @Test
        @DisplayName("Should handle special characters in parameters")
        void shouldHandleSpecialCharactersInParameters() {
            // Given
            String origin = "Service@#$%";
            String method = "method_with-special.chars";
            String message = "Error: Resource @#$%^&*() not found!";
            Throwable cause = new RuntimeException("Cause with special chars: <>?");

            // When
            NotFoundException exception = new NotFoundException(origin, method, message, cause);

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorMessage()).isEqualTo(message);
            assertThat(exception.getCause().getMessage()).contains("special chars");
        }

        @Test
        @DisplayName("Should handle Unicode characters in message")
        void shouldHandleUnicodeCharactersInMessage() {
            // Given
            String origin = "UsuárioService";
            String method = "buscarUsuário";
            String message = "Usuário não encontrado: ç, á, é, í, ó, ú, ã, õ, ñ, ü";
            Throwable cause = null;

            // When
            NotFoundException exception = new NotFoundException(origin, method, message, cause);

            // Then
            assertThat(exception.getErrorMessage()).isEqualTo(message);
        }

        @Test
        @DisplayName("Should preserve cause chain")
        void shouldPreserveCauseChain() {
            // Given
            String origin = "ChainService";
            String method = "processChain";
            String message = "Chain processing failed";
            Throwable rootCause = new Exception("Root cause");
            Throwable intermediateCause = new RuntimeException("Intermediate", rootCause);

            // When
            NotFoundException exception = new NotFoundException(origin, method, message, intermediateCause);

            // Then
            assertThat(exception.getCause()).isEqualTo(intermediateCause);
            assertThat(exception.getCause().getCause()).isEqualTo(rootCause);
        }

        @Test
        @DisplayName("Should handle different exception types as cause")
        void shouldHandleDifferentExceptionTypesAsCause() {
            // Given
            String origin = "ExceptionService";
            String method = "test";

            // When & Then - IllegalArgumentException
            IllegalArgumentException iae = new IllegalArgumentException("Invalid argument");
            NotFoundException ex1 = new NotFoundException(origin, method, "Error", iae);
            assertThat(ex1.getCause()).isInstanceOf(IllegalArgumentException.class);

            // When & Then - NullPointerException
            NullPointerException npe = new NullPointerException("Null pointer");
            NotFoundException ex2 = new NotFoundException(origin, method, "Error", npe);
            assertThat(ex2.getCause()).isInstanceOf(NullPointerException.class);

            // When & Then - IllegalStateException
            IllegalStateException ise = new IllegalStateException("Invalid state");
            NotFoundException ex3 = new NotFoundException(origin, method, "Error", ise);
            assertThat(ex3.getCause()).isInstanceOf(IllegalStateException.class);
        }

        @Test
        @DisplayName("Should create valid exception for typical use case")
        void shouldCreateValidExceptionForTypicalUseCase() {
            // Given
            String origin = "AccountRepository";
            String method = "findById";
            String message = "Account with ID 12345 not found in database";
            Throwable cause = new java.sql.SQLException("No row with the given identifier");

            // When
            NotFoundException exception = new NotFoundException(origin, method, message, cause);

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).contains("AccountRepository");
            assertThat(exception.getErrorCode()).contains("findById");
            assertThat(exception.getErrorMessage()).contains("Account with ID 12345");
            assertThat(exception.getCause()).isInstanceOf(java.sql.SQLException.class);
        }
    }

    @Nested
    @DisplayName("Constructor: NotFoundException(Throwable)")
    class ConstructorWithCauseOnly {

        @Test
        @DisplayName("Should create exception with cause only")
        void shouldCreateExceptionWithCauseOnly() {
            // Given
            Throwable cause = new RuntimeException("Database connection failed");

            // When
            NotFoundException exception = new NotFoundException(cause);

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).isEqualTo(InfraErrorCode.NOT_FOUND.getCode());
            assertThat(exception.getErrorMessage()).isEqualTo(InfraErrorCode.NOT_FOUND.getMessage());
            assertThat(exception.getCause()).isEqualTo(cause);
            assertThat(exception.getMessage()).isEqualTo(InfraErrorCode.NOT_FOUND.getMessage());
        }

        @Test
        @DisplayName("Should use NOT_FOUND error code and message")
        void shouldUseNotFoundErrorCodeAndMessage() {
            // Given
            Throwable cause = new Exception("Some error");

            // When
            NotFoundException exception = new NotFoundException(cause);

            // Then
            assertThat(exception.getErrorCode()).isEqualTo("NOT_FOUND");
            assertThat(exception.getErrorMessage()).isEqualTo("Recurso nao encontrado");
        }

        @Test
        @DisplayName("Should handle RuntimeException as cause")
        void shouldHandleRuntimeExceptionAsCause() {
            // Given
            RuntimeException cause = new RuntimeException("Runtime error occurred");

            // When
            NotFoundException exception = new NotFoundException(cause);

            // Then
            assertThat(exception.getCause()).isInstanceOf(RuntimeException.class);
            assertThat(exception.getCause().getMessage()).isEqualTo("Runtime error occurred");
        }

        @Test
        @DisplayName("Should handle IllegalArgumentException as cause")
        void shouldHandleIllegalArgumentExceptionAsCause() {
            // Given
            IllegalArgumentException cause = new IllegalArgumentException("Invalid argument provided");

            // When
            NotFoundException exception = new NotFoundException(cause);

            // Then
            assertThat(exception.getCause()).isInstanceOf(IllegalArgumentException.class);
            assertThat(exception.getCause().getMessage()).contains("Invalid argument");
        }

        @Test
        @DisplayName("Should handle NullPointerException as cause")
        void shouldHandleNullPointerExceptionAsCause() {
            // Given
            NullPointerException cause = new NullPointerException("Null value encountered");

            // When
            NotFoundException exception = new NotFoundException(cause);

            // Then
            assertThat(exception.getCause()).isInstanceOf(NullPointerException.class);
            assertThat(exception.getCause().getMessage()).isEqualTo("Null value encountered");
        }

        @Test
        @DisplayName("Should handle SQLException as cause")
        void shouldHandleSQLExceptionAsCause() {
            // Given
            java.sql.SQLException cause = new java.sql.SQLException("No data found in database");

            // When
            NotFoundException exception = new NotFoundException(cause);

            // Then
            assertThat(exception.getCause()).isInstanceOf(java.sql.SQLException.class);
            assertThat(exception.getCause().getMessage()).contains("No data found");
        }

        @Test
        @DisplayName("Should handle IOException as cause")
        void shouldHandleIOExceptionAsCause() {
            // Given
            java.io.IOException cause = new java.io.IOException("File not found");

            // When
            NotFoundException exception = new NotFoundException(cause);

            // Then
            assertThat(exception.getCause()).isInstanceOf(java.io.IOException.class);
            assertThat(exception.getCause().getMessage()).isEqualTo("File not found");
        }

        @Test
        @DisplayName("Should preserve cause chain with multiple levels")
        void shouldPreserveCauseChainWithMultipleLevels() {
            // Given
            Throwable rootCause = new IllegalStateException("Root cause");
            Throwable intermediateCause = new RuntimeException("Intermediate cause", rootCause);
            Throwable topCause = new Exception("Top level cause", intermediateCause);

            // When
            NotFoundException exception = new NotFoundException(topCause);

            // Then
            assertThat(exception.getCause()).isEqualTo(topCause);
            assertThat(exception.getCause().getCause()).isEqualTo(intermediateCause);
            assertThat(exception.getCause().getCause().getCause()).isEqualTo(rootCause);
        }

        @Test
        @DisplayName("Should handle cause with null message")
        void shouldHandleCauseWithNullMessage() {
            // Given
            Throwable cause = new RuntimeException((String) null);

            // When
            NotFoundException exception = new NotFoundException(cause);

            // Then
            assertThat(exception.getCause()).isNotNull();
            assertThat(exception.getCause().getMessage()).isNull();
            assertThat(exception.getErrorMessage()).isEqualTo(InfraErrorCode.NOT_FOUND.getMessage());
        }

        @Test
        @DisplayName("Should handle cause with empty message")
        void shouldHandleCauseWithEmptyMessage() {
            // Given
            Throwable cause = new RuntimeException("");

            // When
            NotFoundException exception = new NotFoundException(cause);

            // Then
            assertThat(exception.getCause()).isNotNull();
            assertThat(exception.getCause().getMessage()).isEmpty();
        }

        @Test
        @DisplayName("Should handle cause with very long message")
        void shouldHandleCauseWithVeryLongMessage() {
            // Given
            String longMessage = "This is a very long error message. ".repeat(100);
            Throwable cause = new Exception(longMessage);

            // When
            NotFoundException exception = new NotFoundException(cause);

            // Then
            assertThat(exception.getCause().getMessage()).hasSize(longMessage.length());
            assertThat(exception.getCause().getMessage()).contains("This is a very long error message.");
        }

        @Test
        @DisplayName("Should handle cause with special characters in message")
        void shouldHandleCauseWithSpecialCharactersInMessage() {
            // Given
            Throwable cause = new Exception("Error: @#$%^&*()_+-=[]{}|;:',.<>?/`~");

            // When
            NotFoundException exception = new NotFoundException(cause);

            // Then
            assertThat(exception.getCause().getMessage()).contains("@#$%^&*()");
        }

        @Test
        @DisplayName("Should handle cause with Unicode characters in message")
        void shouldHandleCauseWithUnicodeCharactersInMessage() {
            // Given
            Throwable cause = new Exception("Erro: ç, á, é, í, ó, ú, ã, õ, ñ, ü, €, £, ¥");

            // When
            NotFoundException exception = new NotFoundException(cause);

            // Then
            assertThat(exception.getCause().getMessage()).contains("ç, á, é, í, ó, ú");
        }

        @Test
        @DisplayName("Should be throwable and catchable")
        void shouldBeThrowableAndCatchable() {
            // Given
            Throwable cause = new RuntimeException("Original error");

            // When/Then
            try {
                throw new NotFoundException(cause);
            } catch (NotFoundException e) {
                assertThat(e.getCause()).isEqualTo(cause);
                assertThat(e.getErrorCode()).isEqualTo(InfraErrorCode.NOT_FOUND.getCode());
                assertThat(e.getErrorMessage()).isEqualTo(InfraErrorCode.NOT_FOUND.getMessage());
            }
        }

        @Test
        @DisplayName("Should preserve stack trace")
        void shouldPreserveStackTrace() {
            // Given
            Throwable cause = new Exception("Cause exception");

            // When
            NotFoundException exception = new NotFoundException(cause);

            // Then
            assertThat(exception.getStackTrace()).isNotNull();
            assertThat(exception.getStackTrace()).isNotEmpty();
        }

        @Test
        @DisplayName("Should be instance of expected exception hierarchy")
        void shouldBeInstanceOfExpectedExceptionHierarchy() {
            // Given
            Throwable cause = new RuntimeException("Error");

            // When
            NotFoundException exception = new NotFoundException(cause);

            // Then
            assertThat(exception)
                .isInstanceOf(RuntimeException.class)
                .isInstanceOf(Exception.class)
                .isInstanceOf(Throwable.class);
        }

        @Test
        @DisplayName("Should handle typical repository not found scenario")
        void shouldHandleTypicalRepositoryNotFoundScenario() {
            // Given
            java.sql.SQLException sqlCause = new java.sql.SQLException(
                "No row with the given identifier exists: [User#12345]"
            );

            // When
            NotFoundException exception = new NotFoundException(sqlCause);

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).isEqualTo("NOT_FOUND");
            assertThat(exception.getErrorMessage()).isEqualTo("Recurso nao encontrado");
            assertThat(exception.getCause()).isInstanceOf(java.sql.SQLException.class);
            assertThat(exception.getCause().getMessage()).contains("No row with the given identifier");
        }
    }

    @Nested
    @DisplayName("Serialization Tests")
    class SerializationTests {

        @Test
        @DisplayName("Should have serialVersionUID defined")
        void shouldHaveSerialVersionUIDDefined() {
            // Given
            Throwable cause = new Exception("Test");

            // When
            NotFoundException exception = new NotFoundException(cause);

            // Then
            assertThat(exception).isInstanceOf(java.io.Serializable.class);
        }

        @Test
        @DisplayName("Should be serializable with all parameters constructor")
        void shouldBeSerializableWithAllParametersConstructor() {
            // Given
            NotFoundException exception = new NotFoundException(
                "Service",
                "method",
                "message",
                new RuntimeException("cause")
            );

            // Then
            assertThat(exception).isInstanceOf(java.io.Serializable.class);
        }

        @Test
        @DisplayName("Should be serializable with cause only constructor")
        void shouldBeSerializableWithCauseOnlyConstructor() {
            // Given
            NotFoundException exception = new NotFoundException(new Exception("cause"));

            // Then
            assertThat(exception).isInstanceOf(java.io.Serializable.class);
        }
    }
}

package br.com.bradesco.srv.hex.util.enumerator;

import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

class PeriodicidadeTest {
    @Test void codigoEMesesPorPeriodicidade() {
        assertEquals(4, Periodicidade.MENSAL.codigo());
        assertEquals(12, Periodicidade.MENSAL.meses());
        assertEquals(5, Periodicidade.TRIMESTRAL.codigo());
        assertEquals(4, Periodicidade.TRIMESTRAL.meses());
        assertEquals(7, Periodicidade.ANUAL.codigo());
        assertEquals(1, Periodicidade.ANUAL.meses());
    }

    @Test void converteCodigosValidos() {
        assertEquals(Periodicidade.MENSAL, Periodicidade.fromCodigo(4));
        assertEquals(Periodicidade.TRIMESTRAL, Periodicidade.fromCodigo(5));
        assertEquals(Periodicidade.ANUAL, Periodicidade.fromCodigo(7));
    }

    @Test
    void rejeitaCodigoInvalidoInclusiveNulo() {

        assertThrows(
                IllegalArgumentException.class,
                () -> Periodicidade.fromCodigo(8));

        assertThrows(
                NullPointerException.class,
                () -> Periodicidade.fromCodigo(null));
    }
    
    
    @Test void anualizaConformePeriodicidade() {
        assertEquals(new BigDecimal("120"), Periodicidade.calcularRendaAnual(
                Periodicidade.MENSAL, BigDecimal.TEN));
        assertEquals(new BigDecimal("40"), Periodicidade.calcularRendaAnual(
                Periodicidade.TRIMESTRAL, BigDecimal.TEN));
        assertEquals(new BigDecimal("10"), Periodicidade.calcularRendaAnual(
                Periodicidade.ANUAL, BigDecimal.TEN));
    }
}

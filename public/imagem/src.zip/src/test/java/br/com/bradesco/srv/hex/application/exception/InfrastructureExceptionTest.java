package br.com.bradesco.srv.hex.application.exception;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import br.com.bradesco.srv.hex.application.exception.InfraErrorCode;
import br.com.bradesco.srv.hex.application.exception.InfrastructureException;

import static org.assertj.core.api.Assertions.assertThat;

@DisplayName("InfrastructureException Unit Tests")
class InfrastructureExceptionTest {

    @Nested
    @DisplayName("Constructor: InfrastructureException(String, String, Throwable, Object[])")
    class ConstructorWithAllStringParameters {

        @Test
        @DisplayName("Should create exception with all string parameters")
        void shouldCreateExceptionWithAllStringParameters() {
            // Given
            String errorCode = "INFRA_ERROR_001";
            String errorMessage = "Infrastructure error occurred";
            Throwable cause = new RuntimeException("Root cause");
            Object[] additionalDetails = {"detail1", "detail2", 123};

            // When
            InfrastructureException exception = new InfrastructureException(
                errorCode,
                errorMessage,
                cause,
                additionalDetails
            );

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).isEqualTo(errorCode);
            assertThat(exception.getErrorMessage()).isEqualTo(errorMessage);
            assertThat(exception.getCause()).isEqualTo(cause);
            assertThat(exception.getAdditionalDetails()).isEqualTo(additionalDetails);
            assertThat(exception.getMessage()).isEqualTo(errorMessage);
        }

        @Test
        @DisplayName("Should handle null cause")
        void shouldHandleNullCause() {
            // Given
            String errorCode = "INFRA_ERROR_002";
            String errorMessage = "Error message";
            Throwable cause = null;
            Object[] additionalDetails = {"detail"};

            // When
            InfrastructureException exception = new InfrastructureException(
                errorCode,
                errorMessage,
                cause,
                additionalDetails
            );

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getCause()).isNull();
            assertThat(exception.getErrorCode()).isEqualTo(errorCode);
        }

        @Test
        @DisplayName("Should handle null additional details")
        void shouldHandleNullAdditionalDetails() {
            // Given
            String errorCode = "INFRA_ERROR_003";
            String errorMessage = "Error message";
            Throwable cause = new IllegalStateException("State error");
            Object[] additionalDetails = null;

            // When
            InfrastructureException exception = new InfrastructureException(
                errorCode,
                errorMessage,
                cause,
                additionalDetails
            );

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getAdditionalDetails()).isEmpty();
            assertThat(exception.getCause()).isEqualTo(cause);
        }

        @Test
        @DisplayName("Should handle empty additional details")
        void shouldHandleEmptyAdditionalDetails() {
            // Given
            String errorCode = "INFRA_ERROR_004";
            String errorMessage = "Error message";
            Throwable cause = new Exception("Cause");
            Object[] additionalDetails = {};

            // When
            InfrastructureException exception = new InfrastructureException(
                errorCode,
                errorMessage,
                cause,
                additionalDetails
            );

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getAdditionalDetails()).isEmpty();
        }
    }

    @Nested
    @DisplayName("Constructor: InfrastructureException(String, String, Object[])")
    class ConstructorWithStringAndDetails {

        @Test
        @DisplayName("Should create exception with error code, message and details")
        void shouldCreateExceptionWithCodeMessageAndDetails() {
            // Given
            String errorCode = "INFRA_ERROR_005";
            String errorMessage = "Database connection failed";
            Object[] additionalDetails = {"host", "port", 5432};

            // When
            InfrastructureException exception = new InfrastructureException(
                errorCode,
                errorMessage,
                additionalDetails
            );

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).isEqualTo(errorCode);
            assertThat(exception.getErrorMessage()).isEqualTo(errorMessage);
            assertThat(exception.getCause()).isNull();
            assertThat(exception.getAdditionalDetails()).isEqualTo(additionalDetails);
        }

        @Test
        @DisplayName("Should handle null additional details")
        void shouldHandleNullAdditionalDetails() {
            // Given
            String errorCode = "INFRA_ERROR_006";
            String errorMessage = "Error message";
            Object[] additionalDetails = null;

            // When
            InfrastructureException exception = new InfrastructureException(
                errorCode,
                errorMessage,
                additionalDetails
            );

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getAdditionalDetails()).isEmpty();
        }

        @Test
        @DisplayName("Should handle complex additional details")
        void shouldHandleComplexAdditionalDetails() {
            // Given
            String errorCode = "INFRA_ERROR_007";
            String errorMessage = "Service unavailable";
            Object[] additionalDetails = {
                "serviceName",
                "timeout",
                5000,
                "retryAttempts",
                3,
                true
            };

            // When
            InfrastructureException exception = new InfrastructureException(
                errorCode,
                errorMessage,
                additionalDetails
            );

            // Then
            assertThat(exception.getAdditionalDetails()).hasSize(6);
            assertThat(exception.getAdditionalDetails()[0]).isEqualTo("serviceName");
            assertThat(exception.getAdditionalDetails()[2]).isEqualTo(5000);
        }
    }

    @Nested
    @DisplayName("Constructor: InfrastructureException(String, String)")
    class ConstructorWithStringCodeAndMessage {

        @Test
        @DisplayName("Should create exception with error code and message only")
        void shouldCreateExceptionWithCodeAndMessage() {
            // Given
            String errorCode = "INFRA_ERROR_008";
            String errorMessage = "Redis connection timeout";

            // When
            InfrastructureException exception = new InfrastructureException(
                errorCode,
                errorMessage
            );

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).isEqualTo(errorCode);
            assertThat(exception.getErrorMessage()).isEqualTo(errorMessage);
            assertThat(exception.getCause()).isNull();
            assertThat(exception.getMessage()).isEqualTo(errorMessage);
        }

        @Test
        @DisplayName("Should handle empty error code")
        void shouldHandleEmptyErrorCode() {
            // Given
            String errorCode = "";
            String errorMessage = "Error occurred";

            // When
            InfrastructureException exception = new InfrastructureException(
                errorCode,
                errorMessage
            );

            // Then
            assertThat(exception.getErrorCode()).isEmpty();
            assertThat(exception.getErrorMessage()).isEqualTo(errorMessage);
        }

        @Test
        @DisplayName("Should handle empty error message")
        void shouldHandleEmptyErrorMessage() {
            // Given
            String errorCode = "INFRA_ERROR_009";
            String errorMessage = "";

            // When
            InfrastructureException exception = new InfrastructureException(
                errorCode,
                errorMessage
            );

            // Then
            assertThat(exception.getErrorCode()).isEqualTo(errorCode);
            assertThat(exception.getErrorMessage()).isEmpty();
        }

        @Test
        @DisplayName("Should handle long error messages")
        void shouldHandleLongErrorMessages() {
            // Given
            String errorCode = "INFRA_ERROR_010";
            String errorMessage = "Very long error message. ".repeat(50);

            // When
            InfrastructureException exception = new InfrastructureException(
                errorCode,
                errorMessage
            );

            // Then
            assertThat(exception.getErrorMessage()).contains("Very long error message.");
            assertThat(exception.getErrorMessage().length()).isGreaterThan(1000);
        }
    }

    @Nested
    @DisplayName("Constructor: InfrastructureException(ErrorCode, Object[])")
    class ConstructorWithErrorCodeAndDetails {

        @Test
        @DisplayName("Should create exception with ErrorCode and details")
        void shouldCreateExceptionWithErrorCodeAndDetails() {
            // Given
            InfraErrorCode errorCode = InfraErrorCode.SERVICE_UNAVAILABLE;
            Object[] additionalDetails = {"serviceName", "api-gateway", "statusCode", 503};

            // When
            InfrastructureException exception = new InfrastructureException(
                errorCode,
                additionalDetails
            );

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).isEqualTo(errorCode.getCode());
            assertThat(exception.getErrorMessage()).isEqualTo(errorCode.getMessage());
            assertThat(exception.getAdditionalDetails()).isEqualTo(additionalDetails);
            assertThat(exception.getCause()).isNull();
        }

        @Test
        @DisplayName("Should work with all InfraErrorCode enum values")
        void shouldWorkWithAllInfraErrorCodeValues() {
            // Given
            Object[] details = {"test"};

            // When & Then
            InfrastructureException ex1 = new InfrastructureException(
                InfraErrorCode.JPA_SYSTEM,
                details
            );
            assertThat(ex1.getErrorCode()).isEqualTo("JPA_SYSTEM");
            assertThat(ex1.getErrorMessage()).contains("JPA");

            InfrastructureException ex2 = new InfrastructureException(
                InfraErrorCode.ACCESS_DATABASE,
                details
            );
            assertThat(ex2.getErrorCode()).isEqualTo("ACCESS_DATABASE");
            assertThat(ex2.getErrorMessage()).contains("banco de dados");

            InfrastructureException ex3 = new InfrastructureException(
                InfraErrorCode.NOT_FOUND,
                details
            );
            assertThat(ex3.getErrorCode()).isEqualTo("NOT_FOUND");
            assertThat(ex3.getErrorMessage()).contains("nao encontrado");
        }

        @Test
        @DisplayName("Should handle null additional details")
        void shouldHandleNullAdditionalDetails() {
            // Given
            InfraErrorCode errorCode = InfraErrorCode.BAD_REQUEST;
            Object[] additionalDetails = null;

            // When
            InfrastructureException exception = new InfrastructureException(
                errorCode,
                additionalDetails
            );

            // Then
            assertThat(exception.getAdditionalDetails()).isEmpty();
            assertThat(exception.getErrorCode()).isEqualTo(errorCode.getCode());
        }

        @Test
        @DisplayName("Should handle empty additional details")
        void shouldHandleEmptyAdditionalDetails() {
            // Given
            InfraErrorCode errorCode = InfraErrorCode.UNPROCESSABLE_CONTENT;
            Object[] additionalDetails = {};

            // When
            InfrastructureException exception = new InfrastructureException(
                errorCode,
                additionalDetails
            );

            // Then
            assertThat(exception.getAdditionalDetails()).isEmpty();
        }
    }

    @Nested
    @DisplayName("Constructor: InfrastructureException(ErrorCode, Throwable)")
    class ConstructorWithErrorCodeAndCause {

        @Test
        @DisplayName("Should create exception with ErrorCode and cause")
        void shouldCreateExceptionWithErrorCodeAndCause() {
            // Given
            InfraErrorCode errorCode = InfraErrorCode.ACCESS_DATABASE;
            Throwable cause = new java.sql.SQLException("Connection refused");

            // When
            InfrastructureException exception = new InfrastructureException(
                errorCode,
                cause
            );

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).isEqualTo(errorCode.getCode());
            assertThat(exception.getErrorMessage()).isEqualTo(errorCode.getMessage());
            assertThat(exception.getCause()).isEqualTo(cause);
            assertThat(exception.getCause()).isInstanceOf(java.sql.SQLException.class);
        }

        @Test
        @DisplayName("Should handle different exception types as cause")
        void shouldHandleDifferentExceptionTypes() {
            // Given
            InfraErrorCode errorCode = InfraErrorCode.SERVICE_UNAVAILABLE;

            // When & Then - NullPointerException
            NullPointerException npe = new NullPointerException("Null value");
            InfrastructureException ex1 = new InfrastructureException(errorCode, npe);
            assertThat(ex1.getCause()).isInstanceOf(NullPointerException.class);

            // When & Then - IllegalArgumentException
            IllegalArgumentException iae = new IllegalArgumentException("Invalid arg");
            InfrastructureException ex2 = new InfrastructureException(errorCode, iae);
            assertThat(ex2.getCause()).isInstanceOf(IllegalArgumentException.class);

            // When & Then - RuntimeException
            RuntimeException re = new RuntimeException("Runtime error");
            InfrastructureException ex3 = new InfrastructureException(errorCode, re);
            assertThat(ex3.getCause()).isInstanceOf(RuntimeException.class);
        }

        @Test
        @DisplayName("Should preserve cause chain")
        void shouldPreserveCauseChain() {
            // Given
            Throwable rootCause = new Exception("Root cause");
            Throwable intermediateCause = new RuntimeException("Intermediate", rootCause);
            InfraErrorCode errorCode = InfraErrorCode.JPA_SYSTEM;

            // When
            InfrastructureException exception = new InfrastructureException(
                errorCode,
                intermediateCause
            );

            // Then
            assertThat(exception.getCause()).isEqualTo(intermediateCause);
            assertThat(exception.getCause().getCause()).isEqualTo(rootCause);
        }

        @Test
        @DisplayName("Should work with all InfraErrorCode enum values")
        void shouldWorkWithAllErrorCodes() {
            // Given
            Throwable cause = new Exception("Test cause");

            // When & Then
            InfrastructureException ex1 = new InfrastructureException(
                InfraErrorCode.CALL_NOT_PERMITTED,
                cause
            );
            assertThat(ex1.getErrorCode()).isEqualTo("CALL_NOT_PERMITTED");

            InfrastructureException ex2 = new InfrastructureException(
                InfraErrorCode.NOT_FOUND,
                cause
            );
            assertThat(ex2.getErrorCode()).isEqualTo("NOT_FOUND");

            InfrastructureException ex3 = new InfrastructureException(
                InfraErrorCode.UNPROCESSABLE_CONTENT,
                cause
            );
            assertThat(ex3.getErrorCode()).isEqualTo("UNPROCESSABLE_CONTENT");
        }
    }

    @Nested
    @DisplayName("Constructor: InfrastructureException(ErrorCode)")
    class ConstructorWithErrorCodeOnly {

        @Test
        @DisplayName("Should create exception with ErrorCode only")
        void shouldCreateExceptionWithErrorCodeOnly() {
            // Given
            InfraErrorCode errorCode = InfraErrorCode.SERVICE_UNAVAILABLE;

            // When
            InfrastructureException exception = new InfrastructureException(errorCode);

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).isEqualTo(errorCode.getCode());
            assertThat(exception.getErrorMessage()).isEqualTo(errorCode.getMessage());
            assertThat(exception.getCause()).isNull();
        }

        @Test
        @DisplayName("Should work with JPA_SYSTEM error code")
        void shouldWorkWithJpaSystemErrorCode() {
            // When
            InfrastructureException exception = new InfrastructureException(
                InfraErrorCode.JPA_SYSTEM
            );

            // Then
            assertThat(exception.getErrorCode()).isEqualTo("JPA_SYSTEM");
            assertThat(exception.getErrorMessage()).isEqualTo("Erro no sistema JPA");
        }

        @Test
        @DisplayName("Should work with ACCESS_DATABASE error code")
        void shouldWorkWithAccessDatabaseErrorCode() {
            // When
            InfrastructureException exception = new InfrastructureException(
                InfraErrorCode.ACCESS_DATABASE
            );

            // Then
            assertThat(exception.getErrorCode()).isEqualTo("ACCESS_DATABASE");
            assertThat(exception.getErrorMessage()).isEqualTo("Erro ao acessar o banco de dados");
        }

        @Test
        @DisplayName("Should work with CALL_NOT_PERMITTED error code")
        void shouldWorkWithCallNotPermittedErrorCode() {
            // When
            InfrastructureException exception = new InfrastructureException(
                InfraErrorCode.CALL_NOT_PERMITTED
            );

            // Then
            assertThat(exception.getErrorCode()).isEqualTo("CALL_NOT_PERMITTED");
            assertThat(exception.getErrorMessage()).isEqualTo("Chamada nao permitida");
        }

        @Test
        @DisplayName("Should work with NOT_FOUND error code")
        void shouldWorkWithNotFoundErrorCode() {
            // When
            InfrastructureException exception = new InfrastructureException(
                InfraErrorCode.NOT_FOUND
            );

            // Then
            assertThat(exception.getErrorCode()).isEqualTo("NOT_FOUND");
            assertThat(exception.getErrorMessage()).isEqualTo("Recurso nao encontrado");
        }

        @Test
        @DisplayName("Should work with UNPROCESSABLE_CONTENT error code")
        void shouldWorkWithUnprocessableContentErrorCode() {
            // When
            InfrastructureException exception = new InfrastructureException(
                InfraErrorCode.UNPROCESSABLE_CONTENT
            );

            // Then
            assertThat(exception.getErrorCode()).isEqualTo("UNPROCESSABLE_CONTENT");
            assertThat(exception.getErrorMessage()).isEqualTo("Entidade nao processavel");
        }

        @Test
        @DisplayName("Should work with BAD_REQUEST error code")
        void shouldWorkWithBadRequestErrorCode() {
            // When
            InfrastructureException exception = new InfrastructureException(
                InfraErrorCode.BAD_REQUEST
            );

            // Then
            assertThat(exception.getErrorCode()).isEqualTo("BAD_REQUEST");
            assertThat(exception.getErrorMessage()).isEqualTo("Nao e possivel acessar o recurso solicitado");
        }
    }

    @Nested
    @DisplayName("Serialization and Exception Behavior")
    class SerializationAndBehavior {

        @Test
        @DisplayName("Should have serialVersionUID")
        void shouldHaveSerialVersionUID() {
            // Given
            InfrastructureException exception = new InfrastructureException(
                InfraErrorCode.SERVICE_UNAVAILABLE
            );

            // Then
            assertThat(exception).isInstanceOf(java.io.Serializable.class);
        }

        @Test
        @DisplayName("Should be throwable as RuntimeException")
        void shouldBeThrowableAsRuntimeException() {
            // Given
            InfrastructureException exception = new InfrastructureException(
                InfraErrorCode.ACCESS_DATABASE
            );

            // Then
            assertThat(exception)
                .isInstanceOf(RuntimeException.class)
                .isInstanceOf(Exception.class)
                .isInstanceOf(Throwable.class);
        }

        @Test
        @DisplayName("Should preserve stack trace")
        void shouldPreserveStackTrace() {
            // When
            InfrastructureException exception = new InfrastructureException(
                "ERROR_CODE",
                "Error message"
            );

            // Then
            assertThat(exception.getStackTrace()).isNotNull();
            assertThat(exception.getStackTrace()).isNotEmpty();
        }

        @Test
        @DisplayName("Should be able to throw and catch")
        void shouldBeAbleToThrowAndCatch() {
            // Given
            String errorCode = "INFRA_TEST_ERROR";
            String errorMessage = "Test infrastructure error";

            // When/Then
            try {
                throw new InfrastructureException(errorCode, errorMessage);
            } catch (InfrastructureException e) {
                assertThat(e.getErrorCode()).isEqualTo(errorCode);
                assertThat(e.getErrorMessage()).isEqualTo(errorMessage);
            }
        }
    }

    @Nested
    @DisplayName("Edge Cases and Special Scenarios")
    class EdgeCases {

        @Test
        @DisplayName("Should handle special characters in error messages")
        void shouldHandleSpecialCharactersInErrorMessages() {
            // Given
            String errorCode = "INFRA_ERROR_SPECIAL";
            String errorMessage = "Error: @#$%^&*()_+-=[]{}|;:',.<>?/`~";

            // When
            InfrastructureException exception = new InfrastructureException(
                errorCode,
                errorMessage
            );

            // Then
            assertThat(exception.getErrorMessage()).isEqualTo(errorMessage);
        }

        @Test
        @DisplayName("Should handle Unicode characters")
        void shouldHandleUnicodeCharacters() {
            // Given
            String errorCode = "INFRA_ERROR_UNICODE";
            String errorMessage = "Erro: ç, á, é, í, ó, ú, ã, õ, ñ, ü, €, £, ¥";

            // When
            InfrastructureException exception = new InfrastructureException(
                errorCode,
                errorMessage
            );

            // Then
            assertThat(exception.getErrorMessage()).isEqualTo(errorMessage);
        }

        @Test
        @DisplayName("Should handle very long error codes")
        void shouldHandleVeryLongErrorCodes() {
            // Given
            String errorCode = "INFRA_".repeat(100) + "ERROR";
            String errorMessage = "Error";

            // When
            InfrastructureException exception = new InfrastructureException(
                errorCode,
                errorMessage
            );

            // Then
            assertThat(exception.getErrorCode().length()).isGreaterThan(500);
        }

        @Test
        @DisplayName("Should handle mixed type additional details")
        void shouldHandleMixedTypeAdditionalDetails() {
            // Given
            Object[] details = {
                "string",
                123,
                45.67,
                true,
                null,
                new Object()
            };

            // When
            InfrastructureException exception = new InfrastructureException(
                InfraErrorCode.SERVICE_UNAVAILABLE,
                details
            );

            // Then
            assertThat(exception.getAdditionalDetails()).hasSize(6);
            assertThat(exception.getAdditionalDetails()[0]).isEqualTo("string");
            assertThat(exception.getAdditionalDetails()[1]).isEqualTo(123);
            assertThat(exception.getAdditionalDetails()[4]).isNull();
        }
    }
}

package br.com.bradesco.srv.hex.application.usecase;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.Instant;
import java.math.BigDecimal;

import org.junit.jupiter.api.Test;
import org.mockito.invocation.InvocationOnMock;

import br.com.bradesco.srv.hex.application.model.CalibragemPFRequest;
import br.com.bradesco.srv.hex.application.model.CalibragemPFResponse;
import br.com.bradesco.srv.hex.application.model.DadosPFRequest;
import br.com.bradesco.srv.hex.application.model.DocumentosRelacionados;
import br.com.bradesco.srv.hex.application.model.Processamento;
import br.com.bradesco.srv.hex.application.model.ValidaFinResponse;
import br.com.bradesco.srv.hex.application.port.out.calibragem.CalibragemPFPort;
import br.com.bradesco.srv.hex.application.service.inter.AnaliseRendaService;
import br.com.bradesco.srv.hex.application.service.inter.CalibragemTranslatorService;
import br.com.bradesco.srv.hex.util.enumerator.ResultadoAnalise;
import br.com.bradesco.srv.hex.util.enumerator.TipoPessoa;

class AnaliseRendaPFUseCaseImplTest {

    private static final String CORRELATION_ID = "correlacao-pf-1";
    private static final String ID_PROCESSAMENTO = "id-processamento-1";
    private static final String TERMINAL = "TERMINAL-01";
    private static final String AUTORIZACAO = "Bearer token";
    private static final String CPF = "12345678901";

    private final CalibragemPFPort calibragemPFPort =
            mock(CalibragemPFPort.class);

    private final CalibragemTranslatorService calibragemTranslator =
            mock(CalibragemTranslatorService.class);

    private final AnaliseRendaService analiseRendaService =
            mock(AnaliseRendaService.class);

    private final AnaliseRendaPFUseCaseImpl useCase =
            new AnaliseRendaPFUseCaseImpl(
                    calibragemPFPort,
                    calibragemTranslator,
                    analiseRendaService
            );

    private static DadosPFRequest requisicao() {

        return DadosPFRequest.builder()
                .centroDeCusto("1234")
                .club("CLUB-01")
                .cpf(CPF)
                .valorRendaMensalDeclarada(
                        new BigDecimal("5000.00"))
                .build();
    }

    private static CalibragemPFResponse calibragem() {

        return new CalibragemPFResponse(
                "RECEITA",
                new BigDecimal("10"),
                "SIM"
        );
    }

    private static ValidaFinResponse resposta() {

        return ValidaFinResponse.builder()
                .resultadoAnalise(
                        ResultadoAnalise.APROVADO_SISTEMICAMENTE)
                .build();
    }

    /**
     * Configura a criação dos documentos relacionados.
     *
     * O AnaliseRendaService é um mock.
     * Portanto, precisamos simular seu método de criação.
     */
    private void configurarCriacaoDocumentoRelacionado() {

        when(analiseRendaService.criarDocumentoRelacionado(
                any(DocumentosRelacionados.Conteudo.class),
                anyString(),
                anyString()
        )).thenAnswer(invocation -> {

            DocumentosRelacionados.Conteudo conteudo =
                    invocation.getArgument(0);

            String idProcessamento = invocation.getArgument(1);

            String correlationId = invocation.getArgument(2);

            return new DocumentosRelacionados.Documento(
                    null,
                    idProcessamento,
                    correlationId,
                    Instant.now(),
                    conteudo
            );
        });
    }

    @Test
    void executaAnaliseComSucessoEValidaCallbacks() throws Throwable {

        var request = requisicao();

        var resultadoCalibragem = calibragem();

        var respostaEsperada = resposta();

        configurarCriacaoDocumentoRelacionado();

        when(calibragemPFPort.send(
                any(CalibragemPFRequest.class),
                eq(AUTORIZACAO)
        )).thenReturn(resultadoCalibragem);

        when(calibragemTranslator.translate(
                any(CalibragemPFResponse.class)
        )).thenReturn(respostaEsperada);

        when(analiseRendaService.executar(
                eq(request),
                eq(TERMINAL),
                eq(AUTORIZACAO),
                eq(TipoPessoa.PF),
                any(),
                any(),
                any(),
                any(),
                any()
        )).thenAnswer(invocation ->
                executarCallbacks(invocation, request)
        );

        var resultado = useCase.executar(
                request,
                TERMINAL,
                AUTORIZACAO
        );

        assertThat(resultado)
                .isSameAs(respostaEsperada);

        assertThat(resultado.getResultadoAnalise())
                .isEqualTo(
                        ResultadoAnalise.APROVADO_SISTEMICAMENTE
                );

        verify(analiseRendaService).executar(
                eq(request),
                eq(TERMINAL),
                eq(AUTORIZACAO),
                eq(TipoPessoa.PF),
                any(),
                any(),
                any(),
                any(),
                any()
        );

        verify(calibragemTranslator)
                .translate(any(CalibragemPFResponse.class));
    }

    /**
     * Executa todos os callbacks fornecidos pelo UseCase.
     */
    private Object executarCallbacks(
            InvocationOnMock invocation,
            DadosPFRequest request) throws Throwable {

        /*
         * 1. Criação da requisição.
         */

        Object criarRequisicao = invocation.getArgument(4);

        var requisicaoProcessamento = invocarCallback(
                criarRequisicao,
                request
        );

        assertThat(requisicaoProcessamento)
                .isInstanceOf(Processamento.Requisicao.class);

        var processamento =
                (Processamento.Requisicao) requisicaoProcessamento;

        assertThat(processamento.centroDeCusto())
                .isEqualTo("1234");

        assertThat(processamento.club())
                .isEqualTo("CLUB-01");

        assertThat(processamento.terminal())
                .isEqualTo(TERMINAL);

        assertThat(processamento.tipoPessoa())
                .isEqualTo("PF");

        assertThat(processamento.Documento())
                .isEqualTo(CPF);

        /*
         * 2. Criação do documento de Pessoa Física.
         */

        Object criarDocumentoPessoa = invocation.getArgument(5);

        var documentoPessoa = invocarCallback(
                criarDocumentoPessoa,
                request,
                ID_PROCESSAMENTO,
                CORRELATION_ID
        );

        assertThat(documentoPessoa)
                .isInstanceOf(DocumentosRelacionados.Documento.class);

        var documentoPF =
                (DocumentosRelacionados.Documento) documentoPessoa;

        assertThat(documentoPF.idProcessamento())
                .isEqualTo(ID_PROCESSAMENTO);

        assertThat(documentoPF.correlationId())
                .isEqualTo(CORRELATION_ID);

        assertThat(documentoPF.conteudo())
                .isInstanceOf(DocumentosRelacionados.PessoaFisica.class);

        var pessoaFisica =
                (DocumentosRelacionados.PessoaFisica)
                        documentoPF.conteudo();

        assertThat(pessoaFisica.cpf())
                .isEqualTo(CPF);

        assertThat(pessoaFisica.valorRendaMensalDeclarada())
                .isEqualByComparingTo("5000.00");

        /*
         * 3. Execução da calibragem.
         */

        Object executarCalibragem = invocation.getArgument(6);

        var resultadoCalibragem = invocarCallback(
                executarCalibragem,
                request,
                TERMINAL,
                AUTORIZACAO
        );

        assertThat(resultadoCalibragem)
                .isInstanceOf(CalibragemPFResponse.class);

        var calibragem =
                (CalibragemPFResponse) resultadoCalibragem;

        var envio = org.mockito.ArgumentCaptor.forClass(
                CalibragemPFRequest.class);

        verify(calibragemPFPort).send(
                envio.capture(),
                eq(AUTORIZACAO)
        );

        assertThat(envio.getValue().cpf())
                .isEqualTo(CPF);

        assertThat(envio.getValue().renda())
                .isEqualByComparingTo("5000.00");

        assertThat(envio.getValue().terminal())
                .isEqualTo(TERMINAL);

        /*
         * 4. Criação do documento de calibragem.
         */

        Object criarDocumentoResultado = invocation.getArgument(7);

        var documentoResultado = invocarCallback(
                criarDocumentoResultado,
                calibragem,
                ID_PROCESSAMENTO,
                CORRELATION_ID
        );

        assertThat(documentoResultado)
                .isInstanceOf(DocumentosRelacionados.Documento.class);

        var documentoCalibragem =
                (DocumentosRelacionados.Documento) documentoResultado;

        assertThat(documentoCalibragem.idProcessamento())
                .isEqualTo(ID_PROCESSAMENTO);

        assertThat(documentoCalibragem.correlationId())
                .isEqualTo(CORRELATION_ID);

        assertThat(documentoCalibragem.conteudo())
                .isEqualTo(
                        new DocumentosRelacionados.Calibragem(
                                calibragem.getValorEnquadrado(),
                                null,
                                BigDecimal.ZERO,
                                calibragem.percentualRendaReferencial(),
                                calibragem.fonteReferencia(),
                                null
                        )
                );

        /*
         * 5. Tradução do resultado.
         */

        Object traduzirResultado = invocation.getArgument(8);

        var respostaTraduzida = invocarCallback(
                traduzirResultado,
                calibragem
        );

        assertThat(respostaTraduzida)
                .isInstanceOf(ValidaFinResponse.class);

        assertThat(((ValidaFinResponse) respostaTraduzida)
                .getResultadoAnalise())
                .isEqualTo(
                        ResultadoAnalise.APROVADO_SISTEMICAMENTE
                );

        return respostaTraduzida;
    }

    /**
     * Executa os callbacks funcionais.
     */
    private Object invocarCallback(
            Object callback,
            Object... argumentos) throws Throwable {

        assertThat(callback).isNotNull();

        Method metodo = null;

        for (Method method : callback.getClass().getMethods()) {

            if (method.getDeclaringClass() == Object.class) {
                continue;
            }

            if (method.getParameterCount() == argumentos.length) {
                metodo = method;
                break;
            }
        }

        assertThat(metodo)
                .as("Método funcional do callback")
                .isNotNull();

        try {

            return metodo.invoke(callback, argumentos);

        } catch (InvocationTargetException exception) {

            throw exception.getCause();
        }
    }
}
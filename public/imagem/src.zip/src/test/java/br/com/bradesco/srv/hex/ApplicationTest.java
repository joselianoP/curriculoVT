package br.com.bradesco.srv.hex;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.springframework.boot.SpringApplication;
import org.springframework.core.env.Environment;

class ApplicationTest {

    @Test
    void mainDelegaParaSpringApplication() {
        try (MockedStatic<SpringApplication> spring = mockStatic(SpringApplication.class)) {
            String[] args = {"--teste"};

            Application.main(args);

            spring.verify(() -> SpringApplication.run(Application.class, args));
        }
    }

    @Test
    void runRegistraPerfisAtivos() {
        Environment ambiente = mock(Environment.class);
        when(ambiente.getActiveProfiles()).thenReturn(new String[] {"local", "dev"});

        assertThatCode(() -> new Application(ambiente).run()).doesNotThrowAnyException();
    }

    @Test
    void runUsaPerfilPadraoQuandoNaoHaPerfisAtivos() {
        Environment ambiente = mock(Environment.class);
        when(ambiente.getActiveProfiles()).thenReturn(new String[0]);

        assertThatCode(() -> new Application(ambiente).run()).doesNotThrowAnyException();
    }
}

package br.com.bradesco.srv.hex.application.exception;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.BDDAssertions.then;

import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

class InvalidInputExceptionTest {

	@Nested
	class ConstructorWithAllParameters {

		@Test
		void shouldCreateExceptionWithAllParameters() {
			// Given
			String origin = "TestOrigin";
			String method = "testMethod";
			String message = "Custom error message";
			Throwable cause = new RuntimeException("Root cause");

			// When
			InvalidInputException exception = new InvalidInputException(origin, method, message, cause);

			// Then
			assertThat(exception).isNotNull();
			assertThat(exception.getErrorCode()).contains(origin);
			assertThat(exception.getErrorCode()).contains(method);
			assertThat(exception.getErrorMessage()).isEqualTo(message);
			assertThat(exception.getCause()).isEqualTo(cause);
			assertThat(exception.getMessage()).isEqualTo(message);
		}

		@Test
		void shouldUseDefaultMessageWhenMessageIsNull() {
			// Given
			String origin = "TestOrigin";
			String method = "testMethod";
			String message = null;
			Throwable cause = new RuntimeException("Root cause");

			// When
			InvalidInputException exception = new InvalidInputException(origin, method, message, cause);

			// Then
			assertThat(exception).isNotNull();
			assertThat(exception.getErrorMessage()).isEqualTo(InfraErrorCode.BAD_REQUEST.getMessage());
			assertThat(exception.getMessage()).isEqualTo(InfraErrorCode.BAD_REQUEST.getMessage());
			assertThat(exception.getCause()).isEqualTo(cause);
		}

		@Test
		void shouldHandleNullMethod() {
			// Given
			String origin = "TestOrigin";
			String method = null;
			String message = "Custom message";
			Throwable cause = new RuntimeException("Root cause");

			// When
			InvalidInputException exception = new InvalidInputException(origin, method, message, cause);

			// Then
			assertThat(exception).isNotNull();
			assertThat(exception.getErrorCode()).contains(origin);
			assertThat(exception.getErrorMessage()).isEqualTo(message);
			assertThat(exception.getCause()).isEqualTo(cause);
		}

		@Test
		void shouldHandleNullCause() {
			// Given
			String origin = "TestOrigin";
			String method = "testMethod";
			String message = "Custom message";
			Throwable cause = null;

			// When
			InvalidInputException exception = new InvalidInputException(origin, method, message, cause);

			// Then
			assertThat(exception).isNotNull();
			assertThat(exception.getErrorMessage()).isEqualTo(message);
			assertThat(exception.getCause()).isNull();
		}
	}

	@Nested
	class ConstructorWithOriginMethodAndMessage {

		@Test
		void shouldCreateExceptionWithOriginMethodAndMessage() {
			// Given
			String origin = "TestOrigin";
			String method = "testMethod";
			String message = "Custom error message";

			// When
			InvalidInputException exception = new InvalidInputException(origin, method, message);

			// Then
			assertThat(exception).isNotNull();
			assertThat(exception.getErrorCode()).contains(origin);
			assertThat(exception.getErrorCode()).contains(method);
			assertThat(exception.getErrorMessage()).isEqualTo(message);
			assertThat(exception.getMessage()).isEqualTo(message);
			assertThat(exception.getCause()).isNull();
		}

		@Test
		void shouldUseDefaultMessageWhenMessageIsNull() {
			// Given
			String origin = "TestOrigin";
			String method = "testMethod";
			String message = null;

			// When
			InvalidInputException exception = new InvalidInputException(origin, method, message);

			// Then
			assertThat(exception).isNotNull();
			assertThat(exception.getErrorMessage()).isEqualTo(InfraErrorCode.BAD_REQUEST.getMessage());
			assertThat(exception.getMessage()).isEqualTo(InfraErrorCode.BAD_REQUEST.getMessage());
		}

		@Test
		void shouldHandleNullMethod() {
			// Given
			String origin = "TestOrigin";
			String method = null;
			String message = "Custom message";

			// When
			InvalidInputException exception = new InvalidInputException(origin, method, message);

			// Then
			assertThat(exception).isNotNull();
			assertThat(exception.getErrorCode()).contains(origin);
			assertThat(exception.getErrorMessage()).isEqualTo(message);
		}

		@Test
		void shouldUseDefaultMessageWhenMessageIsEmpty() {
			// Given
			String origin = "TestOrigin";
			String method = "testMethod";
			String message = "";

			// When
			InvalidInputException exception = new InvalidInputException(origin, method, message);

			// Then
			assertThat(exception).isNotNull();
			assertThat(exception.getErrorMessage()).isEmpty();
			assertThat(exception.getMessage()).isEmpty();
		}
	}

	@Nested
	class ConstructorWithCause {

		@Test
		void shouldCreateExceptionWithCause() {
			// Given
			Throwable cause = new RuntimeException("Root cause");

			// When
			InvalidInputException exception = new InvalidInputException(cause);

			// Then
			assertThat(exception).isNotNull();
			assertThat(exception.getErrorCode()).isEqualTo(InfraErrorCode.BAD_REQUEST.getCode());
			assertThat(exception.getErrorMessage()).isEqualTo(InfraErrorCode.BAD_REQUEST.getMessage());
			assertThat(exception.getCause()).isEqualTo(cause);
			assertThat(exception.getMessage()).isEqualTo(InfraErrorCode.BAD_REQUEST.getMessage());
		}

		@Test
		void shouldCreateExceptionWithNullPointerException() {
			// Given
			Throwable cause = new NullPointerException("Null value");

			// When
			InvalidInputException exception = new InvalidInputException(cause);

			// Then
			assertThat(exception).isNotNull();
			assertThat(exception.getCause()).isInstanceOf(NullPointerException.class);
			assertThat(exception.getCause().getMessage()).isEqualTo("Null value");
		}

		@Test
		void shouldCreateExceptionWithIllegalArgumentException() {
			// Given
			Throwable cause = new IllegalArgumentException("Invalid argument");

			// When
			InvalidInputException exception = new InvalidInputException(cause);

			// Then
			assertThat(exception).isNotNull();
			assertThat(exception.getCause()).isInstanceOf(IllegalArgumentException.class);
			assertThat(exception.getCause().getMessage()).isEqualTo("Invalid argument");
		}
	}

	@Nested
	class NoArgsConstructor {

		@Test
		void shouldCreateExceptionWithNoArgs() {
			// When
			InvalidInputException exception = new InvalidInputException();

			// Then
			assertThat(exception).isNotNull();
			assertThat(exception.getErrorCode()).isEqualTo(InfraErrorCode.BAD_REQUEST.getCode());
			assertThat(exception.getErrorMessage()).isEqualTo(InfraErrorCode.BAD_REQUEST.getMessage());
			assertThat(exception.getMessage()).isEqualTo(InfraErrorCode.BAD_REQUEST.getMessage());
			assertThat(exception.getCause()).isNull();
		}
	}

	@Nested
	class ExceptionBehavior {

		@Test
		void shouldBeThrowable() {
			// Given
			InvalidInputException exception = new InvalidInputException();

			// Then
			assertThat(exception).isInstanceOf(Throwable.class);
			assertThat(exception).isInstanceOf(Exception.class);
			assertThat(exception).isInstanceOf(RuntimeException.class);
		}

		@Test
		void shouldBeAbleToThrowAndCatch() {
			// Given
			String origin = "TestService";
			String method = "validateInput";
			String message = "Invalid input provided";

			// When/Then
			try {
				throw new InvalidInputException(origin, method, message);
			} catch (InvalidInputException e) {
				assertThat(e.getErrorMessage()).isEqualTo(message);
				assertThat(e.getErrorCode()).contains(origin);
				assertThat(e.getErrorCode()).contains(method);
			}
		}

		@Test
		void shouldPreserveStackTrace() {
			// Given
			InvalidInputException exception = new InvalidInputException("Origin", "method", "message");

			// When
			StackTraceElement[] stackTrace = exception.getStackTrace();

			// Then
			assertThat(stackTrace).isNotNull();
			assertThat(stackTrace).isNotEmpty();
		}
	}

	@Nested
	class ErrorCodeFormatting {

		@Test
		void shouldFormatErrorCodeCorrectly() {
			// Given
			String origin = "UserService";
			String method = "createUser";

			// When
			InvalidInputException exception = new InvalidInputException(origin, method, "Error");

			// Then
			assertThat(exception.getErrorCode()).contains(origin);
			assertThat(exception.getErrorCode()).contains(method);
			assertThat(exception.getErrorCode()).contains(InfraErrorCode.BAD_REQUEST.getCode());
		}

		@Test
		void shouldHandleSpecialCharactersInOrigin() {
			// Given
			String origin = "User-Service_V2";
			String method = "validateUser";

			// When
			InvalidInputException exception = new InvalidInputException(origin, method, "Error");

			// Then
			assertThat(exception).isNotNull();
			assertThat(exception.getErrorCode()).isNotEmpty();
		}

		@Test
		void shouldHandleSpecialCharactersInMethod() {
			// Given
			String origin = "UserService";
			String method = "validate_user_input";

			// When
			InvalidInputException exception = new InvalidInputException(origin, method, "Error");

			// Then
			assertThat(exception).isNotNull();
			assertThat(exception.getErrorCode()).isNotEmpty();
		}
	}

	@Nested
	class MessageHandling {

		@Test
		void shouldHandleLongMessage() {
			// Given
			String origin = "Service";
			String method = "method";
			String longMessage = "This is a very long error message that contains a lot of details about what went wrong in the system and why the operation failed. "
					.repeat(5);

			// When
			InvalidInputException exception = new InvalidInputException(origin, method, longMessage);

			// Then
			assertThat(exception.getErrorMessage()).isEqualTo(longMessage);
			assertThat(exception.getMessage()).isEqualTo(longMessage);
		}

		@Test
		void shouldHandleMessageWithSpecialCharacters() {
			// Given
			String origin = "Service";
			String method = "method";
			String message = "Error: Invalid input @#$%^&*()_+{}|:\"<>?[]\\;',./`~";

			// When
			InvalidInputException exception = new InvalidInputException(origin, method, message);

			// Then
			assertThat(exception.getErrorMessage()).isEqualTo(message);
		}

		@Test
		void shouldHandleMessageWithUnicodeCharacters() {
			// Given
			String origin = "Service";
			String method = "method";
			String message = "Erro: Entrada inválida com caracteres especiais: ç, á, é, í, ó, ú, ã, õ, ñ, ü";

			// When
			InvalidInputException exception = new InvalidInputException(origin, method, message);

			// Then
			assertThat(exception.getErrorMessage()).isEqualTo(message);
		}
	}

	@Nested
	class CauseChaining {

		@Test
		void shouldPreserveCauseChain() {
			// Given
			Throwable rootCause = new IllegalStateException("Root cause");
			Throwable intermediateCause = new RuntimeException("Intermediate cause", rootCause);

			// When
			InvalidInputException exception = new InvalidInputException(intermediateCause);

			// Then
			assertThat(exception.getCause()).isEqualTo(intermediateCause);
			assertThat(exception.getCause().getCause()).isEqualTo(rootCause);
		}

		@Test
		void shouldHandleDeepCauseChain() {
			// Given
			Throwable level3 = new IllegalArgumentException("Level 3");
			Throwable level2 = new RuntimeException("Level 2", level3);
			Throwable level1 = new Exception("Level 1", level2);

			// When
			InvalidInputException exception = new InvalidInputException("Origin", "method", "Error", level1);

			// Then
			assertThat(exception.getCause()).isEqualTo(level1);
			assertThat(exception.getCause().getCause()).isEqualTo(level2);
			assertThat(exception.getCause().getCause().getCause()).isEqualTo(level3);
		}
	}

	@Nested
	class EdgeCases {

		@Test
		void shouldHandleEmptyOrigin() {
			// Given
			String origin = "";
			String method = "method";
			String message = "Error";

			// When
			InvalidInputException exception = new InvalidInputException(origin, method, message);

			// Then
			assertThat(exception).isNotNull();
			assertThat(exception.getErrorCode()).isNotEmpty();
		}

		@Test
		void shouldHandleEmptyMethod() {
			// Given
			String origin = "Origin";
			String method = "";
			String message = "Error";

			// When
			InvalidInputException exception = new InvalidInputException(origin, method, message);

			// Then
			assertThat(exception).isNotNull();
			assertThat(exception.getErrorCode()).isNotEmpty();
		}

		@Test
		void shouldHandleWhitespaceMessage() {
			// Given
			String origin = "Origin";
			String method = "method";
			String message = "   ";

			// When
			InvalidInputException exception = new InvalidInputException(origin, method, message);

			// Then
			assertThat(exception.getErrorMessage()).isEqualTo("   ");
		}

		@Test
		void shouldHandleVeryLongOriginAndMethod() {
			// Given
			String origin = "A".repeat(1000);
			String method = "B".repeat(1000);
			String message = "Error";

			// When
			InvalidInputException exception = new InvalidInputException(origin, method, message);

			// Then
			assertThat(exception).isNotNull();
			assertThat(exception.getErrorCode()).isNotEmpty();
		}
	}

	@Nested
	class Integration {

		@Test
		void shouldWorkWithTryCatchFinally() {
			// Given
			boolean[] finallyExecuted = { false };

			// When/Then
			try {
				throw new InvalidInputException("Service", "method", "Error");
			} catch (InvalidInputException e) {
				then(e).isNotNull();
				then(e.getErrorMessage()).isEqualTo("Error");
			} finally {
				finallyExecuted[0] = true;
			}

			assertThat(finallyExecuted[0]).isTrue();
		}

		@Test
		void shouldWorkWithMultipleCatchBlocks() {
			// Given
			InvalidInputException thrownException = null;

			// When
			try {
				throw new InvalidInputException("Service", "method", "Test error");
			} catch (InvalidInputException e) {
				thrownException = e;
			} catch (RuntimeException ex) {
				// Should not reach here
				assertThat(true).isFalse();
			}

			// Then
			assertThat(thrownException).isNotNull();
			assertThat(thrownException.getErrorMessage()).isEqualTo("Test error");
		}

		@Test
		void shouldBeSerializableAsRuntimeException() {
			// Given
			InvalidInputException exception = new InvalidInputException("Origin", "method", "Message");

			// When/Then
			assertThat(exception).isInstanceOf(RuntimeException.class);
			assertThat(exception).isInstanceOf(Exception.class);
			assertThat(exception).isInstanceOf(Throwable.class);
		}
	}
}

package br.com.bradesco.srv.hex.adapter.in.api.config;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class ObjectMapperConfigTest {
	@Test
	void criaObjectMapper() {
		assertNotNull(new ObjectMapperConfig().objectMapper());
	}
}

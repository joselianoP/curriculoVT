package br.com.bradesco.srv.hex.application.model;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.util.UUID;

import org.junit.jupiter.api.Test;

import br.com.bradesco.srv.hex.util.enumerator.Periodicidade;
import br.com.bradesco.srv.hex.util.enumerator.ResultadoAnalise;
import br.com.bradesco.srv.hex.util.enumerator.TipoPessoa;

class ApplicationModelsTest {
    @Test void analiseEventMessageExponeTodosOsCampos() {
        var event = new AnaliseEventMessage("event-1", "corr-1", "doc-1");
        assertEquals("event-1", event.eventId());
        assertEquals("corr-1", event.correlationId());
        assertEquals("doc-1", event.documentoId());
    }

    @Test void rendaRequestEValidaFinRequestPermitemCriacaoEAlteracao() {
        var pf = DadosPFRequest.builder().centroDeCusto("CC").club("CLUB").cpf("123").valorRendaMensalDeclarada(BigDecimal.TEN).build();
        var pj = DadosPJRequest.builder().centroDeCusto("CC").club("CLUB").cnpj("123").periodicidade(Periodicidade.MENSAL).anoReferencia(2025).valorFaturamentoDeclarado(BigDecimal.TEN).build();
        var request = ValidaFinRequest.builder().centroDeCusto("CC").club("CLUB").terminal("TERM").tipoPessoa(TipoPessoa.PF).dadosPF(pf).dadosPJ(pj).build();
        assertEquals("123", request.getDadosPF().getCpf());
        assertEquals(Periodicidade.MENSAL, request.getDadosPJ().getPeriodicidade());
        request.setTipoPessoa(TipoPessoa.PJ);
        assertEquals(TipoPessoa.PJ, request.getTipoPessoa());
        assertNotNull(new RendaRequest());
    }

    @Test void validaFinResponseSuportaGettersESetters() {
        var response = ValidaFinResponse.builder().resultadoAnalise(ResultadoAnalise.APROVADO_SISTEMICAMENTE)
                .idAnalise(UUID.randomUUID().toString()).statusComprovacao(1).mensagem("ok").build();
        assertEquals(ResultadoAnalise.APROVADO_SISTEMICAMENTE, response.getResultadoAnalise());
        assertEquals(1, response.getStatusComprovacao());
        response.setMensagem("atualizado");
        assertEquals("atualizado", response.getMensagem());
    }
}

package br.com.bradesco.srv.hex.application.service;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

import br.com.bradesco.srv.hex.application.model.CalibragemPFResponse;
import br.com.bradesco.srv.hex.application.model.CalibragemPJResponse;
import br.com.bradesco.srv.hex.application.model.ValidaFinResponse;
import br.com.bradesco.srv.hex.util.ConstantsUtil;
import br.com.bradesco.srv.hex.util.enumerator.ResultadoAnalise;

class CalibragemTranslatorServiceImplTest {

    private static final String CORRELATION_ID = "correlation-translator-1";

    private final CalibragemTranslatorServiceImpl translator = new CalibragemTranslatorServiceImpl();

    @BeforeEach
    void configurarMdc() {
        MDC.put(ConstantsUtil.COORELATION_ID, CORRELATION_ID);
    }

    @AfterEach
    void limparMdc() {
        MDC.clear();
    }

    @Test
    void traduzCalibragemAprovadaParaAprovadoSistemicamente() {
        var calibragem = new CalibragemPFResponse("RECEITA", null, ConstantsUtil.FRAMED);

        ValidaFinResponse response = translator.translate(calibragem);

        assertThat(response.getResultadoAnalise())
                .isEqualTo(ResultadoAnalise.APROVADO_SISTEMICAMENTE);
        assertThat(response.getIdAnalise()).isEqualTo(CORRELATION_ID);
        assertThat(response.getStatusComprovacao()).isEqualTo(1);
        assertThat(response.getMensagem()).isEqualTo("Validada e aprovada sistemicamente");
    }

    @Test
    void traduzCalibragemNaoEnquadradaParaSolicitarComprovante() {
        var calibragem = new CalibragemPJResponse(
                ConstantsUtil.NOT_FRAMED, false, null, "RECEITA", "ANUAL");

        ValidaFinResponse response = translator.translate(calibragem);

        assertThat(response.getResultadoAnalise())
                .isEqualTo(ResultadoAnalise.SOLICITAR_COMPROVANTE);
        assertThat(response.getIdAnalise()).isEqualTo(CORRELATION_ID);
        assertThat(response.getStatusComprovacao()).isEqualTo(2);
        assertThat(response.getMensagem()).isEqualTo("Necessário solicitar comprovante");
    }

    @Test
    void identificaRespostaComFonteErro() {
        var calibragem = new CalibragemPJResponse(
                "SIM", false, null, "ERRO", "ANUAL");

        assertThat(translator.possuiErro(calibragem)).isTrue();
    }

    @Test
    void naoIdentificaErroQuandoFonteNaoEhErro() {
        var calibragem = new CalibragemPFResponse("RECEITA", null, "SIM");

        assertThat(translator.possuiErro(calibragem)).isFalse();
    }

    @Test
    void naoIdentificaErroQuandoRespostaEhNula() {
        assertThat(translator.possuiErro(null)).isFalse();
    }
}

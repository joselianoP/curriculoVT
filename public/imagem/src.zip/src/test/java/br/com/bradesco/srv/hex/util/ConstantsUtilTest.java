package br.com.bradesco.srv.hex.util;

import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import org.junit.jupiter.api.Test;

class ConstantsUtilTest {
    @Test void constantesHttpPossuemValoresEsperados() {
        assertEquals("200", ConstantsUtil.SUCCESS); assertEquals("400", ConstantsUtil.BAD_REQUEST);
        assertEquals("401", ConstantsUtil.UNAUTHORIZED); assertEquals("403", ConstantsUtil.FORBIDDEN);
        assertEquals("404", ConstantsUtil.NOT_FOUND); assertEquals("409", ConstantsUtil.CONFLICT);
        assertEquals("422", ConstantsUtil.UNPROCESSABLE_ENTITY); assertEquals("429", ConstantsUtil.TOO_MANY_REQUESTS);
        assertEquals("500", ConstantsUtil.INTERNAL_SERVER_ERROR); assertEquals("502", ConstantsUtil.BAD_GATEWAY);
        assertEquals("503", ConstantsUtil.SERVICE_UNAVAILABLE); assertEquals("504", ConstantsUtil.GATEWAY_TIMEOUT);
    }
    @Test void construtorNaoPodeSerUsado() throws Exception {
        Constructor<ConstantsUtil> constructor = ConstantsUtil.class.getDeclaredConstructor();
        constructor.setAccessible(true);
        InvocationTargetException ex = assertThrows(InvocationTargetException.class, constructor::newInstance);
        assertInstanceOf(IllegalStateException.class, ex.getCause());
    }
}

package br.com.bradesco.srv.hex.application.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InOrder;

import br.com.bradesco.srv.hex.application.exception.DocumentoEmAnaliseException;
import br.com.bradesco.srv.hex.application.exception.DocumentoJaCadastradoException;
import br.com.bradesco.srv.hex.application.model.Processamento;
import br.com.bradesco.srv.hex.application.port.out.mongo.ProcessamentoRepositoryPort;

class RegistrarValidaFinDocumentServiceImplTest {

    private final ProcessamentoRepositoryPort repositorio =
            mock(ProcessamentoRepositoryPort.class);

    private final RegistrarValidaFinDocumentServiceImpl servico =
            new RegistrarValidaFinDocumentServiceImpl(repositorio);

    private static Processamento processamento(
            String correlationId,
            Processamento.Requisicao requisicao) {

        return new Processamento(
                correlationId,
                "1",
                requisicao,
                null);
    }

    private static Processamento.Requisicao requisicaoPF() {

        return new Processamento.Requisicao(
                "1234",
                "CLUB-01",
                "TERMINAL-01",
                "PF",
                "12345678901");
    }

    private static Processamento.Requisicao requisicaoPJ() {

        return new Processamento.Requisicao(
                "1234",
                "CLUB-01",
                "TERMINAL-01",
                "PJ",
                "12345678000199");
    }

    @Test
    void deveRegistrarProcessamentoERetornarIdGerado() {

        var entrada = processamento(
                "correlacao-1",
                requisicaoPF());

        when(repositorio.salvarPrincipal(entrada))
                .thenReturn("id-gerado");

        String id = servico.executar(entrada);

        assertThat(id).isEqualTo("id-gerado");

        InOrder ordem = inOrder(repositorio);

        ordem.verify(repositorio)
                .validarDuplicidade(entrada);

        ordem.verify(repositorio)
                .validarDocumentoEmProcessamento(
                        "12345678901",
                        "PF");

        ordem.verify(repositorio)
                .salvarPrincipal(entrada);
    }

    @Test
    void deveValidarDocumentoPessoaFisicaPorCpf() {

        var entrada = processamento(
                "correlacao-pf",
                requisicaoPF());

        when(repositorio.salvarPrincipal(entrada))
                .thenReturn("id-pf");

        String id = servico.executar(entrada);

        assertThat(id).isEqualTo("id-pf");

        verify(repositorio)
                .validarDocumentoEmProcessamento(
                        "12345678901",
                        "PF");

        verify(repositorio)
                .salvarPrincipal(entrada);
    }

    @Test
    void deveValidarDocumentoPessoaJuridicaPorCnpj() {

        var entrada = processamento(
                "correlacao-pj",
                requisicaoPJ());

        when(repositorio.salvarPrincipal(entrada))
                .thenReturn("id-pj");

        String id = servico.executar(entrada);

        assertThat(id).isEqualTo("id-pj");

        verify(repositorio)
                .validarDocumentoEmProcessamento(
                        "12345678000199",
                        "PJ");

        verify(repositorio)
                .salvarPrincipal(entrada);
    }

    @Test
    void naoDeveValidarDocumentoEmProcessamentoSemRequisicao() {

        var entrada = processamento(
                "correlacao-1",
                null);

        when(repositorio.salvarPrincipal(entrada))
                .thenReturn("id-gerado");

        String id = servico.executar(entrada);

        assertThat(id).isEqualTo("id-gerado");

        verify(repositorio)
                .validarDuplicidade(entrada);

        verify(repositorio, never())
                .validarDocumentoEmProcessamento(any(), any());

        verify(repositorio)
                .salvarPrincipal(entrada);
    }

    @ParameterizedTest
    @NullAndEmptySource
    @ValueSource(strings = {" "})
    void deveRejeitarCorrelationIdAusente(String correlationId) {

        var entrada = processamento(
                correlationId,
                requisicaoPF());

        assertThatThrownBy(() -> servico.executar(entrada))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("correlationId obrigatório");

        verifyNoInteractions(repositorio);
    }

    @Test
    void devePropagarErroQuandoProcessamentoDuplicado() {

        var entrada = processamento(
                "correlacao-1",
                requisicaoPF());

        doThrow(new DocumentoJaCadastradoException("duplicado"))
                .when(repositorio)
                .validarDuplicidade(entrada);

        assertThatThrownBy(() -> servico.executar(entrada))
                .isInstanceOf(DocumentoJaCadastradoException.class)
                .hasMessage("duplicado");

        verify(repositorio)
                .validarDuplicidade(entrada);

        verify(repositorio, never())
                .validarDocumentoEmProcessamento(any(), any());

        verify(repositorio, never())
                .salvarPrincipal(any());
    }

    @Test
    void devePropagarErroQuandoDocumentoJaEstaEmAnalise() {

        var entrada = processamento(
                "correlacao-1",
                requisicaoPF());

        doThrow(new DocumentoEmAnaliseException("em analise"))
                .when(repositorio)
                .validarDocumentoEmProcessamento(
                        "12345678901",
                        "PF");

        assertThatThrownBy(() -> servico.executar(entrada))
                .isInstanceOf(DocumentoEmAnaliseException.class)
                .hasMessage("em analise");

        InOrder ordem = inOrder(repositorio);

        ordem.verify(repositorio)
                .validarDuplicidade(entrada);

        ordem.verify(repositorio)
                .validarDocumentoEmProcessamento(
                        "12345678901",
                        "PF");

        verify(repositorio, never())
                .salvarPrincipal(any());
    }

    @Test
    void deveRetornarIdGeradoPeloRepositorio() {

        var entrada = processamento(
                "correlacao-1",
                requisicaoPF());

        when(repositorio.salvarPrincipal(entrada))
                .thenReturn("processamento-123");

        String resultado = servico.executar(entrada);

        assertThat(resultado)
                .isEqualTo("processamento-123");

        verify(repositorio)
                .salvarPrincipal(entrada);
    }

    @Test
    void deveExecutarValidacoesAntesDaPersistencia() {

        var entrada = processamento(
                "correlacao-1",
                requisicaoPJ());

        when(repositorio.salvarPrincipal(entrada))
                .thenReturn("processamento-456");

        servico.executar(entrada);

        InOrder ordem = inOrder(repositorio);

        ordem.verify(repositorio)
                .validarDuplicidade(entrada);

        ordem.verify(repositorio)
                .validarDocumentoEmProcessamento(
                        "12345678000199",
                        "PJ");

        ordem.verify(repositorio)
                .salvarPrincipal(entrada);
    }
}
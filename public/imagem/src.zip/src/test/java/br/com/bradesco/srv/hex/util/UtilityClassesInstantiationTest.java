package br.com.bradesco.srv.hex.util;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.lang.reflect.InvocationTargetException;

import org.junit.jupiter.api.Test;

class UtilityClassesInstantiationTest {

    private static void assertConstrutorBloqueado(Class<?> tipo) throws ReflectiveOperationException {
        var construtor = tipo.getDeclaredConstructor();
        construtor.setAccessible(true);

        assertThatThrownBy(construtor::newInstance)
                .isInstanceOf(InvocationTargetException.class)
                .hasCauseInstanceOf(IllegalStateException.class)
                .cause()
                .hasMessage("Utility class");
    }

    @Test
    void blankStringUtilNaoPodeSerInstanciada() throws Exception {
        assertConstrutorBloqueado(BlankStringUtil.class);
    }

    @Test
    void constantsColletionUtilNaoPodeSerInstanciada() throws Exception {
        assertConstrutorBloqueado(ConstantsColletionUtil.class);
    }

    @Test
    void requireNonBlankSemMensagemLancaExcecaoSemMensagem() {
        assertThat(BlankStringUtil.requireNonBlank("ok")).isEqualTo("ok");
        assertThatThrownBy(() -> BlankStringUtil.requireNonBlank(" "))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage(null);
    }
}

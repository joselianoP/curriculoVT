package br.com.bradesco.srv.hex.application.usecase;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.Instant;
import java.math.BigDecimal;

import org.junit.jupiter.api.Test;
import org.mockito.invocation.InvocationOnMock;

import br.com.bradesco.srv.hex.application.model.CalibragemPJRequest;
import br.com.bradesco.srv.hex.application.model.CalibragemPJResponse;
import br.com.bradesco.srv.hex.application.model.DadosPJRequest;
import br.com.bradesco.srv.hex.application.model.DocumentosRelacionados;
import br.com.bradesco.srv.hex.application.model.Processamento;
import br.com.bradesco.srv.hex.application.model.ValidaFinResponse;
import br.com.bradesco.srv.hex.application.port.out.calibragem.CalibragemPJPort;
import br.com.bradesco.srv.hex.application.service.inter.AnaliseRendaService;
import br.com.bradesco.srv.hex.application.service.inter.CalibragemTranslatorService;
import br.com.bradesco.srv.hex.util.enumerator.Periodicidade;
import br.com.bradesco.srv.hex.util.enumerator.ResultadoAnalise;
import br.com.bradesco.srv.hex.util.enumerator.TipoPessoa;

class AnaliseRendaPJUseCaseImplTest {

    private static final String CORRELATION_ID = "correlacao-pj-1";
    private static final String ID_PROCESSAMENTO = "id-processamento-1";
    private static final String TERMINAL = "TERMINAL-01";
    private static final String AUTORIZACAO = "Bearer token";
    private static final String CNPJ = "12345678000199";

    private final CalibragemPJPort calibragemPJPort =
            mock(CalibragemPJPort.class);

    private final CalibragemTranslatorService calibragemTranslator =
            mock(CalibragemTranslatorService.class);

    private final AnaliseRendaService analiseRendaService =
            mock(AnaliseRendaService.class);

    private final AnaliseRendaPJUseCaseImpl useCase =
            new AnaliseRendaPJUseCaseImpl(
                    calibragemPJPort,
                    calibragemTranslator,
                    analiseRendaService
            );

    private static DadosPJRequest requisicao() {

        return DadosPJRequest.builder()
                .centroDeCusto("1234")
                .club("CLUB-01")
                .cnpj(CNPJ)
                .periodicidade(Periodicidade.ANUAL)
                .anoReferencia(2026)
                .valorFaturamentoDeclarado(
                        new BigDecimal("500000.00"))
                .build();
    }

    private static CalibragemPJResponse calibragem() {

        return new CalibragemPJResponse(
                "SIM",
                true,
                new BigDecimal("10"),
                "RECEITA",
                "ANUAL"
        );
    }

    private static ValidaFinResponse resposta() {

        return ValidaFinResponse.builder()
                .resultadoAnalise(
                        ResultadoAnalise.APROVADO_SISTEMICAMENTE)
                .build();
    }

    /**
     * Configura a criação dos documentos relacionados.
     */
    private void configurarCriacaoDocumentoRelacionado() {

        when(analiseRendaService.criarDocumentoRelacionado(
                any(DocumentosRelacionados.Conteudo.class),
                anyString(),
                anyString()
        )).thenAnswer(invocation -> {

            DocumentosRelacionados.Conteudo conteudo =
                    invocation.getArgument(0);

            String idProcessamento = invocation.getArgument(1);

            String correlationId = invocation.getArgument(2);

            return new DocumentosRelacionados.Documento(
                    null,
                    idProcessamento,
                    correlationId,
                    Instant.now(),
                    conteudo
            );
        });
    }

    @Test
    void executaAnaliseComSucessoEValidaCallbacks() throws Throwable {

        var request = requisicao();

        var resultadoCalibragem = calibragem();

        var respostaEsperada = resposta();

        configurarCriacaoDocumentoRelacionado();

        when(calibragemPJPort.send(
                any(CalibragemPJRequest.class),
                eq(AUTORIZACAO)
        )).thenReturn(resultadoCalibragem);

        when(calibragemTranslator.translate(
                any(CalibragemPJResponse.class)
        )).thenReturn(respostaEsperada);

        when(analiseRendaService.executar(
                eq(request),
                eq(TERMINAL),
                eq(AUTORIZACAO),
                eq(TipoPessoa.PJ),
                any(),
                any(),
                any(),
                any(),
                any()
        )).thenAnswer(invocation ->
                executarCallbacks(invocation, request)
        );

        var resultado = useCase.executar(
                request,
                TERMINAL,
                AUTORIZACAO
        );

        assertThat(resultado)
                .isSameAs(respostaEsperada);

        assertThat(resultado.getResultadoAnalise())
                .isEqualTo(
                        ResultadoAnalise.APROVADO_SISTEMICAMENTE
                );

        verify(analiseRendaService).executar(
                eq(request),
                eq(TERMINAL),
                eq(AUTORIZACAO),
                eq(TipoPessoa.PJ),
                any(),
                any(),
                any(),
                any(),
                any()
        );

        verify(calibragemTranslator)
                .translate(any(CalibragemPJResponse.class));
    }

    /**
     * Executa todos os callbacks fornecidos pelo UseCase.
     */
    private Object executarCallbacks(
            InvocationOnMock invocation,
            DadosPJRequest request) throws Throwable {

        /*
         * 1. Criação da requisição.
         */

        Object criarRequisicao = invocation.getArgument(4);

        var requisicaoProcessamento = invocarCallback(
                criarRequisicao,
                request
        );

        assertThat(requisicaoProcessamento)
                .isInstanceOf(Processamento.Requisicao.class);

        var processamento =
                (Processamento.Requisicao) requisicaoProcessamento;

        assertThat(processamento.centroDeCusto())
                .isEqualTo("1234");

        assertThat(processamento.club())
                .isEqualTo("CLUB-01");

        assertThat(processamento.terminal())
                .isEqualTo(TERMINAL);

        assertThat(processamento.tipoPessoa())
                .isEqualTo("PJ");

        assertThat(processamento.Documento())
                .isEqualTo(CNPJ);

        /*
         * 2. Criação do documento de Pessoa Jurídica.
         */

        Object criarDocumentoPessoa = invocation.getArgument(5);

        var documentoPessoa = invocarCallback(
                criarDocumentoPessoa,
                request,
                ID_PROCESSAMENTO,
                CORRELATION_ID
        );

        assertThat(documentoPessoa)
                .isInstanceOf(DocumentosRelacionados.Documento.class);

        var documentoPJ =
                (DocumentosRelacionados.Documento) documentoPessoa;

        assertThat(documentoPJ.idProcessamento())
                .isEqualTo(ID_PROCESSAMENTO);

        assertThat(documentoPJ.correlationId())
                .isEqualTo(CORRELATION_ID);

        assertThat(documentoPJ.conteudo())
                .isInstanceOf(DocumentosRelacionados.PessoaJuridica.class);

        var pessoaJuridica =
                (DocumentosRelacionados.PessoaJuridica)
                        documentoPJ.conteudo();

        assertThat(pessoaJuridica.cnpj())
                .isEqualTo(CNPJ);

        assertThat(pessoaJuridica.periodicidade())
                .isEqualTo(Periodicidade.ANUAL.meses());

        assertThat(pessoaJuridica.anoReferencia())
                .isEqualTo(2026);

        assertThat(pessoaJuridica.valorFaturamentoDeclarado())
                .isEqualByComparingTo("500000.00");

        /*
         * 3. Execução da calibragem.
         */

        Object executarCalibragem = invocation.getArgument(6);

        var resultadoCalibragem = invocarCallback(
                executarCalibragem,
                request,
                TERMINAL,
                AUTORIZACAO
        );

        assertThat(resultadoCalibragem)
                .isInstanceOf(CalibragemPJResponse.class);

        var calibragem =
                (CalibragemPJResponse) resultadoCalibragem;

        var envio = org.mockito.ArgumentCaptor.forClass(
                CalibragemPJRequest.class);

        verify(calibragemPJPort).send(
                envio.capture(),
                eq(AUTORIZACAO)
        );

        assertThat(envio.getValue().cnpj())
                .isEqualTo(CNPJ);

        assertThat(envio.getValue().faturamentoAnual())
                .isEqualByComparingTo("500000.00");

        assertThat(envio.getValue().terminal())
                .isEqualTo(TERMINAL);

        /*
         * 4. Criação do documento de calibragem.
         */

        Object criarDocumentoResultado = invocation.getArgument(7);

        var documentoResultado = invocarCallback(
                criarDocumentoResultado,
                calibragem,
                ID_PROCESSAMENTO,
                CORRELATION_ID
        );

        assertThat(documentoResultado)
                .isInstanceOf(DocumentosRelacionados.Documento.class);

        var documentoCalibragem =
                (DocumentosRelacionados.Documento) documentoResultado;

        assertThat(documentoCalibragem.idProcessamento())
                .isEqualTo(ID_PROCESSAMENTO);

        assertThat(documentoCalibragem.correlationId())
                .isEqualTo(CORRELATION_ID);

        assertThat(documentoCalibragem.conteudo())
                .isEqualTo(
                        new DocumentosRelacionados.Calibragem(
                                calibragem.getValorEnquadrado(),
                                calibragem.identificadoFonte(),
                                calibragem.faturamentoReferencial(),
                                BigDecimal.ZERO,
                                calibragem.fonte(),
                                calibragem.periodicidade()
                        )
                );

        /*
         * 5. Tradução do resultado.
         */

        Object traduzirResultado = invocation.getArgument(8);

        var respostaTraduzida = invocarCallback(
                traduzirResultado,
                calibragem
        );

        assertThat(respostaTraduzida)
                .isInstanceOf(ValidaFinResponse.class);

        assertThat(((ValidaFinResponse) respostaTraduzida)
                .getResultadoAnalise())
                .isEqualTo(
                        ResultadoAnalise.APROVADO_SISTEMICAMENTE
                );

        return respostaTraduzida;
    }

    /**
     * Executa os callbacks funcionais.
     */
    private Object invocarCallback(
            Object callback,
            Object... argumentos) throws Throwable {

        assertThat(callback).isNotNull();

        Method metodo = null;

        for (Method method : callback.getClass().getMethods()) {

            if (method.getDeclaringClass() == Object.class) {
                continue;
            }

            if (method.getParameterCount() == argumentos.length) {
                metodo = method;
                break;
            }
        }

        assertThat(metodo)
                .as("Método funcional do callback")
                .isNotNull();

        try {

            return metodo.invoke(callback, argumentos);

        } catch (InvocationTargetException exception) {

            throw exception.getCause();
        }
    }

    /**
     * Valida o faturamento mensal declarado.
     */
    @Test
    void enviaFaturamentoMensalDeclaradoParaCalibragem() throws Throwable {

        var request = requisicao();

        request.setPeriodicidade(Periodicidade.MENSAL);

        request.setValorFaturamentoDeclarado(
                new BigDecimal("1000.00"));

        var calibragemMensal = new CalibragemPJResponse(
                "NAO",
                false,
                BigDecimal.ONE,
                "RECEITA",
                "MENSAL"
        );

        var respostaEsperada = ValidaFinResponse.builder()
                .resultadoAnalise(
                        ResultadoAnalise.SOLICITAR_COMPROVANTE)
                .build();

        when(calibragemPJPort.send(
                any(CalibragemPJRequest.class),
                eq(AUTORIZACAO)
        )).thenReturn(calibragemMensal);

        when(calibragemTranslator.translate(
                any(CalibragemPJResponse.class)
        )).thenReturn(respostaEsperada);

        when(analiseRendaService.executar(
                eq(request),
                eq(TERMINAL),
                eq(AUTORIZACAO),
                eq(TipoPessoa.PJ),
                any(),
                any(),
                any(),
                any(),
                any()
        )).thenAnswer(invocation -> {

            Object executarCalibragem = invocation.getArgument(6);

            var resultadoCalibragem = invocarCallback(
                    executarCalibragem,
                    request,
                    TERMINAL,
                    AUTORIZACAO
            );

            Object traduzirResultado = invocation.getArgument(8);

            return invocarCallback(
                    traduzirResultado,
                    resultadoCalibragem
            );
        });

        var resultado = useCase.executar(
                request,
                TERMINAL,
                AUTORIZACAO
        );

        assertThat(resultado)
                .isSameAs(respostaEsperada);

        assertThat(resultado.getResultadoAnalise())
                .isEqualTo(ResultadoAnalise.SOLICITAR_COMPROVANTE);

        var envio = org.mockito.ArgumentCaptor.forClass(
                CalibragemPJRequest.class);

        verify(calibragemPJPort).send(
                envio.capture(),
                eq(AUTORIZACAO)
        );

        assertThat(envio.getValue().cnpj())
                .isEqualTo(CNPJ);

        assertThat(envio.getValue().faturamentoAnual())
                .isEqualByComparingTo("1000.00");

        assertThat(envio.getValue().terminal())
                .isEqualTo(TERMINAL);

        verify(calibragemTranslator)
                .translate(any(CalibragemPJResponse.class));
    }
}
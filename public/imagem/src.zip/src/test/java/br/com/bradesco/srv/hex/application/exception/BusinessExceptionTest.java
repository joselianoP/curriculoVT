package br.com.bradesco.srv.hex.application.exception;

import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import br.com.bradesco.srv.hex.application.exception.BusinessErrorCode;
import br.com.bradesco.srv.hex.application.exception.BusinessException;

import static org.assertj.core.api.Assertions.assertThat;

class BusinessExceptionTest {

    @Nested
    class ConstructorWithAllStringParameters {

        @Test
        void shouldCreateExceptionWithAllStringParameters() {
            // Given
            String errorCode = "TEST_ERROR_001";
            String errorMessage = "Test error message";
            Throwable cause = new RuntimeException("Root cause");
            Object[] additionalDetails = {"detail1", "detail2", 123};

            // When
            BusinessException exception = new BusinessException(errorCode, errorMessage, cause, additionalDetails);

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).isEqualTo(errorCode);
            assertThat(exception.getErrorMessage()).isEqualTo(errorMessage);
            assertThat(exception.getCause()).isEqualTo(cause);
            assertThat(exception.getAdditionalDetails()).isEqualTo(additionalDetails);
        }
    }

    @Nested
    class ConstructorWithStringCodeMessageAndDetails {

        @Test
        void shouldCreateExceptionWithStringCodeMessageAndDetails() {
            // Given
            String errorCode = "TEST_ERROR_002";
            String errorMessage = "Test error message";
            Object[] additionalDetails = {"detail1", "detail2"};

            // When
            BusinessException exception = new BusinessException(errorCode, errorMessage, additionalDetails);

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).isEqualTo(errorCode);
            assertThat(exception.getErrorMessage()).isEqualTo(errorMessage);
            assertThat(exception.getCause()).isNull();
            assertThat(exception.getAdditionalDetails()).isEqualTo(additionalDetails);
        }
    }

    @Nested
    class ConstructorWithStringCodeMessageAndCause {

        @Test
        void shouldCreateExceptionWithStringCodeMessageAndCause() {
            // Given
            String errorCode = "TEST_ERROR_003";
            String errorMessage = "Test error message";
            Throwable cause = new IllegalArgumentException("Invalid argument");

            // When
            BusinessException exception = new BusinessException(errorCode, errorMessage, cause);

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).isEqualTo(errorCode);
            assertThat(exception.getErrorMessage()).isEqualTo(errorMessage);
            assertThat(exception.getCause()).isEqualTo(cause);
        }
    }

    @Nested
    class ConstructorWithErrorCodeAndDetails {

        @Test
        void shouldCreateExceptionWithErrorCodeAndDetails() {
            // Given
            BusinessErrorCode errorCode = BusinessErrorCode.DEPOSIT_NOT_FOUND;
            Object[] additionalDetails = {"depositId123", "accountId456"};

            // When
            BusinessException exception = new BusinessException(errorCode, additionalDetails);

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).isEqualTo(errorCode.getCode());
            assertThat(exception.getErrorMessage()).isEqualTo(errorCode.getMessage());
            assertThat(exception.getAdditionalDetails()).isEqualTo(additionalDetails);
            assertThat(exception.getCause()).isNull();
        }
    }

    @Nested
    class ConstructorWithErrorCodeAndCause {

        @Test
        void shouldCreateExceptionWithErrorCodeAndCause() {
            // Given
            BusinessErrorCode errorCode = BusinessErrorCode.WITHDRAWAL_CANNOT_EDIT;
            Throwable cause = new IllegalStateException("Invalid state");

            // When
            BusinessException exception = new BusinessException(errorCode, cause);

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).isEqualTo(errorCode.getCode());
            assertThat(exception.getErrorMessage()).isEqualTo(errorCode.getMessage());
            assertThat(exception.getCause()).isEqualTo(cause);
        }
    }

    @Nested
    class ConstructorWithErrorCodeOnly {

        @Test
        void shouldCreateExceptionWithErrorCodeOnly() {
            // Given
            BusinessErrorCode errorCode = BusinessErrorCode.DEPOSIT_CANNOT_CHANGE_STATUS;

            // When
            BusinessException exception = new BusinessException(errorCode);

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).isEqualTo(errorCode.getCode());
            assertThat(exception.getErrorMessage()).isEqualTo(errorCode.getMessage());
            assertThat(exception.getCause()).isNull();
        }
    }

    @Nested
    class SerializationTests {

        @Test
        void shouldHaveSerialVersionUID() {
            // Given
            BusinessException exception = new BusinessException(
                BusinessErrorCode.DEPOSIT_NOT_FOUND
            );

            // Then
            assertThat(exception).isInstanceOf(java.io.Serializable.class);
        }
    }

    @Nested
    class AllBusinessErrorCodesTests {

        @Test
        void shouldCreateExceptionWithDepositCannotEdit() {
            // When
            BusinessException exception = new BusinessException(BusinessErrorCode.DEPOSIT_CANNOT_EDIT);

            // Then
            assertThat(exception.getErrorCode()).isEqualTo("DEPOSIT_CANNOT_EDIT");
            assertThat(exception.getErrorMessage()).contains("Deposito nao pode ser editado");
        }

        @Test
        void shouldCreateExceptionWithDepositCannotChangeStatus() {
            // When
            BusinessException exception = new BusinessException(BusinessErrorCode.DEPOSIT_CANNOT_CHANGE_STATUS);

            // Then
            assertThat(exception.getErrorCode()).isEqualTo("DEPOSIT_CANNOT_CHANGE_STATUS");
            assertThat(exception.getErrorMessage()).contains("Nao e possivel alterar o status do deposito");
        }

        @Test
        void shouldCreateExceptionWithDepositNotFound() {
            // When
            BusinessException exception = new BusinessException(BusinessErrorCode.DEPOSIT_NOT_FOUND);

            // Then
            assertThat(exception.getErrorCode()).isEqualTo("DEPOSIT_NOT_FOUND");
            assertThat(exception.getErrorMessage()).contains("Deposito nao encontrado");
        }

        @Test
        void shouldCreateExceptionWithWithdrawalCannotEdit() {
            // When
            BusinessException exception = new BusinessException(BusinessErrorCode.WITHDRAWAL_CANNOT_EDIT);

            // Then
            assertThat(exception.getErrorCode()).isEqualTo("WITHDRAWAL_CANNOT_EDIT");
            assertThat(exception.getErrorMessage()).contains("Saque nao pode ser editado");
        }

        @Test
        void shouldCreateExceptionWithWithdrawalCannotChangeStatus() {
            // When
            BusinessException exception = new BusinessException(BusinessErrorCode.WITHDRAWAL_CANNOT_CHANGE_STATUS);

            // Then
            assertThat(exception.getErrorCode()).isEqualTo("WITHDRAWAL_CANNOT_CHANGE_STATUS");
            assertThat(exception.getErrorMessage()).contains("Nao e possivel alterar o status do saque");
        }

        @Test
        void shouldCreateExceptionWithWithdrawalNotFound() {
            // When
            BusinessException exception = new BusinessException(BusinessErrorCode.WITHDRAWAL_NOT_FOUND);

            // Then
            assertThat(exception.getErrorCode()).isEqualTo("WITHDRAWAL_NOT_FOUND");
            assertThat(exception.getErrorMessage()).contains("Saque nao encontrado");
        }
    }

    @Nested
    class AdditionalDetailsHandling {

        @Test
        void shouldHandleEmptyAdditionalDetails() {
            // Given
            String errorCode = "TEST_ERROR";
            String errorMessage = "Test message";
            Object[] additionalDetails = {};

            // When
            BusinessException exception = new BusinessException(errorCode, errorMessage, additionalDetails);

            // Then
            assertThat(exception.getAdditionalDetails()).isNotNull();
            assertThat(exception.getAdditionalDetails()).isEmpty();
        }

        @Test
        void shouldHandleNullAdditionalDetails() {
            // Given
            String errorCode = "TEST_ERROR";
            String errorMessage = "Test message";
            Object[] additionalDetails = null;

            // When
            BusinessException exception = new BusinessException(errorCode, errorMessage, additionalDetails);

            // Then
            assertThat(exception.getAdditionalDetails()).isEmpty();
        }

        @Test
        void shouldHandleMixedTypeAdditionalDetails() {
            // Given
            Object[] additionalDetails = {
                "stringValue",
                123,
                45.67,
                true,
                new Object()
            };

            // When
            BusinessException exception = new BusinessException(
                BusinessErrorCode.DEPOSIT_NOT_FOUND,
                additionalDetails
            );

            // Then
            assertThat(exception.getAdditionalDetails()).hasSize(5);
            assertThat(exception.getAdditionalDetails()[0]).isEqualTo("stringValue");
            assertThat(exception.getAdditionalDetails()[1]).isEqualTo(123);
            assertThat(exception.getAdditionalDetails()[2]).isEqualTo(45.67);
            assertThat(exception.getAdditionalDetails()[3]).isEqualTo(true);
        }
    }

    @Nested
    class CauseHandling {

        @Test
        void shouldHandleNullPointerExceptionAsCause() {
            // Given
            NullPointerException cause = new NullPointerException("Null value detected");

            // When
            BusinessException exception = new BusinessException(
                BusinessErrorCode.DEPOSIT_CANNOT_EDIT,
                cause
            );

            // Then
            assertThat(exception.getCause()).isInstanceOf(NullPointerException.class);
            assertThat(exception.getCause().getMessage()).isEqualTo("Null value detected");
        }

        @Test
        void shouldHandleIllegalArgumentExceptionAsCause() {
            // Given
            IllegalArgumentException cause = new IllegalArgumentException("Invalid argument");

            // When
            BusinessException exception = new BusinessException(
                "CUSTOM_ERROR",
                "Custom message",
                cause
            );

            // Then
            assertThat(exception.getCause()).isInstanceOf(IllegalArgumentException.class);
        }

        @Test
        void shouldHandleCauseChain() {
            // Given
            Throwable rootCause = new Exception("Root");
            Throwable intermediateCause = new RuntimeException("Intermediate", rootCause);

            // When
            BusinessException exception = new BusinessException(
                "ERROR_CODE",
                "Error message",
                intermediateCause,
                new Object[]{"detail"}
            );

            // Then
            assertThat(exception.getCause()).isEqualTo(intermediateCause);
            assertThat(exception.getCause().getCause()).isEqualTo(rootCause);
        }
    }

    @Nested
    class ExceptionBehavior {

        @Test
        void shouldBeThrowableAsRuntimeException() {
            // Given
            BusinessException exception = new BusinessException(BusinessErrorCode.DEPOSIT_NOT_FOUND);

            // Then
            assertThat(exception)
                .isInstanceOf(RuntimeException.class)
                .isInstanceOf(Exception.class)
                .isInstanceOf(Throwable.class);
        }

    }

}

package br.com.bradesco.srv.hex.adapter.in.api.rest.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.math.BigDecimal;
import java.util.UUID;

import org.junit.jupiter.api.Test;

import br.com.bradesco.srv.hex.adapter.in.api.rest.dto.DadosControleDto;
import br.com.bradesco.srv.hex.adapter.in.api.rest.dto.DadosPFRequestDto;
import br.com.bradesco.srv.hex.adapter.in.api.rest.dto.DadosPJRequestDto;
import br.com.bradesco.srv.hex.adapter.in.api.rest.dto.ValidaFinResponseDto;
import br.com.bradesco.srv.hex.application.model.ValidaFinResponse;
import br.com.bradesco.srv.hex.util.enumerator.Periodicidade;
import br.com.bradesco.srv.hex.util.enumerator.ResultadoAnalise;

class ValidaFindMapperImplCoverageTest {
    private final ValidaFindMapperImpl mapper = new ValidaFindMapperImpl();

    @Test void converteRequestPessoaFisica() {
        var domain = mapper.toDomainPF(new DadosPFRequestDto(new DadosControleDto("CC001", "CLUB001"), "PF", "12345678901", BigDecimal.TEN));
        assertEquals("12345678901", domain.getCpf());
        assertEquals(BigDecimal.TEN, domain.getValorRendaMensalDeclarada());
    }

    @Test void converteRequestPessoaJuridica() {
        var domain = mapper.toDomainPJ(new DadosPJRequestDto(new DadosControleDto("CC001", "CLUB001"), "12345678000199", Periodicidade.ANUAL, 2025, BigDecimal.valueOf(200)));
        assertEquals("12345678000199", domain.getCnpj());
        assertEquals(BigDecimal.valueOf(200), domain.getValorFaturamentoDeclarado());
        assertEquals(Periodicidade.ANUAL, domain.getPeriodicidade());
        assertEquals(2025, domain.getAnoReferencia());
    }

    @Test void converteRespostaComId() {
        String id = UUID.randomUUID().toString();
        ValidaFinResponse response = new ValidaFinResponse(ResultadoAnalise.APROVADO_SISTEMICAMENTE, id, 1, "ok");
        ValidaFinResponseDto dto = mapper.toResponseDto(response);
        assertEquals(id, dto.idAnalise());
        assertEquals(ResultadoAnalise.APROVADO_SISTEMICAMENTE, dto.resultadoAnalise());
        assertEquals(1, dto.statusComprovacao());
        assertEquals("ok", dto.mensagem());
    }

}

package br.com.bradesco.srv.hex.application.usecase;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import br.com.bradesco.srv.hex.application.exception.InvalidInputException;
import br.com.bradesco.srv.hex.application.port.out.mongo.ConsultaDocumentosMongoPort;

class ConsultarDocumentosMongoUseCaseImplTest {

    private final ConsultaDocumentosMongoPort port = mock(ConsultaDocumentosMongoPort.class);
    private final ConsultarDocumentosMongoUseCaseImpl useCase = new ConsultarDocumentosMongoUseCaseImpl(port);

    @Test
    void deveConsultarDocumentosECalcularTotal() {
        String correlationId = "correlation-123";
        Map<String, List<Map<String, Object>>> collections = Map.of(
                "validaFinDocument", List.of(Map.of("_id", "1")),
                "pessoaFisica", List.of(Map.of("cpf", "123"), Map.of("cpf", "456")));
        when(port.buscarPorCorrelationId(correlationId)).thenReturn(collections);

        var resultado = useCase.executar(correlationId);

        assertThat(resultado.correlationId()).isEqualTo(correlationId);
        assertThat(resultado.totalDocumentos()).isEqualTo(3);
        assertThat(resultado.collections()).isEqualTo(collections);
        verify(port).buscarPorCorrelationId(correlationId);
    }

    @Test
    void deveRejeitarCorrelationIdEmBranco() {
        assertThatThrownBy(() -> useCase.executar(" "))
                .isInstanceOf(InvalidInputException.class);
    }
}

package br.com.bradesco.srv.hex.adapter.in.api.rest.mapper;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;

import br.com.bradesco.srv.hex.adapter.in.api.rest.dto.DadosControleDto;
import br.com.bradesco.srv.hex.adapter.in.api.rest.dto.DadosPFRequestDto;
import br.com.bradesco.srv.hex.adapter.in.api.rest.dto.DadosPJRequestDto;
import br.com.bradesco.srv.hex.application.model.DadosPFRequest;
import br.com.bradesco.srv.hex.application.model.DadosPJRequest;
import br.com.bradesco.srv.hex.application.model.ValidaFinResponse;
import br.com.bradesco.srv.hex.util.enumerator.Periodicidade;
import br.com.bradesco.srv.hex.util.enumerator.ResultadoAnalise;

class ValidaFindMapperTest {

    private final ValidaFindMapper mapper = new ValidaFindMapperImpl();
    private final DadosControleDto control = new DadosControleDto("CC001", "CLUB001");

    @Test
    void shouldMapPfDtoToDomain() {
        var dto = new DadosPFRequestDto(control, "PF", "52998224725", new BigDecimal("5500.00"));

        DadosPFRequest result = mapper.toDomainPF(dto);

        assertThat(result.getCpf()).isEqualTo("52998224725");
        assertThat(result.getValorRendaMensalDeclarada()).isEqualByComparingTo("5500.00");
    }

    @Test
    void shouldMapPjDtoToDomain() {
        var dto = new DadosPJRequestDto(control, "11222333000181", Periodicidade.TRIMESTRAL, 2024,
                new BigDecimal("250000.00"));

        DadosPJRequest result = mapper.toDomainPJ(dto);

        assertThat(result.getCnpj()).isEqualTo("11222333000181");
        assertThat(result.getPeriodicidade()).isEqualTo(Periodicidade.TRIMESTRAL);
        assertThat(result.getValorFaturamentoDeclarado()).isEqualByComparingTo("250000.00");
    }

    @Test
    void shouldMapApplicationResponseToRestDto() {
        var response = ValidaFinResponse.builder()
                .resultadoAnalise(ResultadoAnalise.APROVADO_SISTEMICAMENTE)
                .idAnalise("id-1")
                .statusComprovacao(1)
                .mensagem("ok")
                .build();

        var result = mapper.toResponseDto(response);

        assertThat(result.resultadoAnalise()).isEqualTo(ResultadoAnalise.APROVADO_SISTEMICAMENTE);
        assertThat(result.statusComprovacao()).isEqualTo(1);
        assertThat(result.mensagem()).isEqualTo("ok");
        assertThat(result.idAnalise()).isEqualTo("id-1");
    }
}
package br.com.bradesco.srv.hex.adapter.in.api.config;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;

class SwaggerConfigTest {
    private SwaggerConfig config() {
        return new SwaggerConfig("Processamento API", "Documentação de testes", "1.0.0",
                "https://docs.example.test", "/swagger", "/swagger-ui/index.html");
    }

    @Test void customOpenApiConfiguraInformacoesSegurancaEDocumentacao() {
        var api = config().customOpenAPI();
        assertEquals("Processamento API", api.getInfo().getTitle());
        assertEquals("Documentação de testes", api.getInfo().getDescription());
        assertEquals("1.0.0", api.getInfo().getVersion());
        assertEquals("https://docs.example.test", api.getExternalDocs().getUrl());
        assertEquals("bearer", api.getComponents().getSecuritySchemes().get("bearerAuth").getScheme());
        assertEquals("JWT", api.getComponents().getSecuritySchemes().get("bearerAuth").getBearerFormat());
        assertFalse(api.getSecurity().isEmpty());
    }

    @Test void apiV1ConfiguraGrupoEPath() {
        GroupedOpenApi api = config().apiV1();
        assertEquals("v1", api.getGroup());
        assertEquals("Versão 1", api.getDisplayName());
        assertEquals(java.util.List.of("/v1/**"), api.getPathsToMatch());
    }

    @Test void apiV2ConfiguraGrupoEPath() {
        GroupedOpenApi api = config().apiV2();
        assertEquals("v2", api.getGroup());
        assertEquals("Versão 2", api.getDisplayName());
        assertEquals(java.util.List.of("/v2/**"), api.getPathsToMatch());
    }

    @Test void registraEncaminhamentoDoSwagger() {
        ViewControllerRegistry registry = mock(ViewControllerRegistry.class);
        ViewControllerRegistration registration = mock(ViewControllerRegistration.class);
        when(registry.addViewController("/swagger")).thenReturn(registration);
        config().addViewControllers(registry);
        verify(registry).addViewController("/swagger");
        verify(registration).setViewName("forward:/swagger-ui/index.html");
    }
}

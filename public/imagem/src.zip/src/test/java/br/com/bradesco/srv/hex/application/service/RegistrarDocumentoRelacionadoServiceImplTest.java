package br.com.bradesco.srv.hex.application.service;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

import java.math.BigDecimal;
import java.time.Instant;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

import br.com.bradesco.srv.hex.application.model.DocumentosRelacionados;
import br.com.bradesco.srv.hex.application.port.out.mongo.DocumentosRelacionadosRepositoryPort;

class RegistrarDocumentoRelacionadoServiceImplTest {

    private final DocumentosRelacionadosRepositoryPort repositorio =
            mock(DocumentosRelacionadosRepositoryPort.class);

    private final RegistrarDocumentoRelacionadoServiceImpl servico =
            new RegistrarDocumentoRelacionadoServiceImpl(repositorio);

    private static DocumentosRelacionados.Documento documento(
            String idProcessamento,
            String correlationId,
            DocumentosRelacionados.Conteudo conteudo) {
        return new DocumentosRelacionados.Documento(
                null, idProcessamento, correlationId, Instant.now(), conteudo);
    }

    private static DocumentosRelacionados.Conteudo conteudoPadrao() {
        return new DocumentosRelacionados.PessoaFisica("12345678901", new BigDecimal("5000.00"));
    }

    @Test
    void rejeitaRepositorioNulo() {
        assertThatThrownBy(() -> new RegistrarDocumentoRelacionadoServiceImpl(null))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("Repository de documentos relacionados obrigatório");
    }

    @Test
    void salvaDocumentoValido() {
        var documento = documento("id-1", "correlacao-1", conteudoPadrao());

        servico.executar(documento);

        verify(repositorio).salvar(documento);
    }

    @Test
    void rejeitaDocumentoNulo() {
        assertThatThrownBy(() -> servico.executar(null))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("Documento relacionado obrigatório");

        verifyNoInteractions(repositorio);
    }

    @Test
    void rejeitaDocumentoSemConteudo() {
        assertThatThrownBy(() -> servico.executar(documento("id-1", "correlacao-1", null)))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("Documento relacionado obrigatório");

        verifyNoInteractions(repositorio);
    }

    @ParameterizedTest
    @NullAndEmptySource
    @ValueSource(strings = {" "})
    void rejeitaIdProcessamentoAusente(String idProcessamento) {
        assertThatThrownBy(() -> servico.executar(documento(idProcessamento, "correlacao-1", conteudoPadrao())))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("idProcessamento obrigatório");

        verifyNoInteractions(repositorio);
    }

    @ParameterizedTest
    @NullAndEmptySource
    @ValueSource(strings = {" "})
    void rejeitaCorrelationIdAusente(String correlationId) {
        assertThatThrownBy(() -> servico.executar(documento("id-1", correlationId, conteudoPadrao())))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("correlationId obrigatório");

        verifyNoInteractions(repositorio);
    }
}

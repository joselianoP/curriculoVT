package br.com.bradesco.srv.hex.application.exception;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class BusinessValidationExceptionTest {

    @Test
    void shouldCreateWithoutFields() {
        var ex = new BusinessValidationException("400", "message", "details");

        assertThat(ex.getCodigo()).isEqualTo("400");
        assertThat(ex.getMessage()).isEqualTo("message");
        assertThat(ex.getDetalhes()).isEqualTo("details");
        assertThat(ex.getCampos()).isEmpty();
    }

    @Test
    void shouldCopyFieldsDefensively() {
        var fields = new ArrayList<>(List.of(new ValidationFieldException("a", "b")));

        var ex = new BusinessValidationException("400", "message", "details", fields);
        fields.clear();

        assertThat(ex.getCampos()).hasSize(1);
        assertThat(ex.getCampos().get(0).nome()).isEqualTo("a");
        assertThat(ex.getCampos().get(0).motivo()).isEqualTo("b");
        var returnedFields = ex.getCampos();
        assertThatThrownBy(returnedFields::clear).isInstanceOf(UnsupportedOperationException.class);
    }

    @Test
    void shouldAcceptNullFields() {
        var ex = new BusinessValidationException("400", "message", "details", null);

        assertThat(ex.getCampos()).isEmpty();
    }
}
package br.com.bradesco.srv.hex.adapter.in.api.config;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;

import org.junit.jupiter.api.Test;
import org.springframework.boot.jackson.autoconfigure.JacksonProperties;

import tools.jackson.databind.json.JsonMapper;

class JsonConfigTest {

    @Test
    void shouldCustomizeDateSerializersWithDefaultFormat() {
        var builder = JsonMapper.builder();

        new JsonConfig().jsonDateTimeCustomizer(new JacksonProperties()).customize(builder);
        var json = builder.build().writeValueAsString(LocalDateTime.of(2024, 1, 2, 3, 4, 5));

        assertThat(json).contains("2024");
    }

    @Test
    void shouldCustomizeDateSerializersWithConfiguredFormat() {
        var properties = new JacksonProperties();
        properties.setDateFormat("yyyy-MM-dd HH:mm");
        var builder = JsonMapper.builder();

        new JsonConfig().jsonDateTimeCustomizer(properties).customize(builder);
        var mapper = builder.build();

        assertThat(mapper.writeValueAsString(LocalDateTime.of(2024, 1, 2, 3, 4, 5)))
                .isEqualTo("\"2024-01-02 03:04\"");
        assertThat(mapper.writeValueAsString(ZonedDateTime.of(2024, 1, 2, 3, 4, 5, 0, ZoneOffset.UTC)))
                .isEqualTo("\"2024-01-02 03:04Z\"");
    }
}
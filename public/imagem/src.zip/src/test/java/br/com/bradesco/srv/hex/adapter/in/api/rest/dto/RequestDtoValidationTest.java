package br.com.bradesco.srv.hex.adapter.in.api.rest.dto;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import br.com.bradesco.srv.hex.util.enumerator.Periodicidade;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;

/**
 * Os DTOs de entrada não possuem mais Bean Validation: a validação dos dados
 * é delegada à Calibragem, que devolve o erro de entrada correspondente.
 */
class RequestDtoValidationTest {
    private static ValidatorFactory factory;
    private static Validator validator;
    @BeforeAll static void initValidator() { factory = Validation.buildDefaultValidatorFactory(); validator = factory.getValidator(); }
    @AfterAll static void closeValidator() { factory.close(); }

    @Test void pfValidoNaoPossuiViolacoes() {
        var dto = new DadosPFRequestDto(new DadosControleDto("CC001", "CLUB001"), "PF", "12345678901", new BigDecimal("5000"));
        assertTrue(validator.validate(dto).isEmpty());
    }
    @Test void pfComCamposVaziosNaoEhRejeitadoPeloDto() {
        var dto = new DadosPFRequestDto(new DadosControleDto("", ""), "PJ", "", BigDecimal.ZERO);
        assertTrue(validator.validate(dto).isEmpty());
    }
    @Test void pjValidoNaoPossuiViolacoes() {
        var dto = new DadosPJRequestDto(new DadosControleDto("CC001", "CLUB001"), "12345678000199", Periodicidade.MENSAL, 2025, new BigDecimal("10000"));
        assertTrue(validator.validate(dto).isEmpty());
    }
    @Test void pjComCamposVaziosEForaDoIntervaloNaoEhRejeitadoPeloDto() {
        var dto = new DadosPJRequestDto(new DadosControleDto("", ""), "", null, 1999, BigDecimal.ZERO);
        assertTrue(validator.validate(dto).isEmpty());
    }
    @Test void controleComStringsVaziasNaoEhRejeitado() {
        assertTrue(validator.validate(new DadosControleDto(" ", "")).isEmpty());
    }
}
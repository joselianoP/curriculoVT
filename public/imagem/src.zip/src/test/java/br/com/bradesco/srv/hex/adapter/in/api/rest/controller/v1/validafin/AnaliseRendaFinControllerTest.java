package br.com.bradesco.srv.hex.adapter.in.api.rest.controller.v1.validafin;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.slf4j.MDC;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
 
import br.com.bradesco.srv.hex.adapter.in.api.rest.handler.ApplicationExceptionHandler;
import br.com.bradesco.srv.hex.adapter.in.api.rest.mapper.ValidaFindMapper;
import br.com.bradesco.srv.hex.adapter.in.api.rest.mapper.ValidaFindMapperImpl;
import br.com.bradesco.srv.hex.application.exception.BusinessException;
import br.com.bradesco.srv.hex.application.exception.InvalidInputException;
import br.com.bradesco.srv.hex.application.exception.InfrastructureException;
import br.com.bradesco.srv.hex.application.exception.ServiceUnavailableException;
import br.com.bradesco.srv.hex.application.model.ValidaFinResponse;
import br.com.bradesco.srv.hex.application.port.in.validafin.AnaliseRendaPFUseCase;
import br.com.bradesco.srv.hex.application.port.in.validafin.AnaliseRendaPJUseCase;
import br.com.bradesco.srv.hex.util.ConstantsUtil;
import br.com.bradesco.srv.hex.util.enumerator.ResultadoAnalise;

class AnaliseRendaFinControllerTest {

    private static final String TERMINAL = "VLDFINDSKATL";
    private static final String AUTHORIZATION = "Bearer test-token";
    private static final String CORRELATION_ID = "test-correlation-id";
    private static final String PF_URL = "/v1/analise-renda-pf";
    private static final String PJ_URL = "/v1/analise-faturamento-pj";

    private static final String VALID_PF = """
            {"controle":{"centroDeCusto":"CC001","club":"CLUB001"},
             "tipoPessoa":"PF","cpf":"52998224725","valorRendaMensalDeclarada":5500.00}
            """;
    private static final String VALID_PJ = """
            {"controle":{"centroDeCusto":"CC001","club":"CLUB001"},
             "cnpj":"11222333000181","periodicidade":4,"anoReferencia":2024,"valorFaturamentoDeclarado":100000.00}
            """;

    private final AnaliseRendaPFUseCase pfUseCase = mock(AnaliseRendaPFUseCase.class);
    private final AnaliseRendaPJUseCase pjUseCase = mock(AnaliseRendaPJUseCase.class);
    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        var validator = new LocalValidatorFactoryBean();
        validator.afterPropertiesSet();
        ValidaFindMapper mapper = new ValidaFindMapperImpl();
        var controller = new AnaliseRendaFinController(mapper, pfUseCase, pjUseCase);
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new ApplicationExceptionHandler())
                .setValidator(validator)
                .build();
    }

    @AfterEach
    void limparMdc() {
        MDC.clear();
    }

    private static ValidaFinResponse response(ResultadoAnalise result) {
        return ValidaFinResponse.builder().resultadoAnalise(result).idAnalise("id-analise-1").statusComprovacao(2).mensagem("mensagem").build();
    }

    private static MockHttpServletRequestBuilder request(String path) {
        return post(path)
                .header("terminal", TERMINAL)
                .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION)
                .header("correlation-Id", CORRELATION_ID);
    }

    @Test
    void shouldReturnOkForPfWhenProofIsRequired() throws Exception {
        when(pfUseCase.executar(any(), eq(TERMINAL), eq(AUTHORIZATION))).thenAnswer(invocation -> {
            assertThat(MDC.get(ConstantsUtil.COORELATION_ID)).isEqualTo(CORRELATION_ID);
            return response(ResultadoAnalise.SOLICITAR_COMPROVANTE);
        });

        mockMvc.perform(request(PF_URL).contentType(MediaType.APPLICATION_JSON).content(VALID_PF))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.resultadoAnalise").value("SOLICITAR_COMPROVANTE"))
                .andExpect(jsonPath("$.idAnalise").value("id-analise-1"));

        verify(pfUseCase).executar(any(), eq(TERMINAL), eq(AUTHORIZATION));
        assertThat(MDC.get(ConstantsUtil.COORELATION_ID)).isEqualTo(CORRELATION_ID);
    }

    @ParameterizedTest
    @ValueSource(strings = {"pf", "XX", "PJ"})
    void shouldAcceptTipoPessoaWithoutBeanValidation(String tipoPessoa) throws Exception {
        when(pfUseCase.executar(any(), eq(TERMINAL), eq(AUTHORIZATION)))
                .thenReturn(response(ResultadoAnalise.SOLICITAR_COMPROVANTE));

        mockMvc.perform(request(PF_URL).contentType(MediaType.APPLICATION_JSON)
                        .content(VALID_PF.replace("\"PF\"", "\"" + tipoPessoa + "\"")))
                .andExpect(status().isOk());

        verify(pfUseCase).executar(any(), eq(TERMINAL), eq(AUTHORIZATION));
    }

    @Test
    void shouldReturnOkForPjWhenApproved() throws Exception {
        when(pjUseCase.executar(any(), eq(TERMINAL), eq(AUTHORIZATION))).thenAnswer(invocation -> {
            assertThat(MDC.get(ConstantsUtil.COORELATION_ID)).isEqualTo(CORRELATION_ID);
            return response(ResultadoAnalise.APROVADO_SISTEMICAMENTE);
        });

        mockMvc.perform(request(PJ_URL).contentType(MediaType.APPLICATION_JSON).content(VALID_PJ))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.resultadoAnalise").value("APROVADO_SISTEMICAMENTE"))
                .andExpect(jsonPath("$.idAnalise").value("id-analise-1"));

        verify(pjUseCase).executar(any(), eq(TERMINAL), eq(AUTHORIZATION));
        assertThat(MDC.get(ConstantsUtil.COORELATION_ID)).isEqualTo(CORRELATION_ID);
    }

    @ParameterizedTest
    @ValueSource(ints = {1999, 10000})
    void shouldAcceptAnoReferenciaOutsideFormerBounds(int year) throws Exception {
        when(pjUseCase.executar(any(), eq(TERMINAL), eq(AUTHORIZATION)))
                .thenReturn(response(ResultadoAnalise.APROVADO_SISTEMICAMENTE));

        mockMvc.perform(request(PJ_URL).contentType(MediaType.APPLICATION_JSON)
                        .content(VALID_PJ.replace("2024", Integer.toString(year))))
                .andExpect(status().isOk());
    }

    @Test
    void shouldAcceptMissingAndBlankFieldsWithoutBeanValidation() throws Exception {
        when(pfUseCase.executar(any(), eq(TERMINAL), eq(AUTHORIZATION)))
                .thenReturn(response(ResultadoAnalise.SOLICITAR_COMPROVANTE));

        String requestWithBlankControl = """
                {"controle":{"centroDeCusto":"","club":""}}
                """;

        mockMvc.perform(request(PF_URL).contentType(MediaType.APPLICATION_JSON).content(requestWithBlankControl))
                .andExpect(status().isOk());

        verify(pfUseCase).executar(any(), eq(TERMINAL), eq(AUTHORIZATION));
    }

    @Test
    void shouldMapBusinessExceptionTo422() throws Exception {
        when(pfUseCase.executar(any(), any(), any()))
                .thenThrow(new BusinessException("ROUTE-002", "CPF invalido"));

        mockMvc.perform(request(PF_URL).contentType(MediaType.APPLICATION_JSON).content(VALID_PF))
                .andExpect(status().is(422));
    }

    @Test
    void shouldMapInvalidInputExceptionTo400AndPreserveCalibrationDetail() throws Exception {
        when(pfUseCase.executar(any(), any(), any()))
                .thenThrow(new InvalidInputException("calibragem", "send", "CPF informado é inválido"));

        mockMvc.perform(request(PF_URL).contentType(MediaType.APPLICATION_JSON).content(VALID_PF))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.erro.codigo").value("400"))
                .andExpect(jsonPath("$.erro.detalhes").value("Dados informados inválidos."))
                .andExpect(jsonPath("$.erro.correlationId").value(CORRELATION_ID));
    }

 

    @Test
    void shouldMapServiceUnavailableExceptionTo503() throws Exception {
        when(pfUseCase.executar(any(), any(), any()))
                .thenThrow(new ServiceUnavailableException("ROUTE-003", "indisponivel"));

        mockMvc.perform(request(PF_URL).contentType(MediaType.APPLICATION_JSON).content(VALID_PF))
                .andExpect(status().isServiceUnavailable())
                .andExpect(jsonPath("$.erro.codigo").value("503"))
                .andExpect(jsonPath("$.erro.mensagem").value("Serviço indisponível"))
                .andExpect(jsonPath("$.erro.detalhes").value("Serviço temporariamente indisponível."))
                .andExpect(jsonPath("$.erro.correlationId").value(CORRELATION_ID));
    }

    @Test
    void shouldRejectMissingAuthorizationHeader() throws Exception {
        mockMvc.perform(post(PF_URL)
                .header(ConstantsUtil.TERMINAL_HEADER, TERMINAL)
                .header(ConstantsUtil.COORELATION_ID, CORRELATION_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(VALID_PF))
                .andExpect(status().isBadRequest());

        verifyNoInteractions(pfUseCase);
    }

    @Test
    void shouldRejectMissingCorrelationIdHeader() throws Exception {
        mockMvc.perform(post(PF_URL)
                .header(ConstantsUtil.TERMINAL_HEADER, TERMINAL)
                .header("Authorization", AUTHORIZATION)
                .contentType(MediaType.APPLICATION_JSON)
                .content(VALID_PF))
                .andExpect(status().isBadRequest());

        verifyNoInteractions(pfUseCase);
    }
}

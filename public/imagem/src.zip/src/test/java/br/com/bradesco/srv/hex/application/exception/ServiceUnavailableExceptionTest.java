package br.com.bradesco.srv.hex.application.exception;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

@DisplayName("ServiceUnavailableException Unit Tests - Target Constructors Only")
class ServiceUnavailableExceptionTest {

    @Nested
    @DisplayName("Constructor: ServiceUnavailableException(String, String)")
    class ConstructorWithCodeAndMessage {

        @Test
        @DisplayName("Should create exception with code and message")
        void shouldCreateExceptionWithCodeAndMessage() {
            // Given
            String code = "SERVICE_ERROR_001";
            String message = "Database service is temporarily unavailable";

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(code, message);

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).isEqualTo(code);
            assertThat(exception.getErrorMessage()).isEqualTo(message);
            assertThat(exception.getMessage()).isEqualTo(message);
            assertThat(exception.getCause()).isNull();
        }

        @Test
        @DisplayName("Should handle empty code")
        void shouldHandleEmptyCode() {
            // Given
            String code = "";
            String message = "Service unavailable";

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(code, message);

            // Then
            assertThat(exception.getErrorCode()).isEmpty();
            assertThat(exception.getErrorMessage()).isEqualTo(message);
        }

        @Test
        @DisplayName("Should handle empty message")
        void shouldHandleEmptyMessage() {
            // Given
            String code = "ERROR_CODE";
            String message = "";

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(code, message);

            // Then
            assertThat(exception.getErrorCode()).isEqualTo(code);
            assertThat(exception.getErrorMessage()).isEmpty();
        }

        @Test
        @DisplayName("Should handle whitespace message")
        void shouldHandleWhitespaceMessage() {
            // Given
            String code = "ERROR_CODE";
            String message = "   ";

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(code, message);

            // Then
            assertThat(exception.getErrorMessage()).isEqualTo("   ");
        }

        @Test
        @DisplayName("Should handle very long error code")
        void shouldHandleVeryLongErrorCode() {
            // Given
            String code = "SERVICE_ERROR_".repeat(100);
            String message = "Service unavailable";

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(code, message);

            // Then
            assertThat(exception.getErrorCode()).hasSize(code.length());
            assertThat(exception.getErrorCode()).startsWith("SERVICE_ERROR_");
        }

        @Test
        @DisplayName("Should handle very long message")
        void shouldHandleVeryLongMessage() {
            // Given
            String code = "ERROR_CODE";
            String message = "This is a very long error message describing service unavailability. ".repeat(50);

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(code, message);

            // Then
            assertThat(exception.getErrorMessage()).contains("service unavailability");
            assertThat(exception.getErrorMessage().length()).isGreaterThan(1000);
        }

        @Test
        @DisplayName("Should handle special characters in code")
        void shouldHandleSpecialCharactersInCode() {
            // Given
            String code = "ERROR@#$%^&*()_+-=[]{}|;:',.<>?/`~";
            String message = "Service unavailable";

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(code, message);

            // Then
            assertThat(exception.getErrorCode()).isEqualTo(code);
        }

        @Test
        @DisplayName("Should handle special characters in message")
        void shouldHandleSpecialCharactersInMessage() {
            // Given
            String code = "ERROR_CODE";
            String message = "Error: Service @#$%^&*() is unavailable!";

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(code, message);

            // Then
            assertThat(exception.getErrorMessage()).isEqualTo(message);
        }

        @Test
        @DisplayName("Should handle Unicode characters in message")
        void shouldHandleUnicodeCharactersInMessage() {
            // Given
            String code = "ERROR_CODE";
            String message = "Serviço indisponível: ç, á, é, í, ó, ú, ã, õ, ñ, ü, €, £, ¥";

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(code, message);

            // Then
            assertThat(exception.getErrorMessage()).isEqualTo(message);
        }

        @Test
        @DisplayName("Should preserve stack trace")
        void shouldPreserveStackTrace() {
            // Given
            String code = "ERROR_CODE";
            String message = "Service unavailable";

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(code, message);

            // Then
            assertThat(exception.getStackTrace()).isNotNull();
            assertThat(exception.getStackTrace()).isNotEmpty();
        }

        @Test
        @DisplayName("Should be throwable and catchable")
        void shouldBeThrowableAndCatchable() {
            // Given
            String code = "TEST_ERROR";
            String message = "Test service unavailable";

            // When/Then
            try {
                throw new ServiceUnavailableException(code, message);
            } catch (ServiceUnavailableException e) {
                assertThat(e.getErrorCode()).isEqualTo(code);
                assertThat(e.getErrorMessage()).isEqualTo(message);
            }
        }

        @Test
        @DisplayName("Should be instance of expected exception hierarchy")
        void shouldBeInstanceOfExpectedExceptionHierarchy() {
            // Given
            ServiceUnavailableException exception = new ServiceUnavailableException("CODE", "Message");

            // Then
            assertThat(exception).isInstanceOf(RuntimeException.class);
            assertThat(exception).isInstanceOf(Exception.class);
            assertThat(exception).isInstanceOf(Throwable.class);
        }

        @Test
        @DisplayName("Should create exception for typical database scenario")
        void shouldCreateExceptionForTypicalDatabaseScenario() {
            // Given
            String code = "DB_SERVICE_UNAVAILABLE";
            String message = "Database connection pool exhausted. All connections are in use.";

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(code, message);

            // Then
            assertThat(exception.getErrorCode()).isEqualTo(code);
            assertThat(exception.getErrorMessage()).contains("Database connection pool");
        }

        @Test
        @DisplayName("Should create exception for typical API scenario")
        void shouldCreateExceptionForTypicalApiScenario() {
            // Given
            String code = "API_SERVICE_UNAVAILABLE";
            String message = "External payment API is temporarily unavailable. Please retry later.";

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(code, message);

            // Then
            assertThat(exception.getErrorCode()).isEqualTo(code);
            assertThat(exception.getErrorMessage()).contains("payment API");
        }
    }

    @Nested
    @DisplayName("Constructor: ServiceUnavailableException(Throwable)")
    class ConstructorWithCauseOnly {

        @Test
        @DisplayName("Should create exception with cause and add moreInfo")
        void shouldCreateExceptionWithCauseAndAddMoreInfo() {
            // Given
            Throwable cause = new RuntimeException("Redis connection timeout");

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(cause);

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).isEqualTo(InfraErrorCode.SERVICE_UNAVAILABLE.getCode());
            assertThat(exception.getErrorMessage()).isEqualTo(InfraErrorCode.SERVICE_UNAVAILABLE.getMessage());
            assertThat(exception.getCause()).isEqualTo(cause);
            assertThat(exception.getMoreInfos()).isNotNull();
            assertThat(exception.getMoreInfos()).containsKey("causedBy");
            assertThat(exception.getMoreInfos().get("causedBy")).isEqualTo("Redis connection timeout");
        }

        @Test
        @DisplayName("Should use SERVICE_UNAVAILABLE error code")
        void shouldUseServiceUnavailableErrorCode() {
            // Given
            Throwable cause = new Exception("Service error");

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(cause);

            // Then
            assertThat(exception.getErrorCode()).isEqualTo("SERVICE_UNAVAILABLE");
            assertThat(exception.getErrorMessage()).isEqualTo("Servico temporariamente indisponivel");
        }

        @Test
        @DisplayName("Should handle RuntimeException as cause")
        void shouldHandleRuntimeExceptionAsCause() {
            // Given
            RuntimeException cause = new RuntimeException("Database connection failed");

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(cause);

            // Then
            assertThat(exception.getCause()).isInstanceOf(RuntimeException.class);
            assertThat(exception.getCause().getMessage()).isEqualTo("Database connection failed");
            assertThat(exception.getMoreInfos().get("causedBy")).isEqualTo("Database connection failed");
        }

        @Test
        @DisplayName("Should handle SQLException as cause")
        void shouldHandleSQLExceptionAsCause() {
            // Given
            java.sql.SQLException cause = new java.sql.SQLException("Connection pool exhausted");

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(cause);

            // Then
            assertThat(exception.getCause()).isInstanceOf(java.sql.SQLException.class);
            assertThat(exception.getMoreInfos().get("causedBy")).isEqualTo("Connection pool exhausted");
        }

        @Test
        @DisplayName("Should handle IOException as cause")
        void shouldHandleIOExceptionAsCause() {
            // Given
            java.io.IOException cause = new java.io.IOException("Network timeout");

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(cause);

            // Then
            assertThat(exception.getCause()).isInstanceOf(java.io.IOException.class);
            assertThat(exception.getMoreInfos().get("causedBy")).isEqualTo("Network timeout");
        }

        @Test
        @DisplayName("Should handle IllegalStateException as cause")
        void shouldHandleIllegalStateExceptionAsCause() {
            // Given
            IllegalStateException cause = new IllegalStateException("Service in invalid state");

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(cause);

            // Then
            assertThat(exception.getCause()).isInstanceOf(IllegalStateException.class);
            assertThat(exception.getMoreInfos().get("causedBy")).isEqualTo("Service in invalid state");
        }

        @Test
        @DisplayName("Should handle TimeoutException as cause")
        void shouldHandleTimeoutExceptionAsCause() {
            // Given
            java.util.concurrent.TimeoutException cause = new java.util.concurrent.TimeoutException("Request timeout after 30 seconds");

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(cause);

            // Then
            assertThat(exception.getCause()).isInstanceOf(java.util.concurrent.TimeoutException.class);
            assertThat(exception.getMoreInfos().get("causedBy")).contains("timeout");
        }

        @Test
        @DisplayName("Should preserve cause chain")
        void shouldPreserveCauseChain() {
            // Given
            Throwable rootCause = new Exception("Root cause");
            Throwable intermediateCause = new RuntimeException("Intermediate cause", rootCause);

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(intermediateCause);

            // Then
            assertThat(exception.getCause()).isEqualTo(intermediateCause);
            assertThat(exception.getCause().getCause()).isEqualTo(rootCause);
            assertThat(exception.getMoreInfos().get("causedBy")).isEqualTo("Intermediate cause");
        }

        @Test
        @DisplayName("Should handle cause with null message")
        void shouldHandleCauseWithNullMessage() {
            // Given
            Throwable cause = new RuntimeException((String) null);

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(cause);

            // Then
            assertThat(exception.getCause()).isNotNull();
            assertThat(exception.getCause().getMessage()).isNull();
            assertThat(exception.getMoreInfos().get("causedBy")).isNull();
        }

        @Test
        @DisplayName("Should handle cause with empty message")
        void shouldHandleCauseWithEmptyMessage() {
            // Given
            Throwable cause = new RuntimeException("");

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(cause);

            // Then
            assertThat(exception.getCause().getMessage()).isEmpty();
            assertThat(exception.getMoreInfos().get("causedBy")).isEmpty();
        }

        @Test
        @DisplayName("Should handle cause with very long message")
        void shouldHandleCauseWithVeryLongMessage() {
            // Given
            String longMessage = "Service unavailable due to multiple failures. ".repeat(100);
            Throwable cause = new Exception(longMessage);

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(cause);

            // Then
            assertThat(exception.getMoreInfos().get("causedBy")).hasSize(longMessage.length());
        }

        @Test
        @DisplayName("Should handle cause with special characters")
        void shouldHandleCauseWithSpecialCharacters() {
            // Given
            Throwable cause = new Exception("Error: @#$%^&*()_+-=[]{}|;:',.<>?/`~");

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(cause);

            // Then
            assertThat(exception.getMoreInfos().get("causedBy")).contains("@#$%^&*()");
        }

        @Test
        @DisplayName("Should handle cause with Unicode characters")
        void shouldHandleCauseWithUnicodeCharacters() {
            // Given
            Throwable cause = new Exception("Serviço indisponível: ç, á, é, í, ó, ú, ã, õ");

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(cause);

            // Then
            assertThat(exception.getMoreInfos().get("causedBy")).contains("ç, á, é, í");
        }

        @Test
        @DisplayName("Should be throwable and catchable")
        void shouldBeThrowableAndCatchable() {
            // Given
            Throwable cause = new RuntimeException("Service error");

            // When/Then
            try {
                throw new ServiceUnavailableException(cause);
            } catch (ServiceUnavailableException e) {
                assertThat(e.getCause()).isEqualTo(cause);
                assertThat(e.getMoreInfos()).containsKey("causedBy");
            }
        }

        @Test
        @DisplayName("Should preserve stack trace")
        void shouldPreserveStackTrace() {
            // Given
            Throwable cause = new Exception("Test cause");

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(cause);

            // Then
            assertThat(exception.getStackTrace()).isNotNull();
            assertThat(exception.getStackTrace()).isNotEmpty();
        }

        @Test
        @DisplayName("Should create exception for typical Redis scenario")
        void shouldCreateExceptionForTypicalRedisScenario() {
            // Given
            Throwable cause = new RuntimeException("Redis connection pool exhausted after 3 retry attempts");

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(cause);

            // Then
            assertThat(exception.getErrorCode()).isEqualTo("SERVICE_UNAVAILABLE");
            assertThat(exception.getMoreInfos().get("causedBy")).contains("Redis connection pool");
        }

        @Test
        @DisplayName("Should create exception for typical Kafka scenario")
        void shouldCreateExceptionForTypicalKafkaScenario() {
            // Given
            Throwable cause = new RuntimeException("Kafka broker is not available. Connection refused.");

            // When
            ServiceUnavailableException exception = new ServiceUnavailableException(cause);

            // Then
            assertThat(exception.getMoreInfos().get("causedBy")).contains("Kafka broker");
        }
    }

    @Nested
    @DisplayName("Constructor: ServiceUnavailableException()")
    class NoArgsConstructor {

        @Test
        @DisplayName("Should create exception with no arguments")
        void shouldCreateExceptionWithNoArguments() {
            // When
            ServiceUnavailableException exception = new ServiceUnavailableException();

            // Then
            assertThat(exception).isNotNull();
            assertThat(exception.getErrorCode()).isEqualTo(InfraErrorCode.SERVICE_UNAVAILABLE.getCode());
            assertThat(exception.getErrorMessage()).isEqualTo(InfraErrorCode.SERVICE_UNAVAILABLE.getMessage());
            assertThat(exception.getMessage()).isEqualTo(InfraErrorCode.SERVICE_UNAVAILABLE.getMessage());
            assertThat(exception.getCause()).isNull();
        }

        @Test
        @DisplayName("Should use SERVICE_UNAVAILABLE error code")
        void shouldUseServiceUnavailableErrorCode() {
            // When
            ServiceUnavailableException exception = new ServiceUnavailableException();

            // Then
            assertThat(exception.getErrorCode()).isEqualTo("SERVICE_UNAVAILABLE");
        }

        @Test
        @DisplayName("Should use default error message")
        void shouldUseDefaultErrorMessage() {
            // When
            ServiceUnavailableException exception = new ServiceUnavailableException();

            // Then
            assertThat(exception.getErrorMessage()).isEqualTo("Servico temporariamente indisponivel");
        }

        @Test
        @DisplayName("Should have null cause")
        void shouldHaveNullCause() {
            // When
            ServiceUnavailableException exception = new ServiceUnavailableException();

            // Then
            assertThat(exception.getCause()).isNull();
        }

        @Test
        @DisplayName("Should be throwable and catchable")
        void shouldBeThrowableAndCatchable() {
            // When/Then
            try {
                throw new ServiceUnavailableException();
            } catch (ServiceUnavailableException e) {
                assertThat(e.getErrorCode()).isEqualTo("SERVICE_UNAVAILABLE");
                assertThat(e.getErrorMessage()).isEqualTo("Servico temporariamente indisponivel");
            }
        }

        @Test
        @DisplayName("Should preserve stack trace")
        void shouldPreserveStackTrace() {
            // When
            ServiceUnavailableException exception = new ServiceUnavailableException();

            // Then
            assertThat(exception.getStackTrace()).isNotNull();
            assertThat(exception.getStackTrace()).isNotEmpty();
        }

        @Test
        @DisplayName("Should be instance of expected exception hierarchy")
        void shouldBeInstanceOfExpectedExceptionHierarchy() {
            // When
            ServiceUnavailableException exception = new ServiceUnavailableException();

            // Then
            assertThat(exception).isInstanceOf(RuntimeException.class);
            assertThat(exception).isInstanceOf(Exception.class);
            assertThat(exception).isInstanceOf(Throwable.class);
        }

        @Test
        @DisplayName("Should be usable in circuit breaker pattern")
        void shouldBeUsableInCircuitBreakerPattern() {
            // When
            ServiceUnavailableException exception = new ServiceUnavailableException();

            // Then - Verificar que a exceção é adequada para uso em circuit breaker
            assertThat(exception.getErrorCode()).isEqualTo("SERVICE_UNAVAILABLE");
            assertThat(exception).isInstanceOf(RuntimeException.class);
        }

        @Test
        @DisplayName("Should be usable in retry scenarios")
        void shouldBeUsableInRetryScenarios() {
            // When
            ServiceUnavailableException exception = new ServiceUnavailableException();

            // Then - Verificar que a exceção indica um erro transitório
            assertThat(exception.getErrorMessage()).contains("temporariamente");
            assertThat(exception.getErrorCode()).isEqualTo("SERVICE_UNAVAILABLE");
        }

        @Test
        @DisplayName("Should create multiple independent instances")
        void shouldCreateMultipleIndependentInstances() {
            // When
            ServiceUnavailableException exception1 = new ServiceUnavailableException();
            ServiceUnavailableException exception2 = new ServiceUnavailableException();

            // Then
            assertThat(exception1).isNotSameAs(exception2);
            assertThat(exception1.getErrorCode()).isEqualTo(exception2.getErrorCode());
            assertThat(exception1.getErrorMessage()).isEqualTo(exception2.getErrorMessage());
        }
    }

    @Nested
    @DisplayName("Serialization Tests")
    class SerializationTests {

        @Test
        @DisplayName("Should have serialVersionUID defined")
        void shouldHaveSerialVersionUIDDefined() {
            // When
            ServiceUnavailableException exception = new ServiceUnavailableException();

            // Then
            assertThat(exception).isInstanceOf(java.io.Serializable.class);
        }

        @Test
        @DisplayName("Should be serializable with code and message constructor")
        void shouldBeSerializableWithCodeAndMessageConstructor() {
            // Given
            ServiceUnavailableException exception = new ServiceUnavailableException("CODE", "Message");

            // Then
            assertThat(exception).isInstanceOf(java.io.Serializable.class);
        }

        @Test
        @DisplayName("Should be serializable with cause constructor")
        void shouldBeSerializableWithCauseConstructor() {
            // Given
            ServiceUnavailableException exception = new ServiceUnavailableException(new Exception("Cause"));

            // Then
            assertThat(exception).isInstanceOf(java.io.Serializable.class);
        }

        @Test
        @DisplayName("Should be serializable with no args constructor")
        void shouldBeSerializableWithNoArgsConstructor() {
            // Given
            ServiceUnavailableException exception = new ServiceUnavailableException();

            // Then
            assertThat(exception).isInstanceOf(java.io.Serializable.class);
        }
    }

    @Nested
    @DisplayName("Integration Scenarios")
    class IntegrationScenarios {

        @Test
        @DisplayName("Should work in try-catch-finally block")
        void shouldWorkInTryCatchFinallyBlock() {
            // Given
            boolean[] finallyExecuted = {false};

            // When/Then
            try {
                throw new ServiceUnavailableException();
            } catch (ServiceUnavailableException e) {
                assertThat(e.getErrorCode()).isEqualTo("SERVICE_UNAVAILABLE");
            } finally {
                finallyExecuted[0] = true;
            }

            assertThat(finallyExecuted[0]).isTrue();
        }

        @Test
        @DisplayName("Should work with multiple catch blocks")
        void shouldWorkWithMultipleCatchBlocks() {
            // Given
            ServiceUnavailableException thrownException = null;

            // When
            try {
                throw new ServiceUnavailableException("ERROR", "Service down");
            } catch (ServiceUnavailableException e) {
                thrownException = e;
            } catch (RuntimeException ex) {
                // Should not reach here
                assertThat(true).isFalse();
            }

            // Then
            assertThat(thrownException).isNotNull();
        }

        @Test
        @DisplayName("Should integrate with circuit breaker pattern")
        void shouldIntegrateWithCircuitBreakerPattern() {
            // Given
            int failureCount = 0;
            int threshold = 3;

            // When - Simulate circuit breaker
            for (int i = 0; i < threshold; i++) {
                try {
                    throw new ServiceUnavailableException();
                } catch (ServiceUnavailableException ex) {
                    failureCount++;
                }
            }

            // Then
            assertThat(failureCount).isEqualTo(threshold);
        }
    }
}

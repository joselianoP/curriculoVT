package br.com.bradesco.srv.hex.adapter.in.api.rest.handler;

import static org.assertj.core.api.Assertions.assertThat;

import java.lang.reflect.Method;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;

import br.com.bradesco.srv.hex.adapter.in.api.rest.response.ErrorDetail;
import br.com.bradesco.srv.hex.adapter.in.api.rest.response.ErrorResponseAPI;
import br.com.bradesco.srv.hex.application.exception.BusinessException;
import br.com.bradesco.srv.hex.application.exception.BusinessValidationException;
import br.com.bradesco.srv.hex.application.exception.CorrelationIdDuplicadoException;
import br.com.bradesco.srv.hex.application.exception.DocumentoEmAnaliseException;
import br.com.bradesco.srv.hex.application.exception.InfrastructureException;
import br.com.bradesco.srv.hex.application.exception.LimiteEnvioDocumentoExcedidoException;
import br.com.bradesco.srv.hex.application.exception.ProcessamentoNaoEncontradoException;
import br.com.bradesco.srv.hex.application.exception.ServiceUnavailableException;
import br.com.bradesco.srv.hex.application.exception.UnauthorizedException;
import br.com.bradesco.srv.hex.application.exception.ValidationFieldException;
import br.com.bradesco.srv.hex.util.ConstantsUtil;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Path;

class ApplicationExceptionHandlerTest {

    private final ApplicationExceptionHandler handler = new ApplicationExceptionHandler();
    private final AbstractRestExceptionHandler base = new AbstractRestExceptionHandler() {
    };
    private final MockHttpServletRequest servletRequest = new MockHttpServletRequest();
    private final ServletWebRequest request = new ServletWebRequest(servletRequest);

    @AfterEach
    void limpar() {
        MDC.clear();
    }

    private static ErrorDetail erro(org.springframework.http.ResponseEntity<Object> resposta) {
        assertThat(resposta.getBody()).isInstanceOf(ErrorResponseAPI.class);
        return ((ErrorResponseAPI) resposta.getBody()).erro();
    }

    static void metodoAlvo(String valor) {
    }

    private static MethodParameter parametro() throws NoSuchMethodException {
        Method metodo = ApplicationExceptionHandlerTest.class.getDeclaredMethod("metodoAlvo", String.class);
        return new MethodParameter(metodo, 0);
    }

    private static MethodArgumentNotValidException argumentoInvalido(
            List<ObjectError> globais, List<FieldError> campos) throws NoSuchMethodException {
        var binding = new BeanPropertyBindingResult(new Object(), "objeto");
        globais.forEach(binding::addError);
        campos.forEach(binding::addError);
        return new MethodArgumentNotValidException(parametro(), binding);
    }

    @Test
    void correlationIdDuplicadoRetornaConflitoComCorrelationIdDaExcecao() {
        var resposta = handler.handleCorrelationIdDuplicado(new CorrelationIdDuplicadoException("corr-1"), request);

        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.CONFLICT);
        assertThat(erro(resposta).correlationId()).isEqualTo("corr-1");
        assertThat(erro(resposta).mensagem()).isEqualTo("Processamento duplicado");
    }

    @Test
    void documentoEmAnaliseRetornaConflito() {
        var resposta = handler.handleDocumentoEmAnalise(new DocumentoEmAnaliseException("em analise"), request);

        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.CONFLICT);
        assertThat(erro(resposta).detalhes()).isEqualTo("em analise");
    }

    @Test
    void limiteExcedidoRetorna429() {
        var resposta = handler.handleLimiteEnvioDocumentoExcedido(
                new LimiteEnvioDocumentoExcedidoException("limite"), request);

        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.TOO_MANY_REQUESTS);
        assertThat(erro(resposta).mensagem()).isEqualTo("Limite de envio excedido");
    }

    @Test
    void processamentoNaoEncontradoRetorna404() {
        var resposta = handler.handleProcessamentoNaoEncontrado(
                new ProcessamentoNaoEncontradoException("abc"), request);

        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        assertThat(erro(resposta).detalhes()).isEqualTo("Processamento nao encontrado.");
    }

    @Test
    void businessExceptionRetorna422() {
        var resposta = handler.handleBusinessException(new BusinessException("01", "regra"), request);

        assertThat(resposta.getStatusCode().value()).isEqualTo(422);
        assertThat(erro(resposta).mensagem()).isEqualTo("Regra de negócio não atendida");
        assertThat(erro(resposta).detalhes()).isEqualTo("Não foi possível concluir a operação.");
    }

    @Test
    void infrastructureExceptionRetorna500() {
        var resposta = handler.handleInfrastructureException(new InfrastructureException("01", "falha"), request);

        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(erro(resposta).mensagem()).isEqualTo("Erro do servidor interno");
    }

  
    @Test
    void serviceUnavailableRetorna503() {
        var resposta = handler.handleServiceUnavailableException(
                new ServiceUnavailableException("01", "indisponivel"), request);

        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.SERVICE_UNAVAILABLE);
        assertThat(erro(resposta).mensagem()).isEqualTo("Serviço indisponível");
    }

    @Test
    void businessValidationConcatenaDetalhesECampos() {
        var ex = new BusinessValidationException("400", "Invalido", "detalhe",
                List.of(new ValidationFieldException("a", "x"), new ValidationFieldException("b", "y")));

        var detalhes = erro(handler.handleBusinessValidationException(ex, request)).detalhes();

        assertThat(detalhes).isEqualTo("Não foi possível validar os dados informados.");
    }

    @Test
    void businessValidationUsaApenasCamposQuandoDetalheAusente() {
        var ex = new BusinessValidationException("400", "Invalido", " ",
                List.of(new ValidationFieldException("a", "x")));

        assertThat(erro(handler.handleBusinessValidationException(ex, request)).detalhes()).isEqualTo("Não foi possível validar os dados informados.");
    }

    @Test
    void businessValidationSemCamposMantemDetalheOriginal() {
        var ex = new BusinessValidationException("400", "Invalido", "detalhe");

        assertThat(erro(handler.handleBusinessValidationException(ex, request)).detalhes()).isEqualTo("Não foi possível validar os dados informados.");
    }

    @Test
    void businessValidationUsaMensagemEDetalhePadraoQuandoAusentes() {
        var ex = new BusinessValidationException("400", " ", null);

        var detalhe = erro(handler.handleBusinessValidationException(ex, request));

        assertThat(detalhe.mensagem()).isEqualTo("Dados inválidos");
        assertThat(detalhe.detalhes()).isEqualTo("Não foi possível validar os dados informados.");
    }

    @Test
    void correlationIdVemDoMdcQuandoExcecaoNaoInformaUm() {
        MDC.put(ConstantsUtil.COORELATION_ID, "mdc-1");

        var resposta = handler.handleDocumentoEmAnalise(new DocumentoEmAnaliseException("x"), request);

        assertThat(erro(resposta).correlationId()).isEqualTo("mdc-1");
    }

    @Test
    void correlationIdVemDoHeaderQuandoMdcAusente() {
        servletRequest.addHeader(ConstantsUtil.COORELATION_ID, "header-1");

        var resposta = handler.handleDocumentoEmAnalise(new DocumentoEmAnaliseException("x"), request);

        assertThat(erro(resposta).correlationId()).isEqualTo("header-1");
    }

    @Test
    void correlationIdNuloQuandoNaoHaFonteDisponivel() {
        var resposta = handler.handleDocumentoEmAnalise(new DocumentoEmAnaliseException("x"), request);

        assertThat(erro(resposta).correlationId()).isNull();
    }

    @Test
    void metodoArgumentoInvalidoUsaPrimeiraMensagemDeCampo() throws Exception {
        var campo = new FieldError("objeto", "nome", null, false, null, null, "nome obrigatorio");

        var resposta = handler.handleMethodArgumentNotValid(
                argumentoInvalido(List.of(), List.of(campo)), new HttpHeaders(), HttpStatus.BAD_REQUEST, request);

        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(erro(resposta).detalhes()).contains("nome obrigatorio");
    }

    @Test
    void metodoArgumentoInvalidoUsaMensagemPadraoSemErroDeCampoOuSemMensagem() throws Exception {
        var semErros = handler.handleMethodArgumentNotValid(
                argumentoInvalido(List.of(), List.of()), new HttpHeaders(), HttpStatus.BAD_REQUEST, request);
        var semMensagem = handler.handleMethodArgumentNotValid(
                argumentoInvalido(List.of(), List.of(new FieldError("objeto", "nome", null, false, null, null, null))),
                new HttpHeaders(), HttpStatus.BAD_REQUEST, request);

        assertThat(erro(semErros).detalhes()).contains("Validation failed for argument");
        assertThat(erro(semMensagem).detalhes()).contains("Validation failed for argument");
    }

    @Test
    void handlerBaseMontaListaDeErrosDeValidacao() throws Exception {
        var global = new ObjectError("objeto", "erro global");
        var campo = new FieldError("objeto", "nome", "nome obrigatorio");

        var resposta = base.handleMethodArgumentNotValid(
                argumentoInvalido(List.of(global), List.of(campo)), new HttpHeaders(), HttpStatus.BAD_REQUEST, request);

        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(resposta.getBody()).isInstanceOf(ErrorResponseAPI.class);
        assertThat(erro(resposta).mensagem()).isEqualTo("Requisicao invalida");
    }

    @Test
    void handlerBaseTrataViolacaoDeConstraintComCampoAninhado() {
        var violacao = violacao("metodo.parametro.nome", "obrigatorio");

        var resposta = base.handleConstraintViolation(
                new ConstraintViolationException("invalido", java.util.Set.of(violacao)), request);

        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    }

    @Test
    void handlerBaseTrataViolacaoDeConstraintSemPontoNoCaminho() {
        var violacao = violacao("nome", "obrigatorio");

        var resposta = base.handleConstraintViolation(
                new ConstraintViolationException("invalido", java.util.Set.of(violacao)), request);

        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    }

    @Test
    void handlerBaseTrataTipoIncompativelComValorNuloEMensagemPadrao() throws Exception {
        var ex = new MethodArgumentTypeMismatchException(null, null, "valor", parametro(), null);

        var resposta = base.handleMethodArgumentTypeMismatch(ex, request);

        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    }

    @Test
    void handlerBaseTrataTipoIncompativelComValorPreenchido() throws Exception {
        var ex = new MethodArgumentTypeMismatchException("abc", Integer.class, "valor", parametro(), null);

        var resposta = base.handleMethodArgumentTypeMismatch(ex, request);

        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    }

 

    @Test
    void handlerBaseOcultaDetalhesEmErrosDeServidor() {
        var resposta = base.handleExceptionInternal(
                new IllegalStateException("segredo"), null, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR,
                request);

        assertThat(erro(resposta).detalhes()).isEqualTo("segredo");
    }

    @Test
    void handlerBaseUsaDetalheDoProblemDetailQuandoPreenchido() {
        var problema = org.springframework.http.ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, "do problema");

        var resposta = base.handleExceptionInternal(
                new IllegalStateException("outra"), problema, new HttpHeaders(), HttpStatus.BAD_REQUEST, request);

        assertThat(erro(resposta).detalhes()).isEqualTo("outra");
    }

    @Test
    void handlerBaseUsaMensagemDaExcecaoQuandoProblemDetailSemDetalhe() {
        var problema = org.springframework.http.ProblemDetail.forStatus(HttpStatus.BAD_REQUEST);

        var resposta = base.handleExceptionInternal(
                new IllegalStateException("da excecao"), problema, new HttpHeaders(), HttpStatus.BAD_REQUEST,
                request);

        assertThat(erro(resposta).detalhes()).isEqualTo("da excecao");
    }

    @Test
    void handlerBaseUsaDetalhePadraoQuandoNaoHaMensagem() {
        var resposta = base.handleExceptionInternal(
                new IllegalStateException(), null, new HttpHeaders(), HttpStatus.BAD_REQUEST, request);

        assertThat(erro(resposta).detalhes()).isEqualTo("Ocorreu um erro interno ao processar a requisição.");
    }

    @Test
    void handlerBasePreservaCorpoJaPadronizado() {
        var corpo = new ErrorResponseAPI(new ErrorDetail("400", "m", "d", null));

        var resposta = base.handleExceptionInternal(
                new IllegalStateException("x"), corpo, new HttpHeaders(), HttpStatus.BAD_REQUEST, request);

        assertThat(resposta.getBody()).isSameAs(corpo);
    }

    @Test
    void handlerBaseUsaCorrelationIdDoMdcOuDoHeader() {
        MDC.put(ConstantsUtil.COORELATION_ID, "mdc-2");
        var doMdc = base.handleExceptionInternal(
                new IllegalStateException("x"), null, new HttpHeaders(), HttpStatus.BAD_REQUEST, request);
        MDC.clear();
        servletRequest.addHeader(ConstantsUtil.COORELATION_ID, "header-2");
        var doHeader = base.handleExceptionInternal(
                new IllegalStateException("x"), null, new HttpHeaders(), HttpStatus.BAD_REQUEST, request);

        assertThat(erro(doMdc).correlationId()).isEqualTo("mdc-2");
        assertThat(erro(doHeader).correlationId()).isEqualTo("header-2");
    }

    @Test
    void handlerBaseTrataNoHandlerFound() {
        var resposta = base.handleNoHandlerFoundException(
                new NoHandlerFoundException("GET", "/x", new HttpHeaders()), new HttpHeaders(),
                HttpStatus.NOT_FOUND, request);

        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
    }

    @Test
    void handlerBaseUsaLoggerInformado() {
        var logger = org.mockito.Mockito.mock(org.slf4j.Logger.class);
        var comLogger = new AbstractRestExceptionHandler(logger) {
        };

        assertThat(comLogger.logService).isSameAs(logger);
    }

    @Test
    void handlerBaseSemErrosDeValidacaoNaoAdicionaLista() throws Exception {
        var resposta = base.handleMethodArgumentNotValid(
                argumentoInvalido(List.of(), List.of()), new HttpHeaders(), HttpStatus.BAD_REQUEST, request);

        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    }

    @Test
    void handlerBaseTrataViolacaoSemRestricoes() {
        var resposta = base.handleConstraintViolation(
                new ConstraintViolationException("invalido", java.util.Set.of()), request);

        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    }

    @Test
    void handlerBaseIgnoraMdcEmBrancoEUsaHeader() {
        MDC.put(ConstantsUtil.COORELATION_ID, " ");
        servletRequest.addHeader(ConstantsUtil.COORELATION_ID, "header-3");

        var resposta = base.handleExceptionInternal(
                new IllegalStateException("x"), null, new HttpHeaders(), HttpStatus.BAD_REQUEST, request);

        assertThat(erro(resposta).correlationId()).isEqualTo("header-3");
    }

    @Test
    void handlerBaseUsaMensagemDaExcecaoQuandoDetalheDoProblemEstaEmBranco() {
        var problema = org.springframework.http.ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, " ");

        var resposta = base.handleExceptionInternal(
                new IllegalStateException("da excecao"), problema, new HttpHeaders(), HttpStatus.BAD_REQUEST,
                request);

        assertThat(erro(resposta).detalhes()).isEqualTo("da excecao");
    }

    @Test
    void handlerBaseUsaDetalhePadraoQuandoMensagemEstaEmBranco() {
        var resposta = base.handleExceptionInternal(
                new IllegalStateException(" "), null, new HttpHeaders(), HttpStatus.BAD_REQUEST, request);

        assertThat(erro(resposta).detalhes()).isEqualTo("Ocorreu um erro interno ao processar a requisição.");
    }

    private static org.springframework.web.method.annotation.HandlerMethodValidationException validacaoDeMetodo(
            org.springframework.context.MessageSourceResolvable... erros) {
        var parametro = org.mockito.Mockito.mock(org.springframework.validation.method.ParameterValidationResult.class);
        org.mockito.Mockito.when(parametro.getResolvableErrors()).thenAnswer(invocacao -> List.of(erros));
        var resultado = org.mockito.Mockito.mock(org.springframework.validation.method.MethodValidationResult.class,
                org.mockito.Mockito.CALLS_REAL_METHODS);
        org.mockito.Mockito.doReturn(erros.length == 0 ? List.of() : List.of(parametro))
                .when(resultado).getParameterValidationResults();
        return new org.springframework.web.method.annotation.HandlerMethodValidationException(resultado);
    }

    @Test
    void handlerEspecificoTrataValidacaoDeMetodoComPrimeiraMensagem() {
        var ex = validacaoDeMetodo(
                new org.springframework.context.support.DefaultMessageSourceResolvable(new String[] {"c"}, null, null),
                new org.springframework.context.support.DefaultMessageSourceResolvable(new String[] {"c"}, "mensagem"));

        var resposta = handler.handleHandlerMethodValidationException(
                ex, new HttpHeaders(), HttpStatus.BAD_REQUEST, request);

        assertThat(resposta.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(erro(resposta).detalhes()).contains("Validation failure");
    }

    @Test
    void handlerEspecificoUsaMensagemPadraoQuandoValidacaoDeMetodoNaoTemMensagens() {
        var resposta = handler.handleHandlerMethodValidationException(
                validacaoDeMetodo(), new HttpHeaders(), HttpStatus.BAD_REQUEST, request);

        assertThat(erro(resposta).detalhes()).contains("Validation failure");
    }

    @Test
    void handlerEspecificoMapeiaStatusSemMensagemDedicada() {
        var excecao = new InfrastructureException("01", "falha");

        var cliente = handler.handleBaseException(excecao, HttpStatus.FORBIDDEN, request);
        var servidor = handler.handleBaseException(excecao, HttpStatus.BAD_GATEWAY, request);

        assertThat(erro(cliente).mensagem()).isEqualTo("Acesso não autorizado");
        assertThat(erro(servidor).mensagem()).isEqualTo("Falha na comunicação com serviço integrado");
    }

    @Test
    void handlerEspecificoMapeiaConflitoEIgnoraCorrelationIdEmBranco() {
        var excecao = new InfrastructureException("01", "falha");
        MDC.put(ConstantsUtil.COORELATION_ID, " ");

        var resposta = handler.handleBaseException(excecao, HttpStatus.CONFLICT, request);

        assertThat(erro(resposta).mensagem()).isEqualTo("Conflito de processamento");
        assertThat(erro(resposta).correlationId()).isNull();
    }

    @SuppressWarnings("unchecked")
    private static ConstraintViolation<Object> violacao(String caminho, String mensagem) {
        var violacao = org.mockito.Mockito.mock(ConstraintViolation.class);
        var path = org.mockito.Mockito.mock(Path.class);
        org.mockito.Mockito.when(path.toString()).thenReturn(caminho);
        org.mockito.Mockito.when(violacao.getPropertyPath()).thenReturn(path);
        org.mockito.Mockito.when(violacao.getMessage()).thenReturn(mensagem);
        return violacao;
    }
}

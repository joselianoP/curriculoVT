package br.com.bradesco.srv.hex.adapter.in.api.rest.controller.v1.apidoc;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.springframework.http.ProblemDetail;

import br.com.bradesco.srv.hex.adapter.in.api.rest.dto.ValidaFinResponseDto;
import br.com.bradesco.srv.hex.adapter.in.api.rest.response.ErrorResponseAPI;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

class AnaliseRendaCommonApiDocTest {

    @Test
    void shouldDocumentActualResponseCodesAndSchemas() {
        var responses = AnaliseRendaCommonApiDoc.class.getAnnotation(ApiResponses.class).value();

        assertThat(Arrays.stream(responses).map(ApiResponse::responseCode).toList())
                .containsExactly("200", "400", "401", "403", "404", "409", "422", "429", "500", "503");
        assertThat(response(responses, "200").content()[0].schema().implementation())
                .isEqualTo(ValidaFinResponseDto.class);
        assertThat(response(responses, "400").content()[0].schema().oneOf())
                .containsExactly(ErrorResponseAPI.class, ProblemDetail.class);
        assertThat(response(responses, "400").content()[0].examples()).hasSize(2);
        assertThat(response(responses, "404").content()[0].schema().implementation())
                .isEqualTo(ErrorResponseAPI.class);
        assertThat(response(responses, "409").content()[0].schema().implementation())
                .isEqualTo(ErrorResponseAPI.class);
        assertThat(response(responses, "422").content()[0].schema().implementation())
                .isEqualTo(ErrorResponseAPI.class);
        assertThat(response(responses, "429").content()[0].schema().implementation())
                .isEqualTo(ErrorResponseAPI.class);
        assertThat(response(responses, "500").content()[0].schema().oneOf())
                .containsExactly(ErrorResponseAPI.class, ProblemDetail.class);
        assertThat(response(responses, "503").content()[0].schema().implementation())
                .isEqualTo(ErrorResponseAPI.class);
    }

    private static ApiResponse response(ApiResponse[] responses, String responseCode) {
        return Arrays.stream(responses)
                .filter(response -> response.responseCode().equals(responseCode))
                .findFirst()
                .orElseThrow();
    }
}

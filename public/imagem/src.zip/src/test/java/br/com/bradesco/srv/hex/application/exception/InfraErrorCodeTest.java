package br.com.bradesco.srv.hex.application.exception;

import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.FieldSource;

import br.com.bradesco.srv.hex.application.exception.InfraErrorCode;

import java.util.Arrays;

import static org.assertj.core.api.BDDAssertions.then;

class InfraErrorCodeTest {

    @Nested
    class EnumIntegrityTests {
        static final Arguments[] expectedValues = {
            Arguments.of("SERVICE_UNAVAILABLE", "Servico temporariamente indisponivel"),
            Arguments.of("CALL_NOT_PERMITTED", "Chamada nao permitida"),
            Arguments.of("NOT_FOUND", "Recurso nao encontrado"),
            Arguments.of("EXTERNAL_SERVICE_4XX", "Erro na comunicacao com servico externo"),
            Arguments.of("EXTERNAL_SERVICE_5XX", "Erro na comunicacao com servico externo"),
            Arguments.of("CACHE_SERVICE", "Erro no servico de cache"),
            Arguments.of("INFRA_GENERIC", "Erro generico de infraestrutura")
        };

        @Test
        void shouldEnumHaveAllExpectedValues() {
            then(InfraErrorCode.values())
                .hasSizeGreaterThanOrEqualTo(expectedValues.length);
        }

        @ParameterizedTest
        @FieldSource("expectedValues")
        void shouldEnumValuesMatchExpected(String expectedCode, String expectedMessage) {
            // When
            var errorCode = InfraErrorCode.valueOf(expectedCode);
            // Then
            then(errorCode).isNotNull();
            then(errorCode.getCode()).isEqualTo(expectedCode);
            then(errorCode.getMessage()).isEqualTo(expectedMessage);
        }

        @Test
        void shouldEnumCodesBeUnique() {
            // When
            var codes = Arrays.stream(InfraErrorCode.values())
                .map(InfraErrorCode::getCode)
                .toList();
            var uniqueCodes = codes.stream().distinct().toList();
            // Then
            then(codes.size()).isEqualTo(uniqueCodes.size());
        }
    }

    @Nested
    class GetterTests {
        @ParameterizedTest
        @EnumSource(InfraErrorCode.class)
        void shouldGetCodeAndMessage(InfraErrorCode infraErrorCode) {
            // Then
            then(infraErrorCode.getCode())
                .isNotNull()
                .isNotEmpty();
            then(infraErrorCode.getMessage())
                .isNotNull()
                .isNotEmpty();
        }
    }

    @Nested
    class ToStringTests {
        @ParameterizedTest
        @EnumSource(InfraErrorCode.class)
        void shouldToStringReturnExpectedFormat(InfraErrorCode infraErrorCode) {
            // When
            var toStringResult = infraErrorCode.toString();
            // Then
            then(toStringResult)
                .isNotNull()
                .isNotBlank()
                .isEqualTo(infraErrorCode.getCode());
        }
    }

    @Nested
    class FormatSubCodeTests {
        @ParameterizedTest
        @EnumSource(InfraErrorCode.class)
        void shouldFormatSubCodeWithClassNameAndMethod(InfraErrorCode infraErrorCode) {
            // Given
            String className = "MyClass";
            String methodName = "myMethod";
            // When
            String formattedCode = infraErrorCode.formatSubCode(className, methodName);
            // Then
            then(formattedCode).isEqualTo("%s.%s.%s".formatted(className, methodName, infraErrorCode.getCode()));
        }

        @ParameterizedTest
        @EnumSource(InfraErrorCode.class)
        void shouldFormatSubCodeWithClassNameOnly(InfraErrorCode infraErrorCode) {
            // Given
            String className = "MyClass";
            // When
            String formattedCode = infraErrorCode.formatSubCode(className, null);
            // Then
            then(formattedCode).isEqualTo("%s.%s".formatted(className, infraErrorCode.getCode()));
        }

        @ParameterizedTest
        @EnumSource(InfraErrorCode.class)
        void shouldFormatSubCodeWithClassAndMethod(InfraErrorCode infraErrorCode) {
            // Given
            Class<?> clazz = Object.class;
            String methodName = "myMethod";
            // When
            String formattedCode = infraErrorCode.formatSubCode(clazz, methodName);
            // Then
            then(formattedCode).isEqualTo("%s.%s.%s".formatted(clazz.getSimpleName(), methodName, infraErrorCode.getCode()));
        }

        @ParameterizedTest
        @EnumSource(InfraErrorCode.class)
        void shouldFormatSubCodeWithClassOnly(InfraErrorCode infraErrorCode) {
            // Given
            Class<?> clazz = Object.class;
            // When
            String formattedCode = infraErrorCode.formatSubCode(clazz, null);
            // Then
            then(formattedCode).isEqualTo("%s.%s".formatted(clazz.getSimpleName(), infraErrorCode.getCode()));
        }
    }
}

package br.com.bradesco.srv.hex.adapter.in.api.rest.handler;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.bradesco.srv.hex.application.exception.BusinessValidationException;
import br.com.bradesco.srv.hex.application.exception.DocumentoJaCadastradoException;
import br.com.bradesco.srv.hex.application.exception.InvalidInputException;
import br.com.bradesco.srv.hex.application.exception.NotFoundException;
import br.com.bradesco.srv.hex.application.exception.ValidationFieldException;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;

class ExceptionHandlerMvcTest {

    record Payload(@NotBlank(message = "name required") String name) {
    }

    @RestController
    static class StubController {

        @GetMapping("/business")
        String business() {
            throw new BusinessValidationException("400", "Invalid", "details",
                    List.of(new ValidationFieldException("field", "reason")));
        }

        @GetMapping("/business-no-fields")
        String businessNoFields() {
            throw new BusinessValidationException("400", "Invalid", "details");
        }

        @GetMapping("/not-found")
        String notFound() {
            throw new NotFoundException("04", "not found");
        }

        @GetMapping("/invalid-input")
        String invalidInput() {
            throw new InvalidInputException("01", "origin", "bad input");
        }

        @GetMapping("/generic")
        String generic() {
            throw new IllegalStateException("boom");
        }

        @GetMapping("/duplicate")
        String duplicate() {
            throw new DocumentoJaCadastradoException(
                    "Já existe documento para correlationId=correlation-123");
        }

        @GetMapping("/constraint")
        String constraint() {
            throw new ConstraintViolationException("invalid", Set.of());
        }

        @GetMapping("/number")
        String number(@RequestParam Integer value) {
            return String.valueOf(value);
        }

        @PostMapping("/payload")
        String payload(@Valid @RequestBody Payload payload) {
            return payload.name();
        }
    }

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        var validator = new LocalValidatorFactoryBean();
        validator.afterPropertiesSet();
        mockMvc = MockMvcBuilders.standaloneSetup(new StubController())
                .setControllerAdvice(new ApplicationExceptionHandler())
                .setValidator(validator)
                .build();
    }

    @Test
    void shouldHandleBusinessValidationWithFields() throws Exception {
        mockMvc.perform(get("/business"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.erro.codigo").value("400"));
    }

    @Test
    void shouldHandleBusinessValidationWithoutFields() throws Exception {
        mockMvc.perform(get("/business-no-fields")).andExpect(status().isBadRequest());
    }

    @Test
    void shouldHandleNotFound() throws Exception {
        mockMvc.perform(get("/not-found"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.erro.mensagem").value("Recurso não encontrado"));
    }

    @Test
    void shouldHandleInvalidInput() throws Exception {
        mockMvc.perform(get("/invalid-input")).andExpect(status().isBadRequest());
    }

    @Test
    void shouldHandleGenericExceptionAs500() throws Exception {
        mockMvc.perform(get("/generic")).andExpect(status().isInternalServerError());
    }

    @Test
    void shouldReturnDuplicateDetailsAsConflict() throws Exception {
        mockMvc.perform(get("/duplicate"))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.erro.mensagem").value("Processamento duplicado"))
                .andExpect(jsonPath("$.erro.detalhes")
                        .value("Já existe documento para correlationId=correlation-123"));
    }

    @Test
    void shouldHandleConstraintViolationAs400() throws Exception {
        mockMvc.perform(get("/constraint")).andExpect(status().isBadRequest());
    }

    @Test
    void shouldHandleTypeMismatchAs400() throws Exception {
        mockMvc.perform(get("/number").param("value", "abc")).andExpect(status().isBadRequest());
    }

    @Test
    void shouldHandleInvalidBodyAs400() throws Exception {
        mockMvc.perform(post("/payload").contentType(MediaType.APPLICATION_JSON).content("{\"name\":\"\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void shouldHandleMissingRouteAsNotFound() throws Exception {
        mockMvc.perform(get("/unknown")).andExpect(status().isNotFound());
    }

    @Test
    void shouldHandleUnsupportedMethod() throws Exception {
        mockMvc.perform(post("/generic")).andExpect(status().isMethodNotAllowed());
    }
}
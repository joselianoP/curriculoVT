package br.com.bradesco.srv.hex.util;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class BlankStringUtilTest {
    @Test void identificaStringsBlank() {
        assertTrue(BlankStringUtil.isBlank(null));
        assertTrue(BlankStringUtil.isBlank(""));
        assertTrue(BlankStringUtil.isBlank("   "));
        assertFalse(BlankStringUtil.isBlank("x"));
        assertFalse(BlankStringUtil.nonBlank(" "));
        assertTrue(BlankStringUtil.nonBlank("x"));
    }

    @Test void requireNonBlankRetornaOriginalOuLanca() {
        assertEquals("valor", BlankStringUtil.requireNonBlank("valor"));
        assertEquals("valor", BlankStringUtil.requireNonBlank("valor", "erro"));
        assertEquals("valor", BlankStringUtil.requireNonBlank("valor", () -> "erro"));
        assertEquals("erro", assertThrows(IllegalArgumentException.class,
                () -> BlankStringUtil.requireNonBlank(" ", "erro")).getMessage());
        assertNull(assertThrows(IllegalArgumentException.class,
                () -> BlankStringUtil.requireNonBlank(" ", (java.util.function.Supplier<String>) null)).getMessage());
    }

    @Test void requireNonBlankElseUsaDefaultEValidaDefault() {
        assertEquals("original", BlankStringUtil.requireNonBlankElse("original", "default"));
        assertEquals("default", BlankStringUtil.requireNonBlankElse(null, "default"));
        assertThrows(IllegalArgumentException.class, () -> BlankStringUtil.requireNonBlankElse(null, " "));
    }

    @Test void requireNonBlankElseGetUsaSupplierSomenteQuandoNecessario() {
        assertEquals("original", BlankStringUtil.requireNonBlankElseGet("original", () -> "default"));
        assertEquals("default", BlankStringUtil.requireNonBlankElseGet(" ", () -> "default"));
        assertThrows(NullPointerException.class, () -> BlankStringUtil.requireNonBlankElseGet(null, null));
        assertThrows(IllegalArgumentException.class, () -> BlankStringUtil.requireNonBlankElseGet(null, () -> ""));
    }
}

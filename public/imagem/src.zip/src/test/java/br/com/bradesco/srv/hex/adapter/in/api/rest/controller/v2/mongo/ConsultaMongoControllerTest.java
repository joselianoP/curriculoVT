package br.com.bradesco.srv.hex.adapter.in.api.rest.controller.v2.mongo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import br.com.bradesco.srv.hex.application.model.ConsultaMongoResultado;
import br.com.bradesco.srv.hex.application.port.in.mongo.ConsultarDocumentosMongoUseCase;

class ConsultaMongoControllerTest {

    private final ConsultarDocumentosMongoUseCase useCase = mock(ConsultarDocumentosMongoUseCase.class);
    private final ConsultaMongoController controller = new ConsultaMongoController(useCase);

    @Test
    void deveDelegarConsultaAoCasoDeUsoEMapearResposta() {
        String correlationId = "correlation-123";
        var collections = Map.of("pessoaFisica", List.of(Map.<String, Object>of("cpf", "123")));
        when(useCase.executar(correlationId)).thenReturn(new ConsultaMongoResultado(correlationId, 1, collections));

        var response = controller.consultarPorCorrelationId(correlationId);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().cdCorrelationId()).isEqualTo(correlationId);
        assertThat(response.getBody().totalDocumentos()).isEqualTo(1);
        assertThat(response.getBody().collections()).isEqualTo(collections);
        verify(useCase).executar(correlationId);
    }
}

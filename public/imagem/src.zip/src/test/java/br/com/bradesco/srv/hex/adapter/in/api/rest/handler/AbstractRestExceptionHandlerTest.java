package br.com.bradesco.srv.hex.adapter.in.api.rest.handler;

import static org.assertj.core.api.Assertions.assertThat;


import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import br.com.bradesco.srv.hex.adapter.in.api.rest.response.ErrorResponseAPI;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.NoHandlerFoundException;

import jakarta.validation.constraints.NotBlank;

class AbstractRestExceptionHandlerTest {

    static class Bean {
        @NotBlank(message = "required")
        String name;
    }

    private final AbstractRestExceptionHandler handler = new ApplicationExceptionHandler();
    private final ServletWebRequest request = new ServletWebRequest(new MockHttpServletRequest());

 
    @Test
    void shouldHandleNoHandlerFound() {
        var ex = new NoHandlerFoundException("GET", "/missing", new HttpHeaders());

        var response = handler.handleNoHandlerFoundException(ex, new HttpHeaders(), HttpStatus.NOT_FOUND, request);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
    }

    @Test
    void shouldKeepStatusOfErrorResponseExceptions() {
        var response = handler.handleGenericException(
                new ResponseStatusException(HttpStatus.CONFLICT, "conflict"), request);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatusCode.valueOf(409));
    }

    @Test
    void shouldHandleGenericExceptionAs500() {
        var response = handler.handleGenericException(new IllegalStateException("boom"), request);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(response.getBody()).isInstanceOf(ErrorResponseAPI.class);
        var body = (ErrorResponseAPI) response.getBody();
        assertThat(body.erro().codigo()).isEqualTo("500");
        assertThat(body.erro().mensagem()).isEqualTo("Erro do servidor interno");
        assertThat(body.erro().detalhes()).isEqualTo("boom");
    }
}
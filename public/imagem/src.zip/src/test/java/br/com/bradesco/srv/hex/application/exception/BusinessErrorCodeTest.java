package br.com.bradesco.srv.hex.application.exception;

import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import br.com.bradesco.srv.hex.application.exception.BusinessErrorCode;

import java.util.Arrays;

import static org.assertj.core.api.BDDAssertions.then;

class BusinessErrorCodeTest {

    @Nested
    class EnumIntegrityTests {
        @Test
        void shouldEnumCodesBeUnique() {
            // When
            var codes = Arrays.stream(BusinessErrorCode.values())
                .map(BusinessErrorCode::getCode)
                .toList();
            var uniqueCodes = codes.stream().distinct().toList();
            // Then
            then(codes.size()).isEqualTo(uniqueCodes.size());
        }
    }

    @Nested
    class GetterTests {
        @ParameterizedTest
        @EnumSource(BusinessErrorCode.class)
        void shouldGetCodeAndMessage(BusinessErrorCode errorCode) {
            // When
            String code = errorCode.getCode();
            String message = errorCode.getMessage();
            // Then
            then(code)
                .isNotNull().isEqualTo(errorCode.name());
            then(message)
                .isNotNull();
        }
    }

    @Nested
    class ToStringTests {
        @ParameterizedTest
        @EnumSource(BusinessErrorCode.class)
        void shouldToStringReturnExpectedFormat(BusinessErrorCode businessErrorCode) {
            // When
            var toStringResult = businessErrorCode.toString();
            // Then
            then(toStringResult)
                .isNotNull()
                .isNotBlank()
                .isEqualTo(businessErrorCode.getCode());
        }
    }

    @Nested
    class FormatSubCodeTests {
        @ParameterizedTest
        @EnumSource(BusinessErrorCode.class)
        void shouldFormatSubCodeWithClassNameAndMethod(BusinessErrorCode businessErrorCode) {
            // Given
            String className = "MyClass";
            String methodName = "myMethod";
            // When
            String formattedCode = businessErrorCode.formatSubCode(className, methodName);
            // Then
            then(formattedCode).isEqualTo("%s.%s.%s".formatted(className, methodName, businessErrorCode.getCode()));
        }

        @ParameterizedTest
        @EnumSource(BusinessErrorCode.class)
        void shouldFormatSubCodeWithClassNameOnly(BusinessErrorCode businessErrorCode) {
            // Given
            String className = "MyClass";
            // When
            String formattedCode = businessErrorCode.formatSubCode(className, null);
            // Then
            then(formattedCode).isEqualTo("%s.%s".formatted(className, businessErrorCode.getCode()));
        }

        @ParameterizedTest
        @EnumSource(BusinessErrorCode.class)
        void shouldFormatSubCodeWithClassAndMethod(BusinessErrorCode businessErrorCode) {
            // Given
            Class<?> clazz = Object.class;
            String methodName = "myMethod";
            // When
            String formattedCode = businessErrorCode.formatSubCode(clazz, methodName);
            // Then
            then(formattedCode).isEqualTo("%s.%s.%s".formatted(clazz.getSimpleName(), methodName, businessErrorCode.getCode()));
        }

        @ParameterizedTest
        @EnumSource(BusinessErrorCode.class)
        void shouldFormatSubCodeWithClassOnly(BusinessErrorCode businessErrorCode) {
            // Given
            Class<?> clazz = Object.class;
            // When
            String formattedCode = businessErrorCode.formatSubCode(clazz, null);
            // Then
            then(formattedCode).isEqualTo("%s.%s".formatted(clazz.getSimpleName(), businessErrorCode.getCode()));
        }
    }
}

package br.com.bradesco.srv.hex.util;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class CacheUtilTest {

    private final CacheUtil cache = new CacheUtil();

    @Test
    void chaveAusenteRetornaFalse() {
        assertFalse(cache.contains("ausente"));
    }

    @Test
    void putArmazenaValorEPermiteConsulta() {
        cache.put("chave", "valor");
        assertTrue(cache.contains("chave"));
    }

    @Test
    void sobrescreverChaveMantemChavePresente() {
        cache.put("chave", "um");
        cache.put("chave", "dois");
        assertTrue(cache.contains("chave"));
    }

    @Test
    void controlaMultiplasChavesIndependentemente() {
        cache.put("cpf", "52998224725");
        cache.put("cnpj", "11222333000181");

        assertTrue(cache.contains("cpf"));
        assertTrue(cache.contains("cnpj"));
        assertFalse(cache.contains("nome"));
    }

    @Test
    void putComValorNuloRejeita() {
        assertThrows(NullPointerException.class, () -> cache.put("chave", null));
    }
}
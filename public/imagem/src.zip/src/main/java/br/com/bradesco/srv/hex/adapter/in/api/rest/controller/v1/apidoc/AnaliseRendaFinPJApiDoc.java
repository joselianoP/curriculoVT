package br.com.bradesco.srv.hex.adapter.in.api.rest.controller.v1.apidoc;
 
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
 
 
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@AnaliseRendaCommonApiDoc
@Operation(
	summary = "Análise de Renda PJ",
	description = """
            Recebe os dados declaratórios de Pessoa Jurídica e encaminha
            de forma síncrona para a API de Análise de Faturamento.
        """,
		tags = {
                "validaFin", 
                "infra",
                "tipo-api",
                "asset"
        }
)
@Parameters({
	@Parameter(name = "terminal", 
			in = ParameterIn.HEADER, 
			required = true, 
			description = "Terminal chamador autorizado a acionar o ValidaFin.") ,	
	@Parameter(name = "correlation-Id", 
			in = ParameterIn.HEADER, 
			required = true, 
			description = "Id de indenficicao da transacao")
	})
public @interface AnaliseRendaFinPJApiDoc {
}

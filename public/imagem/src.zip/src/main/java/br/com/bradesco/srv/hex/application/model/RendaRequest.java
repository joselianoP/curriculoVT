package br.com.bradesco.srv.hex.application.model;

public class RendaRequest {

}

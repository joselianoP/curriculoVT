package br.com.bradesco.srv.hex.adapter.in.api.rest.dto;
 
import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;

import br.com.bradesco.srv.hex.util.enumerator.Periodicidade;
import io.swagger.v3.oas.annotations.media.Schema;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Requisição de análise de renda para Pessoa Jurídica")
public record DadosPJRequestDto(
	
		DadosControleDto controle,
       
        @Schema(description = "CNPJ da pessoa jurídica (sem formatação)", example = "12345678000190")
        String cnpj,

        @Schema(description = "Periodicidade do faturamento: 4=Mensal, 5=Trimestral, 7=Anual", example = "4")
        Periodicidade periodicidade,

        @Schema(description = "Ano de referência do faturamento", example = "2024")
        Integer anoReferencia,

        @Schema(description = "Valor de faturamento declarado (conforme periodicidade)", example = "100000.00")
        BigDecimal valorFaturamentoDeclarado

)implements Serializable  {
}

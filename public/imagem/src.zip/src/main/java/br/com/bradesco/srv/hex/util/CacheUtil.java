package br.com.bradesco.srv.hex.util;

import java.util.concurrent.ConcurrentHashMap;

 
public class CacheUtil   {
	private final ConcurrentHashMap<String, Object> c = new ConcurrentHashMap<>();

	public void put(String k, Object v) {
		c.put(k, v);
	}

	public boolean contains(String k) {
		return c.containsKey(k);
	} 
}
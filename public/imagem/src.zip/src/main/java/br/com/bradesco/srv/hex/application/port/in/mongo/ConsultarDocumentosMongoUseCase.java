package br.com.bradesco.srv.hex.application.port.in.mongo;

import br.com.bradesco.srv.hex.application.model.ConsultaMongoResultado;

/** Porta de entrada para consulta dos documentos de um processamento. */
public interface ConsultarDocumentosMongoUseCase {
    ConsultaMongoResultado executar(String correlationId);
}

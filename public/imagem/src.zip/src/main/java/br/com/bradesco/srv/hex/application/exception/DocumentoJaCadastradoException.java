package br.com.bradesco.srv.hex.application.exception;

/** Indica tentativa de registrar um processamento ou documento duplicado. */
public class DocumentoJaCadastradoException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public DocumentoJaCadastradoException(String mensagem) {
        super(mensagem);
    }
}

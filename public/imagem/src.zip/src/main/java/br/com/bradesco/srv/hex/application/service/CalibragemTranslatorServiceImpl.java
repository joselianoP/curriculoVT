package  br.com.bradesco.srv.hex.application.service;

import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import br.com.bradesco.srv.hex.application.exception.InfrastructureException;
import br.com.bradesco.srv.hex.application.model.CalibragemResponse;
import br.com.bradesco.srv.hex.application.model.ValidaFinResponse;
import br.com.bradesco.srv.hex.application.service.inter.CalibragemTranslatorService;
import br.com.bradesco.srv.hex.util.ConstantsUtil;
import br.com.bradesco.srv.hex.util.enumerator.ResultadoAnalise;
import br.com.bradesco.srv.hex.util.enumerator.StatusProcessamento;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
public class CalibragemTranslatorServiceImpl  implements CalibragemTranslatorService {

    private static final String APPROVED_MESSAGE =
            "Validada e aprovada sistemicamente";

    private static final String PROOF_REQUIRED_MESSAGE =
            "Necessário solicitar comprovante";
    
    public ValidaFinResponse translate(
            CalibragemResponse calibration) {
    	
    	  String correlationId = MDC.get(ConstantsUtil.COORELATION_ID);
    	  
        if (calibration == null) {
        	throw  new InfrastructureException(ConstantsUtil.INTERNAL_SERVER_ERROR, ConstantsUtil.CALIB_INVALID_RESPONSE);
        }

        if (possuiErro(calibration)) {
        	throw  new InfrastructureException(ConstantsUtil.INTERNAL_SERVER_ERROR, ConstantsUtil.CALIB_INVALID_RESPONSE);
        }
        
        if (parseFraming(
                calibration.getValorEnquadrado())) {

            return new ValidaFinResponse(
                    ResultadoAnalise.APROVADO_SISTEMICAMENTE,
                    correlationId,
                    1,
                    APPROVED_MESSAGE
            );
        }

        return new ValidaFinResponse(
                ResultadoAnalise.SOLICITAR_COMPROVANTE,
                correlationId,
                2,
                PROOF_REQUIRED_MESSAGE
        );
    }
    
    
    public boolean possuiErro(CalibragemResponse response) {
        return response != null
                && StatusProcessamento.ERRO.name()
                        .equalsIgnoreCase(response.getFonteRerencia());
    }
    

    private boolean parseFraming(String value) {
        return ConstantsUtil.FRAMED.equalsIgnoreCase(value);       
    }
    
}
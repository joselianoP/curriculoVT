package br.com.bradesco.srv.hex.adapter.in.api.rest.mapper;

import org.springframework.stereotype.Component;

import br.com.bradesco.srv.hex.adapter.in.api.rest.dto.DadosPFRequestDto;
import br.com.bradesco.srv.hex.adapter.in.api.rest.dto.DadosPJRequestDto;
import br.com.bradesco.srv.hex.adapter.in.api.rest.dto.ValidaFinResponseDto;
import br.com.bradesco.srv.hex.application.model.DadosPFRequest;
import br.com.bradesco.srv.hex.application.model.DadosPJRequest;
import br.com.bradesco.srv.hex.application.model.ValidaFinResponse;

@Component
public class ValidaFindMapperImpl implements ValidaFindMapper {

    public DadosPFRequest toDomainPF(DadosPFRequestDto dto) {
        return DadosPFRequest.builder()
        		.club(dto.controle().club())
        		.centroDeCusto(dto.controle().centroDeCusto())
        		.cpf(dto.cpf())
                .valorRendaMensalDeclarada(dto.valorRendaMensalDeclarada())
                .build();
    }

    public DadosPJRequest toDomainPJ(DadosPJRequestDto dto) {
        return DadosPJRequest.builder()
          		.club(dto.controle().club())
        		.centroDeCusto(dto.controle().centroDeCusto())
                .cnpj(dto.cnpj())
                .valorFaturamentoDeclarado(dto.valorFaturamentoDeclarado())
                .periodicidade(dto.periodicidade())
                .anoReferencia(dto.anoReferencia())
                .build();
    }

    @Override
    public ValidaFinResponseDto toResponseDto(ValidaFinResponse response) {
        return new ValidaFinResponseDto(
                response.getResultadoAnalise(),
                response.getIdAnalise().toString(),
                response.getStatusComprovacao(),
                response.getMensagem());
    }
}

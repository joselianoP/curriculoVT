package br.com.bradesco.srv.hex.application.service;

import org.springframework.stereotype.Service;

import br.com.bradesco.srv.hex.application.model.DocumentosRelacionados;
import br.com.bradesco.srv.hex.application.port.out.mongo.DocumentosRelacionadosRepositoryPort;
import br.com.bradesco.srv.hex.application.service.inter.RegistrarDocumentoRelacionadoService;
import lombok.extern.log4j.Log4j2;

/**
 * Caso de uso responsável por registrar documentos relacionados
 * a um processamento.
 *
 * <p>Este caso de uso valida os dados obrigatórios do documento
 * e delega sua persistência ao {@link DocumentosRelacionadosRepositoryPort}.
 *
 * <p>Os documentos relacionados são persistidos de forma independente
 * do documento principal de processamento, respeitando a arquitetura
 * hexagonal.
 *
 * <p>Exemplos de documentos relacionados:
 * <ul>
 *     <li>Dados de pessoa física;</li>
 *     <li>Dados de pessoa jurídica;</li>
 *     <li>Resultado da calibragem;</li>
 *     <li>Resultado da validação de cartão;</li>
 *     <li>Resultado do CCR;</li>
 *     <li>Documento enviado para análise.</li>
 * </ul>
 *
 * <p>Exemplo de utilização:
 *
 * <pre>{@code
 * 
 * DocumentosRelacionados.PessoaFisica pessoaFisica =
 *         new DocumentosRelacionados.PessoaFisica(
 *                 "12345678901",
 *                 new BigDecimal("8500.00")
 *         );
 * 
 * DocumentosRelacionados.Documento documento =
 *         new DocumentosRelacionados.Documento(
 *                 null,
 *                 idProcessamento,
 *                 correlationId,
 *                 Instant.now(),
 *                 pessoaFisica
 *         );
 * 
 *  registrarDocumentoRelacionadoUseCase.executar(documento);
 * 
 * -----------------------------
 * 
 * DocumentosRelacionados.Calibragem calibragem =
 *         new DocumentosRelacionados.Calibragem(
 *                 "APROVADO",
 *                 "FONTE_INTERNA",
 *                 new BigDecimal("120000.00"),
 *                 "RECEITA_FEDERAL",
 *                 12
 *         );
 * 
 * DocumentosRelacionados.Documento documento =
 *         new DocumentosRelacionados.Documento(
 *                 null,
 *                 idProcessamento,
 *                 correlationId,
 *                 Instant.now(),
 *                 calibragem
 *         );
 * 
 * registrarDocumentoRelacionadoUseCase.executar(documento);
 * 
 * 
 * 
 *
 * useCase.executar(documento);
 * }</pre>
 *
 * @see DocumentosRelacionados
 * @see DocumentosRelacionadosRepositoryPort
 */
@Service
@Log4j2
public class RegistrarDocumentoRelacionadoServiceImpl implements RegistrarDocumentoRelacionadoService {

    private final DocumentosRelacionadosRepositoryPort repository;

    /**
     * Cria o caso de uso para registrar documentos relacionados.
     *
     * @param repository port de persistência dos documentos relacionados;
     *                  não pode ser {@code null}
     */
    public RegistrarDocumentoRelacionadoServiceImpl(
            DocumentosRelacionadosRepositoryPort repository) {

        if (repository == null) {
            throw new IllegalArgumentException(
                    "Repository de documentos relacionados obrigatório");
        }

        this.repository = repository;
    }

    /**
     * Valida e registra um documento relacionado ao processamento.
     *
     * <p>Antes de persistir o documento, são verificadas as seguintes
     * informações obrigatórias:
     * <ul>
     *     <li>O documento e seu conteúdo devem existir;</li>
     *     <li>O identificador do processamento deve estar preenchido;</li>
     *     <li>O correlationId deve estar preenchido.</li>
     * </ul>
     *
     * <p>Após a validação, o documento é encaminhado ao port de
     * persistência. A implementação concreta do port é responsável
     * por realizar a gravação na coleção MongoDB correspondente.
     *
     * <p>Exemplo:
     *
     * <pre>{@code
     * useCase.executar(documento);
     * }</pre>
     *
     * @param documento documento relacionado que será registrado
     *
     * @throws IllegalArgumentException se o documento for nulo,
     *         se seu conteúdo for nulo, se o idProcessamento
     *        estiver ausente ou se o correlationId estiver ausente
     */
    public void executar(DocumentosRelacionados.Documento documento) {

        log.info("Iniciando registro de documento relacionado. processamentoId={}, correlationId={}, tipoConteudo={}",
                documento == null ? null : documento.idProcessamento(),
                documento == null ? null : documento.correlationId(),
                documento == null || documento.conteudo() == null ? null : documento.conteudo().getClass().getSimpleName());
        if (documento == null || documento.conteudo() == null) {
            throw new IllegalArgumentException(
                    "Documento relacionado obrigatório");
        }

        if (documento.idProcessamento() == null
                || documento.idProcessamento().isBlank()) {
            throw new IllegalArgumentException(
                    "idProcessamento obrigatório");
        }

        if (documento.correlationId() == null
                || documento.correlationId().isBlank()) {
            throw new IllegalArgumentException(
                    "correlationId obrigatório");
        }

        repository.salvar(documento);
        log.info("Documento relacionado registrado. processamentoId={}, correlationId={}",
                documento.idProcessamento(), documento.correlationId());
    }
}
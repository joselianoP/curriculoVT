package br.com.bradesco.srv.hex.application.model;

public record AnaliseRegistrada(
        String idProcessamento,
        String correlationId,
        String tipoPessoa) {
}

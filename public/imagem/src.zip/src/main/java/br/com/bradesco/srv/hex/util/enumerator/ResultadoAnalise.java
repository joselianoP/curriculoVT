package br.com.bradesco.srv.hex.util.enumerator;


public enum ResultadoAnalise {
    APROVADO_SISTEMICAMENTE,
    SOLICITAR_COMPROVANTE
}
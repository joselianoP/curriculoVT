package br.com.bradesco.srv.hex.adapter.in.api.rest.dto;

import java.util.List;
import java.util.Map;

/** Contrato REST da consulta dos documentos MongoDB. */
public record ConsultaMongoResponseDto(
        String cdCorrelationId,
        int totalDocumentos,
        Map<String, List<Map<String, Object>>> collections) {
}

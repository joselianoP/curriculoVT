package br.com.bradesco.srv.hex.util;

public class ConstantsColletionUtil {
	private ConstantsColletionUtil() {
		throw new IllegalStateException("Utility class");
	}

	public static final String VALIDA_FIN_DOCUMENT = "validaFinDocument";
	public static final String PESSOA_FISICA = "pessoaFisica";
	public static final String PESSOA_JURIDICA = "pessoaJuridica";
	public static final String CALIBRAGEM = "calibragem";
	public static final String VALIDACAD = "validacad";
	public static final String CFC = "cfc";
	public static final String DOCUMENT_ENVIADO = "documentoEnviado";
	
	
	public static final String CORRELATION_ID = "cdCorrelationId";
	
}

package br.com.bradesco.srv.hex.application.usecase;

import java.math.BigDecimal;

import org.springframework.stereotype.Service;

import br.com.bradesco.srv.hex.application.model.CalibragemPFRequest;
import br.com.bradesco.srv.hex.application.model.DadosPFRequest;
import br.com.bradesco.srv.hex.application.model.DocumentosRelacionados;
import br.com.bradesco.srv.hex.application.model.Processamento;
import br.com.bradesco.srv.hex.application.model.ValidaFinResponse;
import br.com.bradesco.srv.hex.application.port.in.validafin.AnaliseRendaPFUseCase;
import br.com.bradesco.srv.hex.application.port.out.calibragem.CalibragemPFPort;
import br.com.bradesco.srv.hex.application.service.inter.AnaliseRendaService;
import br.com.bradesco.srv.hex.application.service.inter.CalibragemTranslatorService;
import br.com.bradesco.srv.hex.util.enumerator.TipoPessoa;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AnaliseRendaPFUseCaseImpl implements AnaliseRendaPFUseCase {

    private final CalibragemPFPort calibragemPFPort;
    private final CalibragemTranslatorService calibragemTranslator;
    private final AnaliseRendaService analiseRendaService;

    @Override
    public ValidaFinResponse executar(
            DadosPFRequest request,
            String terminal,
            String authorization) {

        return analiseRendaService.executar(

                request,

                terminal,

                authorization,

                TipoPessoa.PF,

                dados -> new Processamento.Requisicao(
                        dados.getCentroDeCusto(),
                        dados.getClub(),
                        terminal,
                        TipoPessoa.PF.toString(),
                        dados.getCpf()
                ),

                (dados, id, correlationId) ->
                analiseRendaService.criarDocumentoRelacionado(
                        new DocumentosRelacionados.PessoaFisica(
                                dados.getCpf(),
                                dados.getValorRendaMensalDeclarada()
                        ),
                        id,
                        correlationId
                ),
                
                
                (dados, terminalExecucao, autorizacao) ->
                        calibragemPFPort.send(
                                new CalibragemPFRequest(
                                        dados.getCpf(),
                                        dados.getValorRendaMensalDeclarada(),
                                        terminalExecucao
                                ),
                                autorizacao
                        ),

                (resultado, id, correlationId) ->
                        analiseRendaService.criarDocumentoRelacionado(
                                new DocumentosRelacionados.Calibragem(
                                        resultado.getValorEnquadrado(),
                                        null,
                                        BigDecimal.ZERO,
                                        resultado.percentualRendaReferencial(),
                                        resultado.fonteReferencia(),
                                        null
                                ),
                                id,
                                correlationId
                        ),

                calibragemTranslator::translate
        );
    }
}
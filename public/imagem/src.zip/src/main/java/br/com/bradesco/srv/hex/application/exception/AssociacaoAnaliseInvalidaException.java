package br.com.bradesco.srv.hex.application.exception;

import java.io.Serial;

import br.com.bradesco.srv.hex.util.ConstantsUtil;

/**
 * Indica que um retorno de calibragem não pode ser associado a uma análise válida:
 * análise inexistente, de outra modalidade ou com identificação divergente.
 * Não cria nem substitui a análise.
 */
public class AssociacaoAnaliseInvalidaException extends InfrastructureException {

    @Serial
    private static final long serialVersionUID = 1L;

    public AssociacaoAnaliseInvalidaException() {
        super(ConstantsUtil.INTERNAL_SERVER_ERROR,
              ConstantsUtil.CALIB_PF_ASSOCIACAO_INVALIDA);
    }
}

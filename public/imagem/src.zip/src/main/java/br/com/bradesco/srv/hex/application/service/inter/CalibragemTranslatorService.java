package br.com.bradesco.srv.hex.application.service.inter;

import br.com.bradesco.srv.hex.application.model.CalibragemResponse;
import br.com.bradesco.srv.hex.application.model.ValidaFinResponse;

public interface CalibragemTranslatorService {

	ValidaFinResponse translate(CalibragemResponse calibration);
	boolean possuiErro(CalibragemResponse response);
}
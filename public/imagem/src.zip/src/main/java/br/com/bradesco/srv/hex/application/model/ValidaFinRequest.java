package br.com.bradesco.srv.hex.application.model;

import br.com.bradesco.srv.hex.util.enumerator.TipoPessoa;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ValidaFinRequest {

	private String centroDeCusto;

	private String club;

	private String terminal;

	private TipoPessoa tipoPessoa;

	private DadosPFRequest dadosPF;

	private DadosPJRequest dadosPJ;

}
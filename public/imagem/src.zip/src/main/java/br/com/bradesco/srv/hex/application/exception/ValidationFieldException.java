package br.com.bradesco.srv.hex.application.exception;
 

import java.io.Serializable;

public record ValidationFieldException(
        String nome,
        String motivo
) implements Serializable {
}
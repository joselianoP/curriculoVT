package br.com.bradesco.srv.hex.application.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;

public record CalibragemPJRequest(
    @JsonProperty("CNPJ") String cnpj,
    BigDecimal faturamentoAnual,
    String terminal) {
}

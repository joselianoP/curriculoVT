package br.com.bradesco.srv.hex.application.model;

public interface CalibragemResponse {

	String getValorEnquadrado();

	String getFonteRerencia();


}
package br.com.bradesco.srv.hex.adapter.in.api.config;

import static java.util.Optional.ofNullable;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.boot.jackson.autoconfigure.JacksonProperties;
import org.springframework.boot.jackson.autoconfigure.JsonMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import br.com.bradesco.srv.hex.util.BlankStringUtil;
import tools.jackson.databind.ext.javatime.ser.LocalDateTimeSerializer;
import tools.jackson.databind.ext.javatime.ser.ZonedDateTimeSerializer;
import tools.jackson.databind.module.SimpleModule;

@Configuration
public class JsonConfig {

	@Bean
    public JsonMapperBuilderCustomizer jsonDateTimeCustomizer(JacksonProperties jacksonProperties) {
        return builder -> {
            var localDateTimeSerializer = ofNullable(jacksonProperties.getDateFormat())
                .filter(BlankStringUtil::nonBlank)
                .map(DateTimeFormatter::ofPattern)
                .map(LocalDateTimeSerializer::new)
                .orElse(LocalDateTimeSerializer.INSTANCE);
            var zonedDateTimeSerializer = ofNullable(jacksonProperties.getDateFormat())
                .filter(BlankStringUtil::nonBlank)
                .map(format -> format + "XXX")
	                .map(DateTimeFormatter::ofPattern)
	                .map(ZonedDateTimeSerializer::new)
	                .orElse(ZonedDateTimeSerializer.INSTANCE);
	            builder.addModule(new SimpleModule()
	                .addSerializer(LocalDateTime.class, localDateTimeSerializer)
	                .addSerializer(ZonedDateTime.class, zonedDateTimeSerializer));
	        };
	    }
}

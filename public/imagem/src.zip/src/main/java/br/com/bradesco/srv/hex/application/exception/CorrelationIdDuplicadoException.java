package br.com.bradesco.srv.hex.application.exception;

public class CorrelationIdDuplicadoException extends RuntimeException {
    private final String correlationId;

    public CorrelationIdDuplicadoException(String correlationId) {
        super("Ja existe um processamento com o correlationId informado: " + correlationId);
        this.correlationId = correlationId;
    }

    public String getCorrelationId() { return correlationId; }
}

package br.com.bradesco.srv.hex.adapter.in.api.rest.controller.v1.apidoc;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.http.ProblemDetail;

import br.com.bradesco.srv.hex.adapter.in.api.rest.dto.ValidaFinResponseDto;
import br.com.bradesco.srv.hex.adapter.in.api.rest.response.ErrorResponseAPI;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;



@Target({
    ElementType.METHOD,
    ElementType.ANNOTATION_TYPE
})
@Retention(RetentionPolicy.RUNTIME)
@ApiResponses({
    @ApiResponse(
            responseCode = "200",
            description = "Requisição processada com sucesso.",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ValidaFinResponseDto.class),
                    examples = @ExampleObject(value = """
                            {
                              "resultadoAnalise": "APROVADO_SISTEMICAMENTE",
                              "idAnalise": "ANL-123456",
                              "statusComprovacao": 2,
                              "mensagem": "mensagem"
                            }
                            """)
            )
    ),
    @ApiResponse(
            responseCode = "400",
            description = "Requisição inválida ou falha de validação.",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(oneOf = {ErrorResponseAPI.class, ProblemDetail.class}),
                    examples = {
                            @ExampleObject(name = "Erro de validação", value = """
                                    {
                                      "erro": {
                                        "codigo": "400",
                                        "mensagem": "Requisição inválida",
                                        "detalhes": "Campo obrigatório",
                                        "correlationId": "123e4567-e89b-12d3-a456-426614174000"
                                      }
                                    }
                                    """),
                            @ExampleObject(name = "Erro de formato", value = """
                                    {
                                      "type": "about:blank",
                                      "title": "Bad Request",
                                      "status": 400,
                                      "detail": "Invalid request"
                                    }
                                    """)
                    }
            )
    ),
    @ApiResponse(
            responseCode = "401",
            description = "Falha de autenticação."
    ),
    @ApiResponse(
            responseCode = "403",
            description = "Terminal ou credencial sem autorização."
    ),
    @ApiResponse(
            responseCode = "404",
            description = "Recurso não encontrado.",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponseAPI.class),
                    examples = @ExampleObject(value = """
                            {
                              "erro": {
                                "codigo": "404",
                                "mensagem": "Recurso não encontrado",
                                "detalhes": "Recurso solicitado não encontrado",
                                "correlationId": "123e4567-e89b-12d3-a456-426614174000"
                              }
                            }
                            """)
            )
    ),
    @ApiResponse(
            responseCode = "409",
            description = "Processamento duplicado ou documento já em análise.",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponseAPI.class),
                    examples = @ExampleObject(value = """
                            {
                              "erro": {
                                "codigo": "409",
                                "mensagem": "Processamento duplicado",
                                "detalhes": "Já existe processamento para o correlationId informado",
                                "correlationId": "123e4567-e89b-12d3-a456-426614174000"
                              }
                            }
                            """)
            )
    ),
    @ApiResponse(
            responseCode = "422",
            description = "Falha de regra de negócio.",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponseAPI.class),
                    examples = @ExampleObject(value = """
                            {
                              "erro": {
                                "codigo": "422",
                                "mensagem": "Regra de negócio não atendida",
                                "detalhes": "A solicitação não pode ser processada",
                                "correlationId": "123e4567-e89b-12d3-a456-426614174000"
                              }
                            }
                            """)
            )
    ),
    @ApiResponse(
            responseCode = "429",
            description = "Limite de envio de documentos excedido.",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponseAPI.class),
                    examples = @ExampleObject(value = """
                            {
                              "erro": {
                                "codigo": "429",
                                "mensagem": "Limite de envio excedido",
                                "detalhes": "Limite de envio de documentos excedido",
                                "correlationId": "123e4567-e89b-12d3-a456-426614174000"
                              }
                            }
                            """)
            )
    ),
    @ApiResponse(
            responseCode = "500",
            description = "Erro interno.",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(oneOf = {ErrorResponseAPI.class, ProblemDetail.class}),
                    examples = {
                            @ExampleObject(name = "Erro da aplicação", value = """
                                    {
                                      "erro": {
                                        "codigo": "500",
                                        "mensagem": "Erro interno do servidor",
                                        "detalhes": "Falha ao processar a solicitação",
                                        "correlationId": "123e4567-e89b-12d3-a456-426614174000"
                                      }
                                    }
                                    """),
                            @ExampleObject(name = "Erro não mapeado", value = """
                                    {
                                      "type": "about:blank",
                                      "title": "Internal Server Error",
                                      "status": 500,
                                      "detail": "Internal server error"
                                    }
                                    """)
                    }
            )
    ),
    @ApiResponse(
            responseCode = "503",
            description = "Serviço de análise indisponível.",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponseAPI.class),
                    examples = @ExampleObject(value = """
                            {
                              "erro": {
                                "codigo": "503",
                                "mensagem": "Serviço indisponível",
                                "detalhes": "Serviço de análise indisponível",
                                "correlationId": "123e4567-e89b-12d3-a456-426614174000"
                              }
                            }
                            """)
            )
    )
})
public @interface AnaliseRendaCommonApiDoc {
}

package br.com.bradesco.srv.hex.application.service;

import org.springframework.stereotype.Service;

import br.com.bradesco.srv.hex.application.model.Processamento;
import br.com.bradesco.srv.hex.application.port.out.mongo.ProcessamentoRepositoryPort;
import br.com.bradesco.srv.hex.application.service.inter.RegistrarStepService;
import lombok.extern.log4j.Log4j2;

/**
 * Caso de uso responsável por registrar etapas do processamento.
 *
 * <p>Permite registrar o histórico de execução de cada etapa,
 * acompanhando seu nome, status, instante de início e mensagem.
 *
 * <p>Cada chamada ao método
 * {@link #executar(String, String, Processamento.StepProcessamento)}
 * registra uma nova etapa no histórico do processamento identificado
 * pelo idProcessamento e correlationId.
 *
 * <p>As etapas são armazenadas no campo {@code steps} do documento
 * principal de processamento, persistido na coleção
 * {@code validaFinDocument}.
 *
 * <p>O caso de uso depende exclusivamente do
 * {@link ProcessamentoRepositoryPort}, respeitando a arquitetura
 * hexagonal.
 *
 * <h2>Exemplos de utilização</h2>
 *
 * <h3>1. Registrar o início de uma análise</h3>
 *
 * <p>Uma etapa pode ser registrada com o status PROCESSANDO
 * para indicar que sua execução foi iniciada.
 *
 * <pre>{@code
 * Instant inicio = Instant.now();
 *
 * Processamento.StepProcessamento step =
 *         new Processamento.StepProcessamento(
 *                 "STEP 1",
 *                 "EM PROCESSANDO",
 *                 inicio,
 *                 "Iniciando análise de renda"
 *         );
 *
 * registrarStepUseCase.executar(
 *         idProcessamento,
 *         correlationId,
 *         step
 * );
 * }</pre>
 *
 * <h3>2. Registrar o resultado da análise</h3>
 *
 * <p>Após a conclusão da análise, uma nova etapa pode ser registrada
 * para indicar o resultado da execução.
 *
 * <pre>{@code
 * Processamento.StepProcessamento step =
 *         new Processamento.StepProcessamento(
 *                 "ANALISE_RENDA",
 *                 "SUCESSO",
 *                 Instant.now(),
 *                 "Análise de renda concluída: APROVADO"
 *         );
 *
 * registrarStepUseCase.executar(
 *         idProcessamento,
 *         correlationId,
 *         step
 * );
 * }</pre>
 *
 * <h3>3. Registrar uma falha</h3>
 *
 * <p>Em caso de falha durante a execução de uma etapa, pode ser
 * registrado o status ERRO e a mensagem correspondente.
 *
 * <pre>{@code
 * Processamento.StepProcessamento step =
 *         new Processamento.StepProcessamento(
 *                 "ANALISE_RENDA",
 *                 "ERRO",
 *                 Instant.now(),
 *                 "Falha ao consultar o serviço de análise de renda"
 *         );
 *
 * registrarStepUseCase.executar(
 *         idProcessamento,
 *         correlationId,
 *         step
 * );
 * }</pre>
 *
 * <p>As chamadas são independentes. O adapter de saída é responsável
 * por adicionar cada etapa ao array {@code steps}, preservando
 * o histórico das etapas anteriores.
 *
 * @see Processamento
 * @see Processamento.StepProcessamento
 * @see ProcessamentoRepositoryPort
 */
@Service
@Log4j2
public class RegistrarStepServiceImpl implements RegistrarStepService {

    private final ProcessamentoRepositoryPort repository;

    /**
     * Cria o caso de uso responsável pelo registro de etapas.
     *
     * @param repository porta de persistência do processamento
     */
    public RegistrarStepServiceImpl(ProcessamentoRepositoryPort repository) {
        this.repository = repository;
    }

    /**
     * Registra uma nova etapa no histórico do processamento.
     *
     * <p>Valida os dados obrigatórios e delega o registro ao
     * port de persistência.
     *
     * <p>Exemplo:
     *
     * <pre>{@code
     * Processamento.StepProcessamento step =
     *         new Processamento.StepProcessamento(
     *                 "VALIDACAO_DOCUMENTO",
     *                 "PROCESSANDO",
     *                 Instant.now(),
     *                 "Iniciando validação do documento"
     *         );
     *
     * registrarStepUseCase.executar(
     *         idProcessamento,
     *         correlationId,
     *         step
     * );
     * }</pre>
     *
     * @param idProcessamento identificador do processamento
     * @param correlationId identificador de correlação da requisição
     * @param step etapa que será registrada
     *
     * @throws IllegalArgumentException se o idProcessamento estiver ausente,
     *         se o correlationId estiver ausente ou se a etapa ou seu nome
     *        forem inválidos
     */
    public void executar(
            String idProcessamento,
            String correlationId,
            Processamento.StepProcessamento step) {
 
        validarEntrada(idProcessamento, correlationId, step);

        repository.registrarStep(
                idProcessamento,
                correlationId,
                step);
         
    }

    /**
     * Valida os dados obrigatórios para o registro da etapa.
     *
     * @param idProcessamento identificador do processamento
     * @param correlationId identificador de correlação da requisição
     * @param step etapa que será validada
     * @throws IllegalArgumentException se algum dado obrigatório estiver ausente
     */
    private void validarEntrada(
            String idProcessamento,
            String correlationId,
            Processamento.StepProcessamento step) {

        if (idProcessamento == null || idProcessamento.isBlank()) {
            throw new IllegalArgumentException(
                    "idProcessamento obrigatório");
        }

        if (correlationId == null || correlationId.isBlank()) {
            throw new IllegalArgumentException(
                    "correlationId obrigatório");
        }

        if (step == null || step.nome() == null || step.nome().isBlank()) {
            throw new IllegalArgumentException(
                    "Step e nome do step são obrigatórios");
        }
    }
}
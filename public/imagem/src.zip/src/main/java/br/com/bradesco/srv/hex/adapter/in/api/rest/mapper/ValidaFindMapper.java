package br.com.bradesco.srv.hex.adapter.in.api.rest.mapper;

import br.com.bradesco.srv.hex.adapter.in.api.rest.dto.DadosPFRequestDto;
import br.com.bradesco.srv.hex.adapter.in.api.rest.dto.DadosPJRequestDto;
import br.com.bradesco.srv.hex.adapter.in.api.rest.dto.ValidaFinResponseDto;
import br.com.bradesco.srv.hex.application.model.DadosPFRequest;
import br.com.bradesco.srv.hex.application.model.DadosPJRequest;
import br.com.bradesco.srv.hex.application.model.ValidaFinResponse;

public interface ValidaFindMapper {

    DadosPFRequest toDomainPF(DadosPFRequestDto dto);

    DadosPJRequest toDomainPJ(DadosPJRequestDto dto);

    ValidaFinResponseDto toResponseDto(ValidaFinResponse response);
}

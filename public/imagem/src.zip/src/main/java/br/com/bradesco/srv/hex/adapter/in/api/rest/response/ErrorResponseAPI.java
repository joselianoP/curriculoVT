package br.com.bradesco.srv.hex.adapter.in.api.rest.response;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Envelope padronizado de erro da API.")
public record ErrorResponseAPI(
        @Schema(description = "Detalhes do erro.")
        ErrorDetail erro
) {
}
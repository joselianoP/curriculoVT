package br.com.bradesco.srv.hex.application.service;

import java.time.Instant;
import java.util.function.Function;

import org.slf4j.MDC;
import org.springframework.stereotype.Service;

import br.com.bradesco.srv.hex.application.model.DocumentosRelacionados;
import br.com.bradesco.srv.hex.application.model.Processamento;
import br.com.bradesco.srv.hex.application.model.ValidaFinResponse;
import br.com.bradesco.srv.hex.application.service.inter.AnaliseRendaService;
import br.com.bradesco.srv.hex.application.service.inter.RegistrarDocumentoRelacionadoService;
import br.com.bradesco.srv.hex.application.service.inter.RegistrarStepService;
import br.com.bradesco.srv.hex.application.service.inter.RegistrarValidaFinDocumentService;
import br.com.bradesco.srv.hex.util.ConstantsUtil;
import br.com.bradesco.srv.hex.util.enumerator.EtapaProcessamento;
import br.com.bradesco.srv.hex.util.enumerator.TipoPessoa;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class AnaliseRendaServiceImpl implements AnaliseRendaService {

    private static final String VERSAO_PROCESSAMENTO = "1";
    private static final String MENSAGEM_VAZIA = "";

    private final RegistrarValidaFinDocumentService registrarValidaFinDocumentService;
    private final RegistrarStepService registrarStepService;
    private final RegistrarDocumentoRelacionadoService registrarDocumentoRelacionadoService;

    @Override
    public <T, R> ValidaFinResponse executar(
            T request,
            String terminal,
            String authorization,
            TipoPessoa tipoPessoa,
            Function<T, Processamento.Requisicao> criarRequisicao,
            DocumentoPessoaFactory<T> criarDocumentoPessoa,
            CalibragemExecutor<T, R> executarCalibragem,
            DocumentoResultadoFactory<R> criarDocumentoResultado,
            Function<R, ValidaFinResponse> traduzirResultado) {

        String correlationId = MDC.get(ConstantsUtil.COORELATION_ID);
        String idProcessamento = null;

        try {

            
            idProcessamento = registrarValidaFinDocumentService.executar( 
            		new Processamento(
	                    correlationId,
	                    VERSAO_PROCESSAMENTO,
	                    criarRequisicao.apply(request),
	                    null
            		)
            );

            registrarDocumentoRelacionadoService.executar(
                    criarDocumentoPessoa.criar(
                            request,
                            idProcessamento,
                            correlationId
                    )
            );

            R resultadoCalibragem = executarCalibragem.executar(
                    request,
                    terminal,
                    authorization
            );

            ValidaFinResponse resposta = traduzirResultado.apply(resultadoCalibragem);

            registrarDocumentoRelacionadoService.executar(
                    criarDocumentoResultado.criar(
                            resultadoCalibragem,
                            idProcessamento,
                            correlationId
                    )
            );

            gravarStep(
                    idProcessamento,
                    correlationId,
                    resposta.getResultadoAnalise().toString(),
                    MENSAGEM_VAZIA
            );

            log.info(
                    "Análise de renda {} concluída. resultado={}, correlationId={}",
                    tipoPessoa,
                    resposta.getResultadoAnalise(),
                    correlationId
            );

            return resposta;

        } catch (RuntimeException ex) {

            registrarFalha(idProcessamento, correlationId, ex);

            throw ex;
        }
    }

    @Override
    public <T extends DocumentosRelacionados.Conteudo>
            DocumentosRelacionados.Documento criarDocumentoRelacionado(
                    T documento,
                    String idProcessamento,
                    String correlationId) {

        return new DocumentosRelacionados.Documento(
                null,
                idProcessamento,
                correlationId,
                Instant.now(),
                documento
        );
    }

    private void registrarFalha(
            String idProcessamento,
            String correlationId,
            RuntimeException exception) {

        if (idProcessamento == null || idProcessamento.isBlank()) {
            return;
        }

        try {

            gravarStep(
                    idProcessamento,
                    correlationId,
                    EtapaProcessamento.ERRO.toString(),
                    exception.getMessage()
            );

        } catch (RuntimeException erroRegistro) {

            exception.addSuppressed(erroRegistro);

            log.error(
                    "Erro ao registrar falha do processamento. correlationId={}",
                    correlationId,
                    erroRegistro
            );
        }
    }

    private void gravarStep(
            String idProcessamento,
            String correlationId,
            String statusProcessamento,
            String mensagemProcessamento) {

        Processamento.StepProcessamento step =
                new Processamento.StepProcessamento(
                        EtapaProcessamento.STEP1.toString(),
                        statusProcessamento,
                        Instant.now(),
                        mensagemProcessamento
                );

        registrarStepService.executar(
                idProcessamento,
                correlationId,
                step
        );
    }
}
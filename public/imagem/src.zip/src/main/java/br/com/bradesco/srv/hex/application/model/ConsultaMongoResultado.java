package br.com.bradesco.srv.hex.application.model;

import java.util.List;
import java.util.Map;

/** Resultado agnóstico de infraestrutura para consulta de documentos por correlationId. */
public record ConsultaMongoResultado(
        String correlationId,
        int totalDocumentos,
        Map<String, List<Map<String, Object>>> collections) {
}

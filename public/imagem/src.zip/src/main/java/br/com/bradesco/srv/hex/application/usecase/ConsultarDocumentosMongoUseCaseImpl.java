package br.com.bradesco.srv.hex.application.usecase;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import br.com.bradesco.srv.hex.application.exception.InvalidInputException;
import br.com.bradesco.srv.hex.application.model.ConsultaMongoResultado;
import br.com.bradesco.srv.hex.application.port.in.mongo.ConsultarDocumentosMongoUseCase;
import br.com.bradesco.srv.hex.application.port.out.mongo.ConsultaDocumentosMongoPort;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ConsultarDocumentosMongoUseCaseImpl implements ConsultarDocumentosMongoUseCase {

    private final ConsultaDocumentosMongoPort consultaDocumentosMongoPort;

    @Override
    public ConsultaMongoResultado executar(String correlationId) {
        if (!StringUtils.hasText(correlationId)) {
            throw new InvalidInputException("ConsultaMongo", "executar", "correlationId é obrigatório");
        }

        Map<String, List<Map<String, Object>>> collections =
                consultaDocumentosMongoPort.buscarPorCorrelationId(correlationId);
        
        int total = collections.values().stream().mapToInt(List::size).sum();
        
        return new ConsultaMongoResultado(correlationId, total, collections);
    }
}

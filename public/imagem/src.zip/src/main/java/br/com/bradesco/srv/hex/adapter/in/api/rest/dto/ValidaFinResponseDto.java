package br.com.bradesco.srv.hex.adapter.in.api.rest.dto;
 
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import br.com.bradesco.srv.hex.util.enumerator.ResultadoAnalise;
import io.swagger.v3.oas.annotations.media.Schema;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record ValidaFinResponseDto(

        @Schema(description = "Resultado da análise de renda.")
        ResultadoAnalise resultadoAnalise,

        @Schema(description = "Identificador da análise.", example = "ANL-123456")
        String idAnalise,

        @Schema(description = "Status da comprovação de renda.", example = "2")
        Integer statusComprovacao,

        @Schema(description = "Mensagem associada ao resultado da análise.", example = "mensagem")
        String mensagem

)implements Serializable  {
}

package br.com.bradesco.srv.hex.util.enumerator;


public enum TipoPessoa {
    PF,
    PJ
}
package br.com.bradesco.srv.hex.application.service.inter;

import br.com.bradesco.srv.hex.application.model.Processamento;

/**
 * Contrato do caso de uso RegistrarValidaFinDocumentService.
 */
public interface RegistrarValidaFinDocumentService {

    /**
     * Executa o caso de uso.
     *
     * @param entrada dados de entrada do caso de uso
     */
	
	String executar(Processamento entrada);
}

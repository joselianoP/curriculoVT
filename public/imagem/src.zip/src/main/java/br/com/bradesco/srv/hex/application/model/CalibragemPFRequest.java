package br.com.bradesco.srv.hex.application.model;

import java.math.BigDecimal;

public record CalibragemPFRequest(String cpf, BigDecimal renda, String terminal) {
}

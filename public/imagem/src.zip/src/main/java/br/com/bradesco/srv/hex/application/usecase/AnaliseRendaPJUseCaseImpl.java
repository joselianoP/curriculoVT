package br.com.bradesco.srv.hex.application.usecase;

import java.math.BigDecimal;

import org.springframework.stereotype.Service;

import br.com.bradesco.srv.hex.application.model.CalibragemPJRequest;
import br.com.bradesco.srv.hex.application.model.DadosPJRequest;
import br.com.bradesco.srv.hex.application.model.DocumentosRelacionados;
import br.com.bradesco.srv.hex.application.model.Processamento;
import br.com.bradesco.srv.hex.application.model.ValidaFinResponse;
import br.com.bradesco.srv.hex.application.port.in.validafin.AnaliseRendaPJUseCase;
import br.com.bradesco.srv.hex.application.port.out.calibragem.CalibragemPJPort;
import br.com.bradesco.srv.hex.application.service.inter.AnaliseRendaService;
import br.com.bradesco.srv.hex.application.service.inter.CalibragemTranslatorService;
import br.com.bradesco.srv.hex.util.enumerator.TipoPessoa;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AnaliseRendaPJUseCaseImpl implements AnaliseRendaPJUseCase {

    private final CalibragemPJPort calibragemPJPort;
    private final CalibragemTranslatorService calibragemTranslator;
    private final AnaliseRendaService analiseRendaService;

    @Override
    public ValidaFinResponse executar(
            DadosPJRequest request,
            String terminal,
            String authorization) {

        return analiseRendaService.executar(

                request,

                terminal,

                authorization,

                TipoPessoa.PJ,

                dados -> new Processamento.Requisicao(
                        dados.getCentroDeCusto(),
                        dados.getClub(),
                        terminal,
                        TipoPessoa.PJ.toString(),
                        dados.getCnpj()
                ),

                (dados, id, correlationId) ->
                analiseRendaService.criarDocumentoRelacionado(
                        new DocumentosRelacionados.PessoaJuridica(
                                dados.getCnpj(),
                                dados.getPeriodicidade().meses(),
                                dados.getAnoReferencia(),
                                dados.getValorFaturamentoDeclarado()
                        ),
                        id,
                        correlationId
                ),
                
                (dados, terminalExecucao, autorizacao) ->
                        calibragemPJPort.send(
                                new CalibragemPJRequest(
                                        dados.getCnpj(),
                                        dados.getValorFaturamentoDeclarado(),
                                        terminalExecucao
                                ),
                                autorizacao
                        ),

                (resultado, id, correlationId) ->
                        analiseRendaService.criarDocumentoRelacionado(
                                new DocumentosRelacionados.Calibragem(
                                        resultado.getValorEnquadrado(),
                                        resultado.identificadoFonte(),
                                        resultado.faturamentoReferencial(),
                                        BigDecimal.ZERO,
                                        resultado.fonte(),
                                        resultado.periodicidade()
                                ),
                                id,
                                correlationId
                        ),

                calibragemTranslator::translate
        );
    }
}
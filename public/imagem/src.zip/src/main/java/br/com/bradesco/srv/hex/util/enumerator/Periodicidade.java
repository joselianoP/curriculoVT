package br.com.bradesco.srv.hex.util.enumerator;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.math.BigDecimal;

public enum Periodicidade {

    MENSAL(4, 12),
    TRIMESTRAL(5, 4),
    ANUAL(7, 1);

    private final int codigo;
    private final int meses;

    Periodicidade(final int codigo, final int meses) {
        this.codigo = codigo;
        this.meses = meses;
    }
    @JsonValue
    public int codigo() {
        return codigo;
    }

    public int meses() {
        return meses;
    }

    @JsonCreator
    public static Periodicidade fromCodigo(Integer codigo) {
        return java.util.Arrays.stream(Periodicidade.values())
            .filter(p -> p.codigo == codigo)
            .findFirst()
            .orElseThrow(() -> new IllegalArgumentException("Codigo de periodicidade invalido: " + codigo + ". Valores validos: 4 (MENSAL), 5 (TRIMESTRAL), 7 (ANUAL)"));
    }

    public static BigDecimal calcularRendaAnual(Periodicidade periodicidade, BigDecimal valor) {
        return valor.multiply(BigDecimal.valueOf(periodicidade.meses()));
    }
}

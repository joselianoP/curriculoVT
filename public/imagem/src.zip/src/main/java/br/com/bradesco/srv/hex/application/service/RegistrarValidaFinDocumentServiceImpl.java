package br.com.bradesco.srv.hex.application.service;

import org.springframework.stereotype.Service;

import br.com.bradesco.srv.hex.application.model.Processamento;
import br.com.bradesco.srv.hex.application.port.out.mongo.ProcessamentoRepositoryPort;
import br.com.bradesco.srv.hex.application.service.inter.RegistrarValidaFinDocumentService;
import lombok.extern.log4j.Log4j2;

/**
 * Caso de uso responsável por registrar o documento principal do processamento
 * na coleção validaFinDocument.
 *
 * <p>Este caso de uso realiza as seguintes operações:
 * <ol>
 *     <li>Valida os dados obrigatórios de entrada.</li>
 *     <li>Verifica se existe duplicidade de processamento.</li>
 *     <li>Verifica se o documento informado já está em processamento,
 *         considerando o número da requisição e o tipo de pessoa.</li>
 *     <li>Salva o documento principal.</li>
 * </ol>
 *
 * <p>Os documentos relacionados, como Pessoa Física, Pessoa Jurídica,
 * Calibragem, Validacad, CCR e Documento Enviado, devem ser registrados
 * por seus respectivos casos de uso.
 *
 * <p>Exemplo de utilização:
 *
 * <pre>{@code
 * Processamento entrada = new Processamento(
 *     "id-processamento-123",
 *     "correlation-123",
 *     "REQ-123",
 *     new Processamento.Requisicao(
 *             "REQ-123",
 *             "1234",
 *             "CLUB-01",
 *             "TERMINAL-01",
 *             "PF"
 *     )
 * );
 *
 * registrarValidaFinDocumentUseCase.executar(entrada);
 * }</pre>
 *
 * <p>Se a entrada for inválida ou houver uma duplicidade identificada
 * pelo repositório, o processamento não será salvo.
 */
@Service
@Log4j2
public class RegistrarValidaFinDocumentServiceImpl implements RegistrarValidaFinDocumentService {

    private final ProcessamentoRepositoryPort repository;

    /**
     * Cria uma instância do caso de uso.
     *
     * @param repository porta de repositório responsável pelas validações
     *                  e pela persistência do documento principal
     */
    public RegistrarValidaFinDocumentServiceImpl(
            ProcessamentoRepositoryPort repository) {
        this.repository = repository;
    }

    /**
     * Executa o registro do documento principal.
     *
     * <p>Antes de salvar, valida os campos obrigatórios e solicita ao
     * repositório a verificação de duplicidade e de documento em processamento.
     *
     * <p>A validação de documento em processamento será realizada somente
     * quando o número da requisição estiver preenchido.
     *
     * <p>Exemplo:
     *
     * <pre>{@code
     * registrarValidaFinDocumentUseCase.executar(entrada);
     * }</pre>
     *
     * @param entrada dados do processamento que será registrado
     * @throws IllegalArgumentException caso o processamento, o id ou
     *                                  o correlationId sejam inválidos
     */
    public String executar(Processamento entrada) {

        log.info("Iniciando processamento principal. correlationId={}", entrada.correlationId());
        validarEntrada(entrada);

        log.debug("Validando duplicidade por correlationId={}", entrada.correlationId());

        repository.validarDuplicidade(entrada);
        if (entrada.requisicao() != null) {

            log.debug("Validando documento em processamento. numero={}, tipoPessoa={}",
                    entrada.requisicao().tipoPessoa());
            
            repository.validarDocumentoEmProcessamento(
                    entrada.requisicao().Documento(),
                    entrada.requisicao().tipoPessoa());
        }

        log.info("Processamento principal registrado com sucesso.  correlationId={}",
                 entrada.correlationId());
        
       return  repository.salvarPrincipal(entrada);
         
    }

    /**
     * Valida os dados obrigatórios para o registro do documento principal.
     *
     * @param entrada processamento recebido para validação
     * @throws IllegalArgumentException caso o processamento seja nulo
     *                                  ou possua campos obrigatórios vazios
     */
    private void validarEntrada(Processamento entrada) {

        if (entrada == null) {
            throw new IllegalArgumentException("Processamento obrigatório");
        }

        validarCampoObrigatorio(entrada.correlationId(), "correlationId");
    }

    /**
     * Valida se um campo obrigatório foi informado.
     *
     * @param valor valor do campo que será validado
     * @param nomeCampo nome do campo para identificação da mensagem de erro
     * @throws IllegalArgumentException caso o campo seja nulo ou vazio
     */
    private void validarCampoObrigatorio(String valor, String nomeCampo) {

        if (valor == null || valor.isBlank()) {
            throw new IllegalArgumentException(nomeCampo + " obrigatório");
        }
    }
}
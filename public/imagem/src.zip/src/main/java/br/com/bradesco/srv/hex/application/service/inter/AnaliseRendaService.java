package br.com.bradesco.srv.hex.application.service.inter;

import java.util.function.Function;

import br.com.bradesco.srv.hex.application.model.DocumentosRelacionados;
import br.com.bradesco.srv.hex.application.model.Processamento;
import br.com.bradesco.srv.hex.application.model.ValidaFinResponse;
import br.com.bradesco.srv.hex.util.enumerator.TipoPessoa;

public interface AnaliseRendaService {

    <T, R> ValidaFinResponse executar(
            T request,
            String terminal,
            String authorization,
            TipoPessoa tipoPessoa,
            Function<T, Processamento.Requisicao> criarRequisicao,
            DocumentoPessoaFactory<T> criarDocumentoPessoa,
            CalibragemExecutor<T, R> executarCalibragem,
            DocumentoResultadoFactory<R> criarDocumentoResultado,
            Function<R, ValidaFinResponse> traduzirResultado
    );

    <T extends DocumentosRelacionados.Conteudo>
    DocumentosRelacionados.Documento criarDocumentoRelacionado(
            T documento,
            String idProcessamento,
            String correlationId
    );

    @FunctionalInterface
    interface CalibragemExecutor<T, R> {

        R executar(T request, String terminal, String authorization);
    }

    @FunctionalInterface
    interface DocumentoPessoaFactory<T> {

        DocumentosRelacionados.Documento criar(
                T request,
                String idProcessamento,
                String correlationId
        );
    }

    @FunctionalInterface
    interface DocumentoResultadoFactory<R> {

        DocumentosRelacionados.Documento criar(
                R resultado,
                String idProcessamento,
                String correlationId
        );
    }
}
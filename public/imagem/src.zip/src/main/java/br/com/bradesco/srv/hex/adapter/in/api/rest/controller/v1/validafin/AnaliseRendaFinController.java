package br.com.bradesco.srv.hex.adapter.in.api.rest.controller.v1.validafin;

import org.slf4j.MDC;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.bradesco.srv.hex.adapter.in.api.rest.controller.v1.apidoc.AnaliseRendaFinPFApiDoc;
import br.com.bradesco.srv.hex.adapter.in.api.rest.controller.v1.apidoc.AnaliseRendaFinPJApiDoc;
import br.com.bradesco.srv.hex.adapter.in.api.rest.dto.DadosPFRequestDto;
import br.com.bradesco.srv.hex.adapter.in.api.rest.dto.DadosPJRequestDto;
import br.com.bradesco.srv.hex.adapter.in.api.rest.dto.ValidaFinResponseDto;
import br.com.bradesco.srv.hex.adapter.in.api.rest.mapper.ValidaFindMapper;
import br.com.bradesco.srv.hex.application.model.ValidaFinResponse;
import br.com.bradesco.srv.hex.application.port.in.validafin.AnaliseRendaPFUseCase;
import br.com.bradesco.srv.hex.application.port.in.validafin.AnaliseRendaPJUseCase;
import br.com.bradesco.srv.hex.util.ConstantsUtil;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/v1")
@SecurityRequirement(name = "bearerAuth")
public class AnaliseRendaFinController {
	

    private static final String LOG_CORRELATION = "get correlation - {}";

    private final ValidaFindMapper validaFindMapper;
    private final AnaliseRendaPFUseCase analisarPFUseCase;
    private final AnaliseRendaPJUseCase analisarPJUseCase;
    
    
    @AnaliseRendaFinPFApiDoc
    @PostMapping("/analise-renda-pf")
    public ResponseEntity<ValidaFinResponseDto> analiseRendaPF(
            @RequestBody DadosPFRequestDto request,
            @RequestHeader(ConstantsUtil.TERMINAL_HEADER) String terminal,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String authorization,
            @RequestHeader(ConstantsUtil.COORELATION_ID) String correlationId) {
		    	 
        log.info("[Controller][Entrada] endpoint=validafin centroDeCusto={} terminal={} club={}",
                request.controle().centroDeCusto(),
                terminal,
                request.controle().club());
        
        MDC.put(ConstantsUtil.COORELATION_ID, correlationId);
        
        log.info(ConstantsUtil.TERMINAL_HEADER, terminal);
        log.info(LOG_CORRELATION, correlationId);
        log.info("authorization", authorization);

        var domainRequest = validaFindMapper.toDomainPF(request);
        ValidaFinResponse response = analisarPFUseCase.executar(domainRequest, terminal, authorization);

        return ResponseEntity.ok(validaFindMapper.toResponseDto(response));
    }

    @AnaliseRendaFinPJApiDoc
    @PostMapping("/analise-faturamento-pj")
    public ResponseEntity<ValidaFinResponseDto> analiseRendaPJ(
            @RequestBody DadosPJRequestDto request,
            @RequestHeader(ConstantsUtil.TERMINAL_HEADER) String terminal,
            @RequestHeader(HttpHeaders.AUTHORIZATION) String authorization,
            @RequestHeader(ConstantsUtil.COORELATION_ID) String correlationId
      ) {

    	 MDC.put(ConstantsUtil.COORELATION_ID, correlationId);
    	 
        log.info(ConstantsUtil.TERMINAL_HEADER, terminal);
        log.info(LOG_CORRELATION, correlationId);
        log.info("authorization", authorization);

        var domainRequest = validaFindMapper.toDomainPJ(request);
        ValidaFinResponse response = analisarPJUseCase.executar(domainRequest, terminal, authorization);

        return ResponseEntity.ok(validaFindMapper.toResponseDto(response));
    }

}
package br.com.bradesco.srv.hex.application.exception;

/** Indica que já existe uma análise ativa para o CPF/CNPJ informado. */
public class DocumentoEmAnaliseException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public DocumentoEmAnaliseException(String message) {
        super(message);
    }
}

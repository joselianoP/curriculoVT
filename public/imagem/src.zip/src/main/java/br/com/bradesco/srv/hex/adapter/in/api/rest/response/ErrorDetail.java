package br.com.bradesco.srv.hex.adapter.in.api.rest.response;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;

/** Contrato único para respostas de erro da API. */
@Schema(description = "Informações sobre a falha ocorrida.")
public record ErrorDetail(
        @Schema(description = "Código do erro, normalmente correspondente ao status HTTP.", example = "400")
        String codigo,
        @Schema(description = "Resumo da falha.", example = "Requisição inválida")
        String mensagem,
        @Schema(description = "Detalhes adicionais sobre a falha.", example = "Campo obrigatório")
        String detalhes,
        @Schema(description = "Identificador de correlação da requisição.", example = "123e4567-e89b-12d3-a456-426614174000")
        @JsonInclude(JsonInclude.Include.NON_NULL) String correlationId
) {
}
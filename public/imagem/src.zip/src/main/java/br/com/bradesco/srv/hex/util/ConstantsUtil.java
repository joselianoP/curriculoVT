package br.com.bradesco.srv.hex.util;

public final class ConstantsUtil {

	private ConstantsUtil() {
		throw new IllegalStateException("Utility class");
	}

	// CorrelationId e Terminal
	public static final String COORELATION_ID = "correlation-Id";
	public static final String TERMINAL = "VLDFINDSKATL";
	public static final String TERMINAL_HEADER = "terminal";

	public static final String FRAMED = "SIM";
	public static final String NOT_FRAMED = "NAO";
    
	// Status HTTP
	public static final String SUCCESS = "200";
	public static final String BAD_REQUEST = "400";
	public static final String UNAUTHORIZED = "401";
	public static final String FORBIDDEN = "403";
	public static final String NOT_FOUND = "404";
	public static final String CONFLICT = "409";
	public static final String UNPROCESSABLE_ENTITY = "422";
	public static final String TOO_MANY_REQUESTS = "429";
	public static final String INTERNAL_SERVER_ERROR = "500";
	public static final String BAD_GATEWAY = "502";
	public static final String SERVICE_UNAVAILABLE = "503";
	public static final String GATEWAY_TIMEOUT = "504";

	// Mensagens de erro
	public static final String REQUISICAO_INVALIDA = "Requisicao invalida";
	public static final String DETALHES_VALIDACAO = "Campos obrigatorios ausentes ou invalidos";
	public static final String CAMPO_OBRIGATORIO = "Campo obrigatorio";
	public static final String CAMPO_INVALIDO = "Campo invalido";
	
	// Terminal
	public static final String TERMINAL_OBRIGATORIO = "O campo terminal e obrigatorio";
	public static final String TERMINAL_INVALIDO = "Terminal invalido";
	public static final String TERMINAL_NAO_AUTORIZADO = "O terminal nao possui permissao para acessar o servico ValidaFin";

    //Calibragem
    public static final String CALIB_INDISPONIVEL = "Calibragem indisponivel.";
    public static final String CALIB_TIMEOUT = "Timeout na comunicacao com a Calibragem.";
    public static final String CALIB_AUTHENTICATION = "Falha de autenticacao na comunicacao com a Calibragem.";
    public static final String CALIB_INVALID_RESPONSE = "Retorno invalido da Calibragem.";
    public static final String CALIB_ENTRADA_INVALIDA = "Dados invalidos para a Calibragem.";
    public static final String CALIB_ERRO_PROCESSAMENTO = "Nao foi possivel processar a requisicao na Calibragem.";

    //Retorno da Calibragem PF
    public static final String CALIB_PF_ASSOCIACAO_INVALIDA = "Retorno PF nao associado a uma analise valida do Step 1.";
    public static final String MONGO_REGISTRO_INDISPONIVEL = "Nao foi possivel registrar os dados da analise neste momento.";
}

package br.com.bradesco.srv.hex.adapter.in.api.config;

import org.jspecify.annotations.NonNull;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import br.com.bradesco.srv.hex.Application;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.ExternalDocumentation;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;

@Configuration(proxyBeanMethods = false)
@ConditionalOnProperty(
        value = "springdoc.swagger-ui.enabled",
        havingValue = "true",
        matchIfMissing = true)
public class SwaggerConfig implements WebMvcConfigurer {

    static final String CONTROLLER_PACKAGE_NAME =
            Application.class.getPackageName() + ".adapter.in";

    static final String BRADESCO_DOCS_TITLE = "Bradescode Documentation";
    private static final String SECURITY_SCHEME_NAME = "bearerAuth";

    private final String name;
    private final String description;
    private final String version;
    private final String docsUrl;
    private final String swaggerUiBasePath;
    private final String swaggerUiForwardPath;

    public SwaggerConfig(
            @Value("${info.app.name:unknown}") String name,
            @Value("${info.app.description:unknown}") String description,
            @Value("${info.app.version:unknown}") String version,
            @Value("${springdoc.external-docs.url:}") String docsUrl,
            @Value("${app.swagger-ui.base-path}") String swaggerUiBasePath,
            @Value("${app.swagger-ui.forward-path}") String swaggerUiForwardPath) {

        this.docsUrl = docsUrl;
        this.name = name;
        this.description = description;
        this.version = version;
        this.swaggerUiBasePath = swaggerUiBasePath;
        this.swaggerUiForwardPath = swaggerUiForwardPath;
    }

    @Override
    public void addViewControllers(@NonNull ViewControllerRegistry registry) {
        registry.addViewController(swaggerUiBasePath)
                .setViewName("forward:" + swaggerUiForwardPath);
    }

    @Bean
    public OpenAPI customOpenAPI() {

        SecurityScheme bearerScheme = new SecurityScheme()
                .type(SecurityScheme.Type.HTTP)
                .scheme("bearer")
                .bearerFormat("JWT")
                .description("Informe o token JWT. O prefixo 'Bearer' será adicionado automaticamente pelo Swagger.");

        return new OpenAPI()
               
                .info(new Info()
                        .title(name)
                        .description(description)
                        .version(version))
                .externalDocs(new ExternalDocumentation()
                        .description(BRADESCO_DOCS_TITLE)
                        .url(docsUrl))
                .components(new Components()
                        .addSecuritySchemes(
                                SECURITY_SCHEME_NAME,
                                bearerScheme))
                .addSecurityItem(
                        new SecurityRequirement()
                                .addList(SECURITY_SCHEME_NAME));
    }

    /**
     * Documentação OpenAPI dos endpoints da versão 1.
     */
    @Bean
    public GroupedOpenApi apiV1() {
        return GroupedOpenApi.builder()
                .group("v1")
                .displayName("Versão 1")
                .pathsToMatch("/v1/**")
                .packagesToScan(CONTROLLER_PACKAGE_NAME)
                .build();
    }

    /**
     * Documentação OpenAPI dos endpoints da versão 2.
     * A consulta REST do MongoDB pertence exclusivamente a este grupo.
     */
    @Bean
    public GroupedOpenApi apiV2() {
        return GroupedOpenApi.builder()
                .group("v2")
                .displayName("Versão 2")
                .pathsToMatch("/v2/**")
                .packagesToScan(CONTROLLER_PACKAGE_NAME)
                .build();
    }

}
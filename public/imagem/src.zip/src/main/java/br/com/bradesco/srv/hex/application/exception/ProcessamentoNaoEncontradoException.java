package br.com.bradesco.srv.hex.application.exception;

public class ProcessamentoNaoEncontradoException extends RuntimeException {
    public ProcessamentoNaoEncontradoException(String identificador) {
        super("Processamento não encontrado: " + identificador);
    }
}

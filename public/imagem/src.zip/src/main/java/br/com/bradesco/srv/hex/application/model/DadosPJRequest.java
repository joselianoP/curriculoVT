package br.com.bradesco.srv.hex.application.model;
 
import java.math.BigDecimal;

import br.com.bradesco.srv.hex.util.enumerator.Periodicidade;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DadosPJRequest{

	private String centroDeCusto;		 
	private String club;
	private String cnpj;
	private Periodicidade periodicidade;
	private Integer anoReferencia;
	private BigDecimal valorFaturamentoDeclarado;


}

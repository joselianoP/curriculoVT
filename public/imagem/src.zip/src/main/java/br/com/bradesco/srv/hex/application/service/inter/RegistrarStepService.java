package br.com.bradesco.srv.hex.application.service.inter;

import br.com.bradesco.srv.hex.application.model.Processamento;

/**
 * Contrato do caso de uso RegistrarStepService.
 */
public interface RegistrarStepService {

    /**
     * Executa o caso de uso.
     *
     * @param idProcessamento identificador do processamento
     * @param correlationId identificador de correlação
     * @param step etapa que será registrada
     */
    void executar(String idProcessamento, String correlationId, Processamento.StepProcessamento step);
}

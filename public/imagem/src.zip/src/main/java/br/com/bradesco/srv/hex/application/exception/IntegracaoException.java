package br.com.bradesco.srv.hex.application.exception;

import java.io.Serial;

/** Representa falha ao consumir uma API ou serviço externo. */
public class IntegracaoException extends BaseException {

	@Serial
	private static final long serialVersionUID = 1L;

	private final String servico;

	public IntegracaoException(String servico, Throwable cause) {
		super("ERRO_INTEGRACAO", "Falha ao consumir " + servico + ".", cause);
		this.servico = servico;
	}

	public String getServico() {
		return servico;
	}
}

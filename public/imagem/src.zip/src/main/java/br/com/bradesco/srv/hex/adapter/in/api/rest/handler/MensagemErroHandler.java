package br.com.bradesco.srv.hex.adapter.in.api.rest.handler;


import java.io.InterruptedIOException;
import java.net.ConnectException;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeoutException;

import org.springframework.http.HttpStatus;

import br.com.bradesco.srv.hex.application.exception.BusinessException;
import br.com.bradesco.srv.hex.application.exception.BusinessValidationException;
import br.com.bradesco.srv.hex.application.exception.CorrelationIdDuplicadoException;
import br.com.bradesco.srv.hex.application.exception.InfrastructureException;
import br.com.bradesco.srv.hex.application.exception.IntegracaoException;
import br.com.bradesco.srv.hex.application.exception.InvalidInputException;
import br.com.bradesco.srv.hex.application.exception.LimiteEnvioDocumentoExcedidoException;
import br.com.bradesco.srv.hex.application.exception.NotFoundException;
import br.com.bradesco.srv.hex.application.exception.ProcessamentoNaoEncontradoException;
import br.com.bradesco.srv.hex.application.exception.ServiceUnavailableException;
import feign.FeignException;
import feign.RetryableException;

/** Padroniza mensagens seguras para o Client e para o histórico no MongoDB. */
public final class MensagemErroHandler {

    private static final String ERRO_GENERICO =
            "Ocorreu um erro interno ao processar a requisição.";
    private static final String ERRO_TIMEOUT =
            "Tempo limite de comunicação excedido.";
    private static final String SERVICO_INDISPONIVEL =
            "Serviço temporariamente indisponível.";
    private static final String ERRO_INTEGRACAO =
            "Falha na comunicação com o serviço integrado.";
    private static final String ERRO_AUTENTICACAO =
            "Erro de entegração do serviço.";

    private static final Map<Class<?>, String> MENSAGENS_EXCECOES = Map.ofEntries(
            Map.entry(CorrelationIdDuplicadoException.class, "Já existe um processamento para o identificador informado."),
            Map.entry(ProcessamentoNaoEncontradoException.class, "Processamento nao encontrado."),
            Map.entry(LimiteEnvioDocumentoExcedidoException.class,"Limite de envio de documentos excedido."),
            Map.entry(InvalidInputException.class, "Dados informados inválidos."),
            Map.entry(BusinessValidationException.class,"Não foi possível validar os dados informados."),
            Map.entry(NotFoundException.class,"Registro nao encontrado."),
            Map.entry(ServiceUnavailableException.class, SERVICO_INDISPONIVEL),
            Map.entry(InfrastructureException.class, ERRO_GENERICO),
            Map.entry(BusinessException.class,"Não foi possível concluir a operação."));

    private static final Map<Integer, String> MENSAGENS_HTTP = Map.ofEntries(
            Map.entry(400, "Requisição inválida. Verifique os dados enviados."),
            Map.entry(401, ERRO_AUTENTICACAO),
            Map.entry(403, ERRO_AUTENTICACAO),
            Map.entry(404, "Recurso nao encontrado no servico integrado."),
            Map.entry(405, "Metodo HTTP nao permitido no servico integrado."),
            Map.entry(408, ERRO_TIMEOUT),
            Map.entry(409, "Conflito ao executar operacao no servico integrado."),
            Map.entry(413, "Conteúdo enviado excede o limite permitido."),
            Map.entry(415, "Formato de conteúdo não suportado pelo serviço integrado."),
            Map.entry(422, "Dados rejeitados pelo serviço integrado."),
            Map.entry(429, "Limite de solicitações do serviço integrado excedido."),
            Map.entry(500, ERRO_GENERICO),
            Map.entry(502, ERRO_INTEGRACAO),
            Map.entry(503, SERVICO_INDISPONIVEL),
            Map.entry(504, ERRO_TIMEOUT));

    private MensagemErroHandler() {
        throw new IllegalStateException("Classe utilitaria.");
    }

    public static String obterMensagemMongo(Throwable ex) {
        return obterMensagem(ex, false);
    }

    public static String obterMensagemClient(Throwable ex) {
        return obterMensagem(ex, true);
    }

    /**
     * Identifica a API/serviço consumido e classifica a falha
     * sem expor dados técnicos desnecessários.
     */
    private static String obterMensagem(Throwable ex, boolean client) {
        if (ex == null) {
            return ERRO_GENERICO;
        }

        IntegracaoException integracao = encontrarIntegracao(ex);

        if (integracao != null) {
            return obterMensagemIntegracao(integracao, client);
        }

        return obterMensagemDaCadeia(ex);
    }

    private static String obterMensagemIntegracao(
            IntegracaoException integracao, boolean client) {

        String servico = obterNomeServico(integracao);
        Throwable causa = integracao.getCause();
        String classificacao = classificarFalha(causa);

        if (client) {
            return "Falha ao consumir " + servico + ". "
                    + detalheClient(causa, classificacao);
        }

        return "Falha ao consumir " + servico + ": " + classificacao;
    }

    private static String obterNomeServico(IntegracaoException integracao) {
        String servico = integracao.getServico();

        return servico == null || servico.isBlank()
                ? "serviço externo"
                : servico;
    }

    private static String obterMensagemDaCadeia(Throwable ex) {
        Throwable atual = ex;

        while (atual != null) {
            String mensagem = encontrarMensagemConhecida(atual);

            if (mensagem != null) {
                return mensagem;
            }

            String mensagemOriginal = atual.getMessage();

            if (mensagemOriginal != null && !mensagemOriginal.isBlank()) {
                return mensagemOriginal;
            }

            atual = proximaCausa(atual);
        }

        return ERRO_GENERICO;
    }

    /** Determina o status HTTP da falha de integração. */
    public static HttpStatus obterStatusHttp(Throwable ex) {
        if (ex == null) {
            return HttpStatus.INTERNAL_SERVER_ERROR;
        }

        IntegracaoException integracao = encontrarIntegracao(ex);
        Throwable causa = integracao != null ? integracao.getCause() : ex;

        if (causa == null) {
            return HttpStatus.INTERNAL_SERVER_ERROR;
        }

        return classificarStatusHttp(causa);
    }

    private static HttpStatus classificarStatusHttp(Throwable causa) {
        if (possuiCausa(causa, InterruptedIOException.class)
                || possuiCausa(causa, TimeoutException.class)) {
            return HttpStatus.GATEWAY_TIMEOUT;
        }

        if (possuiFalhaConexao(causa)) {
            return HttpStatus.SERVICE_UNAVAILABLE;
        }

        RetryableException retryable = encontrarRetryable(causa);

        if (retryable != null) {
            return HttpStatus.SERVICE_UNAVAILABLE;
        }

        FeignException feign = encontrarFeign(causa);

        if (feign != null) {
            return classificarStatusFeign(feign.status());
        }

        return HttpStatus.INTERNAL_SERVER_ERROR;
    }

    private static HttpStatus classificarStatusFeign(int status) {
        if (status == 401 || status == 403) {
            return HttpStatus.UNAUTHORIZED;
        }

        if (status == 400 || status == 404 || status == 409
                || status == 422 || status == 429 || status == 500
                || status == 502 || status == 503 || status == 504) {
            return HttpStatus.valueOf(status);
        }

        return HttpStatus.BAD_GATEWAY;
    }

    private static String detalheClient(Throwable cause, String classificacao) {
        FeignException feign = encontrarFeign(cause);

        if (feign != null && feign.status() == 500) {
            return ERRO_GENERICO;
        }

        return classificacao;
    }

    private static String encontrarMensagemConhecida(Throwable ex) {
        if (ex == null) {
            return null;
        }

        RetryableException retryable = encontrarRetryable(ex);

        if (retryable != null) {
            return classificarRetryable(retryable);
        }

        FeignException feign = encontrarFeign(ex);

        if (feign != null) {
            return classificarHttp(feign.status());
        }

        if (possuiFalhaTimeout(ex)) {
            return ERRO_TIMEOUT;
        }

        if (possuiFalhaConexao(ex)) {
            return SERVICO_INDISPONIVEL;
        }

        return buscarMensagem(ex.getClass());
    }

    private static String classificarFalha(Throwable cause) {
        if (cause == null) {
            return ERRO_GENERICO;
        }

        String mensagem = encontrarMensagemConhecida(cause);

        return mensagem != null ? mensagem : ERRO_GENERICO;
    }

    private static String classificarRetryable(RetryableException ex) {
        if (possuiFalhaTimeout(ex)) {
            return ERRO_TIMEOUT;
        }

        if (possuiFalhaConexao(ex)) {
            return SERVICO_INDISPONIVEL;
        }

        return ex.status() > 0
                ? classificarHttp(ex.status())
                : SERVICO_INDISPONIVEL;
    }

    private static String classificarHttp(int status) {
        return MENSAGENS_HTTP.getOrDefault(
                status,
                status >= 500 ? ERRO_INTEGRACAO : ERRO_GENERICO);
    }

    private static boolean possuiFalhaTimeout(Throwable ex) {
        return possuiCausa(ex, InterruptedException.class)
                || possuiCausa(ex, InterruptedIOException.class)
                || possuiCausa(ex, TimeoutException.class);
    }

    private static boolean possuiFalhaConexao(Throwable ex) {
        return possuiCausa(ex, ConnectException.class)
                || possuiCausa(ex, UnknownHostException.class)
                || possuiCausa(ex, SocketException.class);
    }

    private static RetryableException encontrarRetryable(Throwable ex) {
        Throwable atual = ex;

        while (atual != null) {
            if (atual instanceof RetryableException retryable) {
                return retryable;
            }

            atual = proximaCausa(atual);
        }

        return null;
    }

    private static FeignException encontrarFeign(Throwable ex) {
        Throwable atual = ex;

        while (atual != null) {
            if (atual instanceof FeignException feign) {
                return feign;
            }

            atual = proximaCausa(atual);
        }

        return null;
    }

    private static String buscarMensagem(Class<?> tipo) {
        Class<?> atual = tipo;

        while (atual != null && atual != Object.class) {
            String mensagem = MENSAGENS_EXCECOES.get(atual);

            if (mensagem != null) {
                return mensagem;
            }

            atual = atual.getSuperclass();
        }

        return null;
    }

    /** Indica se a exceção ou alguma causa representa falha de integração. */
    public static boolean ehFalhaIntegracao(Throwable ex) {
        return encontrarIntegracao(ex) != null;
    }

    private static IntegracaoException encontrarIntegracao(Throwable ex) {
        Throwable atual = ex;

        while (atual != null) {
            if (atual instanceof IntegracaoException integracao) {
                return integracao;
            }

            atual = proximaCausa(atual);
        }

        return null;
    }

    private static boolean possuiCausa(
            Throwable ex, Class<? extends Throwable> tipo) {

        if (ex == null || tipo == null) {
            return false;
        }

        Throwable atual = ex;
        Set<Throwable> visitados = Collections.newSetFromMap(
                new IdentityHashMap<>());

        while (atual != null && visitados.add(atual)) {
            if (tipo.isInstance(atual)) {
                return true;
            }

            atual = proximaCausa(atual);
        }

        return false;
    }

    private static Throwable proximaCausa(Throwable ex) {
        if (ex == null) {
            return null;
        }

        Throwable causa = ex.getCause();

        return causa == ex ? null : causa;
    }
}


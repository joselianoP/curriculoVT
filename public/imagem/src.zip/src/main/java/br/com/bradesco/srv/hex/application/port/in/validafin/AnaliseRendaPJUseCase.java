package br.com.bradesco.srv.hex.application.port.in.validafin;

import br.com.bradesco.srv.hex.application.model.DadosPJRequest;
import br.com.bradesco.srv.hex.application.model.ValidaFinResponse;

public interface AnaliseRendaPJUseCase {

    ValidaFinResponse executar(DadosPJRequest request, String terminal, String authorization);
}

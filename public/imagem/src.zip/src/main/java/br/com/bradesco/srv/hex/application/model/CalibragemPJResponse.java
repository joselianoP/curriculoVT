package br.com.bradesco.srv.hex.application.model;

import java.io.Serializable;
import java.math.BigDecimal;

public record CalibragemPJResponse(
		String valorEnquadradoMS,

		Boolean identificadoFonte,

		BigDecimal faturamentoReferencial,

		String fonte,

		String periodicidade

) implements CalibragemResponse, Serializable {

	@Override
	public String getValorEnquadrado() {
		return valorEnquadradoMS;
	}

	@Override
	public String getFonteRerencia() {
		return fonte;
	}
}
package br.com.bradesco.srv.hex.application.exception;

public class LimiteEnvioDocumentoExcedidoException extends RuntimeException {
    public LimiteEnvioDocumentoExcedidoException(String message) { super(message); }
}

package br.com.bradesco.srv.hex.util.enumerator;

public enum EtapaProcessamento {
    STEP1,
    STEP2,
    CCN,
    CALIBRAGEM,
    FINALIZADO,
    ERRO
}

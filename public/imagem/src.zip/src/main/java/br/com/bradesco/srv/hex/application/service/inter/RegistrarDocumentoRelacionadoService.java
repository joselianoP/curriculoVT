package br.com.bradesco.srv.hex.application.service.inter;

import br.com.bradesco.srv.hex.application.model.DocumentosRelacionados;

/**
 * Contrato do caso de uso RegistrarDocumentoRelacionadoService.
 */
public interface RegistrarDocumentoRelacionadoService {

    /**
     * Executa o caso de uso.
     *
     * @param documento dados de entrada do caso de uso
     */
    void executar(DocumentosRelacionados.Documento documento);
}

package br.com.bradesco.srv.hex.adapter.in.api.rest.controller.v2.mongo;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.bradesco.srv.hex.adapter.in.api.rest.dto.ConsultaMongoResponseDto;
import br.com.bradesco.srv.hex.application.model.ConsultaMongoResultado;
import br.com.bradesco.srv.hex.application.port.in.mongo.ConsultarDocumentosMongoUseCase;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/v2/mongo")
@Tag(name = "Consulta MongoDB", description = "Consulta documentos persistidos pelo correlationId")
public class ConsultaMongoController {

    private final ConsultarDocumentosMongoUseCase consultarDocumentosMongoUseCase;

    @GetMapping("/{cdCorrelationId}")
    @Operation(summary = "Consulta todas as collections pelo cdCorrelationId",
            description = "Retorna os documentos encontrados nas collections do processamento.")
    public ResponseEntity<ConsultaMongoResponseDto> consultarPorCorrelationId(
            @Parameter(description = "Identificador de correlação da requisição", required = true)
            @PathVariable String cdCorrelationId) {

        log.info("Recebida consulta de documentos MongoDB. correlationId={}", cdCorrelationId);
        ConsultaMongoResultado resultado = consultarDocumentosMongoUseCase.executar(cdCorrelationId);
        return ResponseEntity.ok(new ConsultaMongoResponseDto(
                resultado.correlationId(), resultado.totalDocumentos(), resultado.collections()));
    }
}

package br.com.bradesco.srv.hex.application.exception;

import java.io.Serial;

import br.com.bradesco.srv.hex.util.ConstantsUtil;

/**
 * Exceção para falhas de autenticação, como token inválido, expirado ou ausente em um serviço consumido.
 *
 * @see BaseException
 */
public class UnauthorizedException extends BaseException {

    @Serial
    private static final long serialVersionUID = 1L;

    public UnauthorizedException(String message) {
        super(ConstantsUtil.UNAUTHORIZED, message);
    }

    public UnauthorizedException(String message, Throwable cause) {
        super(ConstantsUtil.UNAUTHORIZED, message, cause);
    }
}

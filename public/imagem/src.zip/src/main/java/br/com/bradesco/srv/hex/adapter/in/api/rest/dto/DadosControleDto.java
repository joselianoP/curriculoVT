package br.com.bradesco.srv.hex.adapter.in.api.rest.dto;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Dados de controle da requisição")
public record DadosControleDto(
		
		@Schema(description = "Centro de custo", example = "CC001")
		String centroDeCusto, 
		
		@Schema(description = "Identificador do club", example = "CLUB001")
		String club ) {
}

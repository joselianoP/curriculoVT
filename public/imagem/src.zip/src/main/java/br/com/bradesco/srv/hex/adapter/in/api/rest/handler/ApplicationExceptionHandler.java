package br.com.bradesco.srv.hex.adapter.in.api.rest.handler;

import java.util.Objects;

import org.slf4j.MDC;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.HandlerMethodValidationException;

import br.com.bradesco.srv.hex.adapter.in.api.rest.response.ErrorDetail;
import br.com.bradesco.srv.hex.adapter.in.api.rest.response.ErrorResponseAPI;
import br.com.bradesco.srv.hex.application.exception.BaseException;
import br.com.bradesco.srv.hex.application.exception.BusinessException;
import br.com.bradesco.srv.hex.application.exception.BusinessValidationException;
import br.com.bradesco.srv.hex.application.exception.CorrelationIdDuplicadoException;
import br.com.bradesco.srv.hex.application.exception.DocumentoEmAnaliseException;
import br.com.bradesco.srv.hex.application.exception.DocumentoJaCadastradoException;
import br.com.bradesco.srv.hex.application.exception.InfrastructureException;
import br.com.bradesco.srv.hex.application.exception.IntegracaoException;
import br.com.bradesco.srv.hex.application.exception.InvalidInputException;
import br.com.bradesco.srv.hex.application.exception.LimiteEnvioDocumentoExcedidoException;
import br.com.bradesco.srv.hex.application.exception.NotFoundException;
import br.com.bradesco.srv.hex.application.exception.ProcessamentoNaoEncontradoException;
import br.com.bradesco.srv.hex.application.exception.ServiceUnavailableException;
import br.com.bradesco.srv.hex.util.ConstantsUtil;

/**
 * Handler global de exceções especializado no mapeamento de exceções de domínio para respostas HTTP.
 *
 * <p>Intercepta exceções específicas do domínio da aplicação ({@link BaseException}) e as converte
 * no contrato JSON padronizado de erro da API ({@link ErrorResponseAPI}).</p>
 *
 * @see BaseException
 * @see AbstractRestExceptionHandler
 */
@ControllerAdvice
public class ApplicationExceptionHandler extends AbstractRestExceptionHandler {

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex,
            HttpHeaders headers,
            HttpStatusCode status,
            WebRequest request) {
        FieldError firstError = ex.getBindingResult().getFieldError();
        String details = firstError != null && firstError.getDefaultMessage() != null
                ? firstError.getDefaultMessage() : ConstantsUtil.CAMPO_INVALIDO;
        return error(HttpStatus.BAD_REQUEST, ConstantsUtil.REQUISICAO_INVALIDA, details, null, request, ex);
    }

    @Override
    protected ResponseEntity<Object> handleHandlerMethodValidationException(
            HandlerMethodValidationException ex,
            HttpHeaders headers,
            HttpStatusCode status,
            WebRequest request) {
        String details = ex.getAllErrors().stream()
                .map(MessageSourceResolvable::getDefaultMessage)
                .filter(Objects::nonNull)
                .findFirst()
                .orElse(ConstantsUtil.REQUISICAO_INVALIDA);
        return error(HttpStatus.BAD_REQUEST, ConstantsUtil.REQUISICAO_INVALIDA, details, null, request, ex);
    }

    @ExceptionHandler(CorrelationIdDuplicadoException.class)
    public ResponseEntity<Object> handleCorrelationIdDuplicado(
            CorrelationIdDuplicadoException ex, WebRequest request) {
        return error(HttpStatus.CONFLICT, "Processamento duplicado", ex.getMessage(),
                ex.getCorrelationId(), request, ex);
    }

    @ExceptionHandler(DocumentoEmAnaliseException.class)
    public ResponseEntity<Object> handleDocumentoEmAnalise(
            DocumentoEmAnaliseException ex, WebRequest request) {
        return error(HttpStatus.CONFLICT, "Documento em análise", ex.getMessage(),
                null, request, ex);
    }

    @ExceptionHandler(LimiteEnvioDocumentoExcedidoException.class)
    public ResponseEntity<Object> handleLimiteEnvioDocumentoExcedido(
            LimiteEnvioDocumentoExcedidoException ex, WebRequest request) {
        return error(HttpStatus.TOO_MANY_REQUESTS, "Limite de envio excedido", ex.getMessage(),
                null, request, ex);
    }

    @ExceptionHandler(ProcessamentoNaoEncontradoException.class)
    public ResponseEntity<Object> handleProcessamentoNaoEncontrado(
            ProcessamentoNaoEncontradoException ex, WebRequest request) {
        return error(HttpStatus.NOT_FOUND, "Processamento não encontrado", ex.getMessage(),
                null, request, ex);
    }

    @ExceptionHandler(IntegracaoException.class)
    public ResponseEntity<Object> handleIntegracaoException(IntegracaoException ex, WebRequest request) {
        HttpStatus status = MensagemErroHandler.obterStatusHttp(ex);
        return error(status, defaultMessage(status), null, null, request, ex);
    }

    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<Object> handleBusinessException(BusinessException ex, WebRequest request) {
        return handleBaseException(ex, HttpStatus.UNPROCESSABLE_ENTITY, request);
    }

    @ExceptionHandler(NotFoundException.class)
    public ResponseEntity<Object> handleNotFoundException(NotFoundException ex, WebRequest request) {
        ex.addMoreInfo("04", "item-nao-encontrado");
        return handleBaseException(ex, HttpStatus.NOT_FOUND, request);
    }

    @ExceptionHandler(InvalidInputException.class)
    public ResponseEntity<Object> handleInvalidInputException(InvalidInputException ex, WebRequest request) {
        return handleBaseException(ex, HttpStatus.BAD_REQUEST, request);
    }

    @ExceptionHandler(InfrastructureException.class)
    public ResponseEntity<Object> handleInfrastructureException(InfrastructureException ex, WebRequest request) {
        return handleBaseException(ex, HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

    @ExceptionHandler(ServiceUnavailableException.class)
    public ResponseEntity<Object> handleServiceUnavailableException(ServiceUnavailableException ex, WebRequest request) {
        return handleBaseException(ex, HttpStatus.SERVICE_UNAVAILABLE, request);
    }

    @ExceptionHandler(DocumentoJaCadastradoException.class)
    public ResponseEntity<Object> handleDocumentoJaCadastrado(
            DocumentoJaCadastradoException ex,
            WebRequest request) {
        
        String correlationId = MDC.get(ConstantsUtil.COORELATION_ID);
  
        return error(
        HttpStatus.CONFLICT,
        "Processamento duplicado",
                 ex.getMessage(),
                correlationId,
                request,
                ex);

    }
    
    @ExceptionHandler(BusinessValidationException.class)
    public ResponseEntity<Object> handleBusinessValidationException(
            BusinessValidationException ex, WebRequest request) {
        String details = ex.getDetalhes();
        if (ex.getCampos() != null && !ex.getCampos().isEmpty()) {
            String fields = ex.getCampos().stream()
                    .map(field -> field.nome() + ": " + field.motivo())
                    .reduce((left, right) -> left + "; " + right)
                    .orElse("");
            details = details == null || details.isBlank() ? fields : details + ". " + fields;
        }
        return error(HttpStatus.BAD_REQUEST, safeMessage(ex.getMessage(), "Dados inválidos"),
                details, null, request, ex);
    }

    /** Constrói todas as respostas específicas usando o mesmo envelope JSON. */
    private ResponseEntity<Object> error(
            HttpStatus status,
            String message,
            String details,
            String exceptionCorrelationId,
            WebRequest request,
            Exception ex) {
        String correlationId = nonBlank(exceptionCorrelationId);
        if (correlationId == null) correlationId = nonBlank(MDC.get(ConstantsUtil.COORELATION_ID));
        if (correlationId == null) correlationId = nonBlank(request.getHeader(ConstantsUtil.COORELATION_ID));

        ErrorResponseAPI body = new ErrorResponseAPI(new ErrorDetail(
                Integer.toString(status.value()),
                safeMessage(message, defaultMessage(status)),
                safeMessage(MensagemErroHandler.obterMensagemClient(ex),
                        safeMessage(details, "Ocorreu um erro interno ao processar a requisicao.")),
                correlationId));
        logHttpError(status, ex);
        return ResponseEntity.status(status).body(body);
    }

    /** Tratamento base para exceções que herdam de BaseException. */
    protected ResponseEntity<Object> handleBaseException(
            @NonNull BaseException ex,
            @NonNull HttpStatusCode status,
            @NonNull WebRequest request) {
        String message = defaultMessage(status);
        String details = ex.getErrorMessage();
        return error(HttpStatus.valueOf(status.value()), message, details, null, request, ex);
    }

    private static String nonBlank(String value) {
        return value == null || value.isBlank() ? null : value;
    }

    private static String safeMessage(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    private static String defaultMessage(HttpStatusCode status) {
        if (status.value() == HttpStatus.BAD_REQUEST.value()) return "Requisição inválida";
        if (status.value() == HttpStatus.UNAUTHORIZED.value()) return "Autenticação necessária";
        if (status.value() == HttpStatus.FORBIDDEN.value()) return "Acesso não autorizado";
        if (status.value() == HttpStatus.NOT_FOUND.value()) return "Recurso não encontrado";
        if (status.value() == HttpStatus.CONFLICT.value()) return "Conflito de processamento";
        if (status.value() == HttpStatus.REQUEST_TIMEOUT.value()) return "Tempo limite excedido";
        if (status.value() == HttpStatus.TOO_MANY_REQUESTS.value()) return "Limite de solicitações excedido";
        if (status.value() == HttpStatus.UNPROCESSABLE_ENTITY.value()) return "Regra de negócio não atendida";
        if (status.value() == HttpStatus.BAD_GATEWAY.value()) return "Falha na comunicação com serviço integrado";
        if (status.value() == HttpStatus.SERVICE_UNAVAILABLE.value()) return "Serviço indisponível";
        if (status.value() == HttpStatus.GATEWAY_TIMEOUT.value()) return "Tempo limite do serviço integrado excedido";
        return status.is4xxClientError() ? "Requisição inválida" : "Erro do servidor interno";
    }
}



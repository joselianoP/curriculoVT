package br.com.bradesco.srv.hex.application.model;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DadosPFRequest {

	private String centroDeCusto;

	private String club;

	private String cpf;

	private BigDecimal valorRendaMensalDeclarada;

}
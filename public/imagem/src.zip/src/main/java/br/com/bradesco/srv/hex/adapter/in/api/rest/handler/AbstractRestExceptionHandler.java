package br.com.bradesco.srv.hex.adapter.in.api.rest.handler;

import static java.util.Objects.requireNonNull;
import static java.util.Optional.ofNullable;

import java.util.Map;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.slf4j.event.Level;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import br.com.bradesco.srv.hex.adapter.in.api.rest.response.ErrorDetail;
import br.com.bradesco.srv.hex.adapter.in.api.rest.response.ErrorResponseAPI;
import br.com.bradesco.srv.hex.util.ConstantsUtil;
import jakarta.validation.ConstraintViolationException;

/**
 * Handler global de exceções REST para tratamento centralizado de exceções da aplicação.
 *
 * <p>Estende {@link ResponseEntityExceptionHandler} para o tratamento de erro centralizado padrão do Spring Web,
 * incluindo validação, conversão, tipos de mídia e outras exceções HTTP.
 * Fornece respostas padronizadas conforme a <a href="https://datatracker.ietf.org/doc/html/rfc9457">RFC-9457</a>,
 * utilizando o {@link org.springframework.http.ProblemDetail}.</p>
 *
 * <p>Documentação relevante:</p>
 * <ul>
 * <li><a href="https://datatracker.ietf.org/doc/html/rfc9457">RFC-9457: Problem Details for HTTP APIs</a></li>
 * <li><a href="https://docs.spring.io/spring-framework/reference/web/webmvc/mvc-ann-rest-exceptions.html">
 *     Spring Framework - Error Responses</a></li>
 * </ul>
 *
 * <p>Funcionalidades principais:</p>
 * <ul>
 * <li>Tratamento de exceções de validação (@Valid, @Validated)</li>
 * <li>Conversão de tipos e argumentos de métodos</li>
 * <li>Tipos de mídia não suportados</li>
 * <li>Parâmetros de requisição ausentes ou inválidos</li>
 * <li>Mensagens HTTP mal formadas ou ilegíveis</li>
 * <li>Handlers não encontrados para URLs</li>
 * <li>Logging automático de todas as exceções</li>
 * </ul>
 *
 * @see ResponseEntityExceptionHandler
 */
public abstract class AbstractRestExceptionHandler extends ResponseEntityExceptionHandler {

    /**
     * Modelo de mensagem para logging de exceções de domínio capturadas.
     * Será formatado com o código de erro da API e a mensagem de erro.
     */
    private static final String LOG_TEMPLATE = "Excecao sendo capturada, APIErrorCode: {}, Mensagem: {}";

    public static final String LIST_OF_ERRORS_KEY = "errors";
    public static final String ERROR_CAMPO_NAME_KEY = "campo";
    public static final String ERROR_MENSAGEM_NAME_KEY = "mensagem";

    private static final String VALIDATION_ERROR_DETAIL = "Dados de entrada invalidos.";

    protected final Logger logService;

    protected AbstractRestExceptionHandler() {
        super();
        this.logService = LoggerFactory.getLogger(getClass());
    }

    protected AbstractRestExceptionHandler(Logger logService) {
        super();
        this.logService = logService;
    }

    /**
     * Trata exceções quando nenhum handler é encontrado para a requisição.
     *
     * @param ex      a exceção de handler não encontrado
     * @param headers os headers HTTP da requisição
     * @param status  o status HTTP
     * @param request a requisição web
     * @return ResponseEntity com ProblemDetail e status BAD_REQUEST
     */
    @Override
    protected ResponseEntity<Object> handleNoHandlerFoundException(
        @NonNull NoHandlerFoundException ex,
        @NonNull HttpHeaders headers,
        @NonNull HttpStatusCode status,
        @NonNull WebRequest request
    ) {
        final var args = new Object[]{ex.getHttpMethod(), ex.getRequestURL()};
        final var body = createProblemDetail(ex, status, ex.getMessage(), null, args, request);
        return handleExceptionInternal(ex, body, headers, status, request);
    }

    /**
     * Manipula exceções de validação de argumentos de métodos anotados com {@code @Valid} ou {@code @Validated}.
     *
     * <p>Este método é chamado quando ocorre uma {@link MethodArgumentNotValidException}, geralmente devido a falhas
     * de validação em objetos recebidos como parâmetros em endpoints REST. Ele constrói uma resposta padronizada
     * no formato {@link org.springframework.http.ProblemDetail}, incluindo uma lista dos campos inválidos e os
     * respectivos motivos da falha de validação.</p>
     *
     * @param ex      a exceção lançada quando a validação de argumento falha
     * @param headers os cabeçalhos HTTP da requisição
     * @param status  o status HTTP a ser retornado
     * @param request o contexto da requisição web
     * @return uma {@link ResponseEntity} contendo o corpo do erro padronizado e o status HTTP apropriado
     */
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
        @NonNull MethodArgumentNotValidException ex,
        @NonNull HttpHeaders headers,
        @NonNull HttpStatusCode status,
        @NonNull WebRequest request
    ) {
        var globalErrors = ex.getBindingResult().getGlobalErrors().stream()
            .map(objectError -> Map.of(
                ERROR_CAMPO_NAME_KEY, objectError.getObjectName(),
                ERROR_MENSAGEM_NAME_KEY, requireNonNull(objectError.getDefaultMessage())
            ));
        var fieldErrors = ex.getBindingResult().getFieldErrors().stream()
            .map(fieldError -> Map.of(
                ERROR_CAMPO_NAME_KEY, fieldError.getField(),
                ERROR_MENSAGEM_NAME_KEY, requireNonNull(fieldError.getDefaultMessage())
            ));
        var errors = Stream.concat(globalErrors, fieldErrors).toList();
        final var body = createProblemDetail(ex, status, VALIDATION_ERROR_DETAIL, null, null, request);
        if (!errors.isEmpty())
            body.setProperty(LIST_OF_ERRORS_KEY, errors);
        return handleExceptionInternal(ex, body, headers, status, request);
    }

    /**
     * Trata exceções de violação de constraints de validação do Bean Validation.
     *
     * <p>Este método é invocado quando há violação de constraints definidas através
     * de anotações de validação (como @NotNull, @Size, @Pattern, etc.) em nível
     * de método ou classe.</p>
     *
     * <p>Diferente do handleMethodArgumentNotValid, este trata violações que ocorrem diretamente
     * nas constraints dos beans, comumente acionado em validações programáticas ou quando constraints
     * são violadas em operações que não passam pelo processo de binding do Spring.</p>
     *
     * @param ex      a exceção de violação de constraint do Bean Validation
     * @param request a requisição web
     * @return ResponseEntity com ProblemDetail contendo mensagem de erro de validação e status BAD_REQUEST
     */
    @ExceptionHandler(jakarta.validation.ConstraintViolationException.class)
    public ResponseEntity<Object> handleConstraintViolation(
        @NonNull ConstraintViolationException ex,
        @NonNull WebRequest request
    ) {
        final var status = HttpStatus.BAD_REQUEST;
        final var body = createProblemDetail(ex, status, VALIDATION_ERROR_DETAIL, null, null, request);
        final var errors = ex.getConstraintViolations().stream()
            .map(constraintViolation -> Map.of(
                ERROR_CAMPO_NAME_KEY, obterNomeCampo(constraintViolation.getPropertyPath().toString()),
                ERROR_MENSAGEM_NAME_KEY, constraintViolation.getMessage()
            ))
            .toList();
        if (!errors.isEmpty())
            body.setProperty(LIST_OF_ERRORS_KEY, errors);
        return handleExceptionInternal(ex, body, new HttpHeaders(), status, request);
    }

    /**
     * Trata exceções de incompatibilidade de tipo de argumento de método.
     *
     * @param ex      a exceção de incompatibilidade de tipo
     * @param request a requisição web
     * @return ResponseEntity com ProblemDetail e status BAD_REQUEST
     */
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<Object> handleMethodArgumentTypeMismatch(
        @NonNull MethodArgumentTypeMismatchException ex,
        @NonNull WebRequest request
    ) {
        final var status = HttpStatus.BAD_REQUEST;
        final var args = new Object[]{
            ex.getName(),
            ofNullable(ex.getValue())
                .map(Object::getClass)
                .map(Class::getSimpleName)
                .orElse("null"),
            ofNullable(ex.getRequiredType())
                .map(Class::getSimpleName)
                .orElse("null")
        };
        final var body = createProblemDetail(ex, status, ex.getMessage(), null, args, request);
        return handleExceptionInternal(ex, body, new HttpHeaders(), status, request);
    }

    /**
     * Trata exceções genéricas não capturadas por handlers específicos.
     *
     * <p>Este método atua como um "catch-all" para qualquer exceção que não seja
     * tratada pelos handlers mais específicos. É o último recurso para garantir
     * que nenhuma exceção não tratada chegue ao cliente como erro 500 sem
     * estrutura adequada.</p>
     *
     * <p>Importante: Este handler tem a menor precedência e só será acionado
     * quando nenhum outro handler mais específico puder tratar a exceção.
     * Retorna sempre status INTERNAL_SERVER_ERROR (500) indicando erro no servidor.</p>
     *
     * @param ex      a exceção genérica não tratada por outros handlers
     * @param request a requisição web
     * @return ResponseEntity com ProblemDetail contendo detalhes da exceção e status INTERNAL_SERVER_ERROR
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handleGenericException(
        @NonNull Exception ex,
        @NonNull WebRequest request
    ) {
        if (ex instanceof ErrorResponse errorResponse) {
            return handleExceptionInternal(ex, null, new HttpHeaders(), errorResponse.getStatusCode(), request);
        }
        if (MensagemErroHandler.ehFalhaIntegracao(ex)) {
            HttpStatus status = MensagemErroHandler.obterStatusHttp(ex);
            return handleExceptionInternal(ex, null, new HttpHeaders(), status, request);
        }
        final var status = HttpStatus.INTERNAL_SERVER_ERROR;
        final var body = createProblemDetail(ex, status, "Ocorreu um erro interno ao processar a requisicao.", null, null, request);
        return handleExceptionInternal(ex, body, new HttpHeaders(), status, request);
    }
    
    
    /**
     * Implementação personalizada adicionada para logging centralizado de exceções HTTP.
     * <hr/>
     * <p>
     * {@inheritDoc}
     */
    @Override
    protected ResponseEntity<Object> handleExceptionInternal(
        @NonNull Exception ex,
        @Nullable Object body,
        @NonNull HttpHeaders headers,
        @NonNull HttpStatusCode statusCode,
        @NonNull WebRequest request
    ) {
        logHttpError(statusCode, ex);

        // Garante o mesmo contrato JSON para todos os erros originados pelo Spring MVC.
        Object responseBody = body;
        if (!(body instanceof ErrorResponseAPI)) {
            String correlationId = correlationId(request);
            String mensagem = mensagemPara(statusCode);
            String detalhes = MensagemErroHandler.obterMensagemClient(ex);

            responseBody = new ErrorResponseAPI(new ErrorDetail(
                    String.valueOf(statusCode.value()),
                    mensagem,
                    detalhes,
                    correlationId));
        }
        return super.handleExceptionInternal(ex, responseBody, headers, statusCode, request);
    }

    private String correlationId(WebRequest request) {
        String correlationId = MDC.get(ConstantsUtil.COORELATION_ID);
        if (correlationId == null || correlationId.isBlank()) {
            correlationId = request.getHeader(ConstantsUtil.COORELATION_ID);
        }
        return correlationId;
    }

    private String mensagemPara(HttpStatusCode status) {
        if (status.value() == HttpStatus.BAD_REQUEST.value()) return "Requisicao invalida";
        if (status.value() == HttpStatus.NOT_FOUND.value()) return "Recurso nao encontrado";
        if (status.value() == HttpStatus.UNAUTHORIZED.value()) return "Autenticacao necessaria";
        if (status.value() == HttpStatus.FORBIDDEN.value()) return "Acesso nao autorizado";
        if (status.value() == HttpStatus.CONFLICT.value()) return "Conflito de processamento";
        if (status.value() == HttpStatus.TOO_MANY_REQUESTS.value()) return "Limite de solicitacoes excedido";
        if (status.value() == HttpStatus.BAD_GATEWAY.value()) return "Falha na comunicacao com servico integrado";
        if (status.value() == HttpStatus.GATEWAY_TIMEOUT.value()) return "Tempo limite do servico integrado excedido";
        if (status.value() == HttpStatus.METHOD_NOT_ALLOWED.value()) return "Metodo HTTP nao permitido";
        if (status.value() == HttpStatus.UNSUPPORTED_MEDIA_TYPE.value()) return "Tipo de conteudo nao suportado";
        if (status.value() == HttpStatus.NOT_ACCEPTABLE.value()) return "Formato de resposta nao aceitavel";
        if (status.value() == HttpStatus.SERVICE_UNAVAILABLE.value()) return "Servico indisponivel";
        if (status.is4xxClientError()) return "Requisicao invalida";
        return "Erro do servidor interno";
    }

 

    /**
     * Logging centralizado de exceções HTTP capturadas.
     *
     * @param statusCode o código de status HTTP associado à exceção
     * @param ex         a exceção capturada
     */
    protected void logHttpError(HttpStatusCode statusCode, Exception ex) {
        var level = statusCode.is5xxServerError() ? Level.ERROR : Level.DEBUG;
        logService.atLevel(level)
            .setCause(ex)
            .setMessage(LOG_TEMPLATE)
            .addArgument(statusCode)
            .addArgument(ex.getMessage())
            .log();
    }

    private String obterNomeCampo(String propertyPath) {
        if (propertyPath == null || !propertyPath.contains(".")) {
            return propertyPath;
        }
        return propertyPath.substring(propertyPath.lastIndexOf('.') + 1);
    }
}

package br.com.bradesco.srv.hex.application.exception;

import java.io.Serial;


/**
 * Exceção que indica indisponibilidade temporária de serviços críticos para o funcionamento da aplicação.
 *
 * <p>Esta exceção é utilizada para sinalizar situações onde serviços essenciais estão temporariamente
 * indisponíveis, mas espera-se que retornem ao funcionamento normal em breve. Diferente de falhas
 * permanentes, esta exceção indica problemas transitórios que podem ser resolvidos com retry
 * ou aguardando a restauração do serviço.</p>
 *
 * @see InfrastructureException
 * @see InfraErrorCode#SERVICE_UNAVAILABLE
 * @since 1.0.0
 */
public class ServiceUnavailableException extends BaseException {

	private static final String CAUSED_BY_KEY = "causedBy";

	@Serial
	private static final long serialVersionUID = 1L;

	public ServiceUnavailableException(String code, String message, Throwable cause) {
		super(code, message, cause);
		addMoreInfo(CAUSED_BY_KEY, cause.getMessage());
	}

	public ServiceUnavailableException(String code, String message) {
		super(code, message);
	}

	public ServiceUnavailableException(Throwable cause) {
		super(InfraErrorCode.SERVICE_UNAVAILABLE, cause);
		addMoreInfo(CAUSED_BY_KEY, cause.getMessage());
	}

	public ServiceUnavailableException() {
		super(InfraErrorCode.SERVICE_UNAVAILABLE);
	}
}

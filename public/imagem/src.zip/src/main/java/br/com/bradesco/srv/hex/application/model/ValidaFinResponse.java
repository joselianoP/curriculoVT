package br.com.bradesco.srv.hex.application.model;

import br.com.bradesco.srv.hex.util.enumerator.ResultadoAnalise;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ValidaFinResponse {

	private ResultadoAnalise resultadoAnalise;

	private String idAnalise;

	private Integer statusComprovacao;

	private String mensagem;

}
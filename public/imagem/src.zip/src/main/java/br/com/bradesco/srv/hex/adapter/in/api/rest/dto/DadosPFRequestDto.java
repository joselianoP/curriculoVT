package br.com.bradesco.srv.hex.adapter.in.api.rest.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Requisição de análise de renda para Pessoa Física")
public record DadosPFRequestDto(

		DadosControleDto controle,

        @Schema(description = "Tipo de pessoa: PF ou PJ", example = "PF")
        String tipoPessoa, //ponto a questionar: pq tipo pessoa somente p dados pf?
       
		@Schema(description = "CPF da pessoa física (sem formatação)", example = "12345678901")
		String cpf,

		@Schema(description = "Valor de renda mensal declarada", example = "5500.00")
		BigDecimal valorRendaMensalDeclarada

)implements Serializable  {
}
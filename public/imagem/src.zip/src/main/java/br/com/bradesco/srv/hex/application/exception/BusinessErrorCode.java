package br.com.bradesco.srv.hex.application.exception;

public enum BusinessErrorCode implements ErrorCode {

    DEPOSIT_CANNOT_EDIT("Deposito nao pode ser editado no status atual"),
	DEPOSIT_CANNOT_CHANGE_STATUS("Nao e possivel alterar o status do deposito"),
	DEPOSIT_NOT_FOUND("Deposito nao encontrado"),

	WITHDRAWAL_CANNOT_EDIT("Saque nao pode ser editado no status atual"),
	WITHDRAWAL_CANNOT_CHANGE_STATUS("Nao e possivel alterar o status do saque"),
	WITHDRAWAL_NOT_FOUND("Saque nao encontrado");

    private final String code;
    private final String message;

    BusinessErrorCode(String message) {
        this.code = name();
        this.message = message;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getMessage() {
        return message;
    }

}

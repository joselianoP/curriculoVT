package br.com.bradesco.srv.hex.application.model;

import java.time.Instant;
import java.util.List;

/** Modelo do documento principal persistido na coleção validaFinDocument. */
public record Processamento(
        String correlationId,
        String numeroRequisicao,
        Requisicao requisicao,
        List<StepProcessamento> steps) {

	
    public record Requisicao(
            String centroDeCusto,
            String club,
            String terminal,
            String tipoPessoa,
            String Documento) {
    }

   
    /** Um evento de etapa registrado no documento principal. */
    public record StepProcessamento(
            String nome,
            String status,
            Instant iniciadoEm,
            String mensagem) {
    }

  
}

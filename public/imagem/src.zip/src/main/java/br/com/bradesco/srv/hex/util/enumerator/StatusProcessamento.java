package br.com.bradesco.srv.hex.util.enumerator;

public enum StatusProcessamento {
    RECEBIDO,
    PROCESSANDO,
    AGUARDANDO_CCN,
    CCN_CONCLUIDO,
    AGUARDANDO_CALIBRAGEM,
    CONCLUIDO,
    REJEITADO,
    ERRO,
    SISTEMA_INDISPONIVEL
}

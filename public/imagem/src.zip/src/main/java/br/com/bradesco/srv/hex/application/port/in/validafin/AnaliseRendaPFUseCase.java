package br.com.bradesco.srv.hex.application.port.in.validafin;

import br.com.bradesco.srv.hex.application.model.DadosPFRequest;
import br.com.bradesco.srv.hex.application.model.ValidaFinResponse;

public interface AnaliseRendaPFUseCase {

    ValidaFinResponse executar(DadosPFRequest request, String terminal, String authorization);
}

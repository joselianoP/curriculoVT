package br.com.bradesco.srv.hex.application.model;

import java.io.Serializable;
import java.math.BigDecimal;

public record CalibragemPFResponse(
 
    String fonteReferencia, 
    BigDecimal percentualRendaReferencial, 
    String valorEnquadrado

) implements CalibragemResponse, Serializable {

	@Override
	public String getValorEnquadrado() {
        return valorEnquadrado;
	}

	@Override
	public String getFonteRerencia() {
		return fonteReferencia;
	}
}

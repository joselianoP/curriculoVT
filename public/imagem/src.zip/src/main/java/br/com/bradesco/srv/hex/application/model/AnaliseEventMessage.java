package br.com.bradesco.srv.hex.application.model;

public record AnaliseEventMessage(
		String eventId, 
		String correlationId, 
		String documentoId) {

}

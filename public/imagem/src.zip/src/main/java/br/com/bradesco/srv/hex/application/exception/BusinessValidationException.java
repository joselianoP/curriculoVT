package br.com.bradesco.srv.hex.application.exception;
 

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
 

public class BusinessValidationException extends RuntimeException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private final String codigo;
    private final String detalhes;
    private final ArrayList<ValidationFieldException> campos;

    public BusinessValidationException(
            String codigo,
            String mensagem,
            String detalhes) {

        super(mensagem);

        this.codigo = codigo;
        this.detalhes = detalhes;
        this.campos = new ArrayList<>();
    }
    
    
    public BusinessValidationException(
            String codigo,
            String mensagem,
            String detalhes,
            List<ValidationFieldException> campos) {

        super(mensagem);

        this.codigo = codigo;
        this.detalhes = detalhes;
        this.campos = campos == null ? new ArrayList<>() : new ArrayList<>(campos);
    }

    public String getCodigo() {
        return codigo;
    }

    public String getDetalhes() {
        return detalhes;
    }

    public List<ValidationFieldException> getCampos() {
        return Collections.unmodifiableList(campos);
    }
}
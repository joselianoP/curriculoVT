package br.com.bradesco.srv.hex.application.model;

import java.math.BigDecimal;
import java.time.Instant;

/**
 * Modelos de aplicação para persistência incremental dos documentos
 * relacionados.
 */
public final class DocumentosRelacionados {
	private DocumentosRelacionados() {
	}

	public sealed interface Conteudo
			permits PessoaFisica, PessoaJuridica, Calibragem, Validacad, Cfc, DocumentoEnviado {
	}

	public record Documento(String id, String idProcessamento, String correlationId, Instant processadoEm,
			Conteudo conteudo) {
	}

	public record PessoaFisica(String cpf, BigDecimal valorRendaMensalDeclarada) implements Conteudo {
	}

	public record PessoaJuridica(String cnpj, Integer periodicidade, Integer anoReferencia,
			BigDecimal valorFaturamentoDeclarado) implements Conteudo {
	}

	public record Calibragem(
			String valorEnquadrado, 
			Boolean identificadoFonte, 
			BigDecimal faturamentoReferencial,
			BigDecimal percentualRendaReferencial,
			String fonteReferencia, 
			String periodicidade) implements Conteudo {
	}

	public record Validacad(String valorInformado, String scoreValidacao, String variavelValidacao,
			String statusValidacao, String nomeVariavel) implements Conteudo {
	}

	public record Cfc(String chave, String nome, String registro, String situacaoCadastral, String situacaoCcr,
			String categoriaCcr, String tipoRegistro) implements Conteudo {
	}

	public record DocumentoEnviado(String numeroRequisicao, Long tamanho, String type, String gridFsId,
			Instant atualizadoEm, Integer schemaVersion) implements Conteudo {
	}
}

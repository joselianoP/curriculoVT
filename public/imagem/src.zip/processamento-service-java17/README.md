# processamento-service (Java 17)

Backend sem REST API, organizado em arquitetura hexagonal. O ponto de entrada é `ProcessamentoApplication`.
O starter inclui um caso de uso de gravação do agregado de processamento e persistência em coleções MongoDB separadas.

## Requisitos
- Java 17
- Maven 3.8+
- MongoDB 6+ (local ou container)

## Executar
```bash
docker compose up -d
mvn clean test
mvn spring-boot:run
```

## Coleções MongoDB
- `processamento`: documento raiz com `requisicao`, `processamento`, `steps` e `auditoria`.
- `pessoaFisica`, `pessoaJuridica`, `calibragem`, `validacard`, `ccr`, `documentoEnviado`: documentos separados com `idProcessamento` como referência ao `_id` de `processamento` e `correlationId` para rastreabilidade.

**Atenção ao JSON de origem:** `ccr` não traz `idProcessamento` nem `correlationId`; o modelo do projeto adiciona esses campos para manter o vínculo com o processamento principal. `steps` e `auditoria` ficam embutidos no documento principal, conforme o JSON enviado. Os exemplos de valores do JSON (como `"string"` e `0`) são placeholders, não valores de negócio.

## Organização
- `application`: casos de uso e DTOs de entrada
- `domain`: entidades e portas (interfaces)
- `adapter.out.mongodb`: documentos Mongo e adapters de persistência
- `config`: configuração de beans

Não há `@RestController`, endpoints HTTP nem dependência `spring-boot-starter-web`.

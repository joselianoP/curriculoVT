package br.com.bradesco.srv.hex.application.usecase;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.Instant;

import org.junit.jupiter.api.Test;
import org.mockito.invocation.InvocationOnMock;

import br.com.bradesco.srv.hex.application.model.AnaliseRendaContexto;
import br.com.bradesco.srv.hex.application.model.AnaliseRendaEstrategia;
import br.com.bradesco.srv.hex.application.model.CalibragemPFRequest;
import br.com.bradesco.srv.hex.application.model.CalibragemPFResponse;
import br.com.bradesco.srv.hex.application.model.DadosPFRequest;
import br.com.bradesco.srv.hex.application.model.DocumentosRelacionados;
import br.com.bradesco.srv.hex.application.model.Processamento;
import br.com.bradesco.srv.hex.application.model.ValidaFinResponse;
import br.com.bradesco.srv.hex.application.port.out.calibragem.CalibragemPFPort;
import br.com.bradesco.srv.hex.application.service.inter.AnaliseRendaService;
import br.com.bradesco.srv.hex.application.service.inter.CalibragemTranslatorService;
import br.com.bradesco.srv.hex.util.enumerator.ResultadoAnalise;
import br.com.bradesco.srv.hex.util.enumerator.TipoPessoa;

class AnaliseRendaPFUseCaseImplTest {

    private static final String CORRELATION_ID = "correlacao-pf-1";
    private static final String ID_PROCESSAMENTO = "id-processamento-1";
    private static final String TERMINAL = "TERMINAL-01";
    private static final String AUTORIZACAO = "Bearer token";
    private static final String CPF = "12345678901";

    private final CalibragemPFPort calibragemPFPort = mock(CalibragemPFPort.class);
    private final CalibragemTranslatorService calibragemTranslator =
            mock(CalibragemTranslatorService.class);
    private final AnaliseRendaService analiseRendaService = mock(AnaliseRendaService.class);

    private final AnaliseRendaPFUseCaseImpl useCase = new AnaliseRendaPFUseCaseImpl(
            calibragemPFPort,
            calibragemTranslator,
            analiseRendaService);

    private static DadosPFRequest requisicao() {
        return DadosPFRequest.builder()
                .centroDeCusto("1234")
                .club("CLUB-01")
                .cpf(CPF)
                .valorRendaMensalDeclarada(new BigDecimal("5000.00"))
                .build();
    }

    private static CalibragemPFResponse calibragem() {
        return new CalibragemPFResponse(
                "RECEITA",
                new BigDecimal("10"),
                "SIM");
    }

    private static ValidaFinResponse resposta() {
        return ValidaFinResponse.builder()
                .resultadoAnalise(ResultadoAnalise.APROVADO_SISTEMICAMENTE)
                .build();
    }

    private void configurarCriacaoDocumentoRelacionado() {
        when(analiseRendaService.criarDocumentoRelacionado(
                any(DocumentosRelacionados.Conteudo.class),
                anyString(),
                anyString()))
                .thenAnswer(invocation -> {
                    DocumentosRelacionados.Conteudo conteudo = invocation.getArgument(0);
                    String idProcessamento = invocation.getArgument(1);
                    String correlationId = invocation.getArgument(2);
                    return new DocumentosRelacionados.Documento(
                            null,
                            idProcessamento,
                            correlationId,
                            Instant.now(),
                            conteudo);
                });
    }

    @Test
    void executaAnaliseComSucessoEValidaContextoEEstrategia() throws Throwable {
        DadosPFRequest request = requisicao();
        CalibragemPFResponse resultadoCalibragem = calibragem();
        ValidaFinResponse respostaEsperada = resposta();

        configurarCriacaoDocumentoRelacionado();

        when(calibragemPFPort.send(any(CalibragemPFRequest.class), eq(AUTORIZACAO)))
                .thenReturn(resultadoCalibragem);
        when(calibragemTranslator.translate(any(CalibragemPFResponse.class)))
                .thenReturn(respostaEsperada);

        when(analiseRendaService.<DadosPFRequest, CalibragemPFResponse>executar(
                any(AnaliseRendaContexto.class),
                any(AnaliseRendaEstrategia.class)))
                .thenAnswer(invocation -> executarEstrategia(invocation, request));

        ValidaFinResponse resultado = useCase.executar(request, TERMINAL, AUTORIZACAO);

        assertThat(resultado).isSameAs(respostaEsperada);
        assertThat(resultado.getResultadoAnalise())
                .isEqualTo(ResultadoAnalise.APROVADO_SISTEMICAMENTE);

        verify(analiseRendaService).<DadosPFRequest, CalibragemPFResponse>executar(
                any(AnaliseRendaContexto.class),
                any(AnaliseRendaEstrategia.class));
        verify(calibragemTranslator).translate(any(CalibragemPFResponse.class));
    }

    private ValidaFinResponse executarEstrategia(
            InvocationOnMock invocation,
            DadosPFRequest request) throws Throwable {

        @SuppressWarnings("unchecked")
        AnaliseRendaContexto<DadosPFRequest> contexto = invocation.getArgument(0);
        @SuppressWarnings("unchecked")
        AnaliseRendaEstrategia<DadosPFRequest, CalibragemPFResponse> estrategia =
                invocation.getArgument(1);

        assertThat(contexto.request()).isSameAs(request);
        assertThat(contexto.terminal()).isEqualTo(TERMINAL);
        assertThat(contexto.authorization()).isEqualTo(AUTORIZACAO);
        assertThat(contexto.tipoPessoa()).isEqualTo(TipoPessoa.PF);

        Processamento.Requisicao processamento =
                contexto.criarRequisicao().apply(contexto.request());
        assertThat(processamento.centroDeCusto()).isEqualTo("1234");
        assertThat(processamento.club()).isEqualTo("CLUB-01");
        assertThat(processamento.terminal()).isEqualTo(TERMINAL);
        assertThat(processamento.tipoPessoa()).isEqualTo("PF");
        assertThat(processamento.Documento()).isEqualTo(CPF);

        DocumentosRelacionados.Documento documentoPessoa =
                estrategia.criarDocumentoPessoa().criar(
                        request, ID_PROCESSAMENTO, CORRELATION_ID);
        assertThat(documentoPessoa.idProcessamento()).isEqualTo(ID_PROCESSAMENTO);
        assertThat(documentoPessoa.correlationId()).isEqualTo(CORRELATION_ID);
        assertThat(documentoPessoa.conteudo())
                .isInstanceOf(DocumentosRelacionados.PessoaFisica.class);

        DocumentosRelacionados.PessoaFisica pessoaFisica =
                (DocumentosRelacionados.PessoaFisica) documentoPessoa.conteudo();
        assertThat(pessoaFisica.cpf()).isEqualTo(CPF);
        assertThat(pessoaFisica.valorRendaMensalDeclarada()).isEqualByComparingTo("5000.00");

        CalibragemPFResponse calibragem = estrategia.executarCalibragem()
                .executar(request, TERMINAL, AUTORIZACAO);
        assertThat(calibragem).isEqualTo(calibragem());

        var envio = org.mockito.ArgumentCaptor.forClass(CalibragemPFRequest.class);
        verify(calibragemPFPort).send(envio.capture(), eq(AUTORIZACAO));
        assertThat(envio.getValue().cpf()).isEqualTo(CPF);
        assertThat(envio.getValue().renda()).isEqualByComparingTo("5000.00");
        assertThat(envio.getValue().terminal()).isEqualTo(TERMINAL);

        DocumentosRelacionados.Documento documentoCalibragem =
                estrategia.criarDocumentoResultado().criar(
                        calibragem, ID_PROCESSAMENTO, CORRELATION_ID);
        assertThat(documentoCalibragem.idProcessamento()).isEqualTo(ID_PROCESSAMENTO);
        assertThat(documentoCalibragem.correlationId()).isEqualTo(CORRELATION_ID);
        assertThat(documentoCalibragem.conteudo()).isEqualTo(
                new DocumentosRelacionados.Calibragem(
                        calibragem.getValorEnquadrado(),
                        null,
                        BigDecimal.ZERO,
                        calibragem.percentualRendaReferencial(),
                        calibragem.fonteReferencia(),
                        null));

        ValidaFinResponse respostaTraduzida = estrategia.traduzirResultado().apply(calibragem);
        assertThat(respostaTraduzida.getResultadoAnalise())
                .isEqualTo(ResultadoAnalise.APROVADO_SISTEMICAMENTE);
        return respostaTraduzida;
    }
}

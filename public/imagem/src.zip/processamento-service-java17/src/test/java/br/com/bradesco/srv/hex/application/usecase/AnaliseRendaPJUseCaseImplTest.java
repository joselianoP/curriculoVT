package br.com.bradesco.srv.hex.application.usecase;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.Instant;

import org.junit.jupiter.api.Test;
import org.mockito.invocation.InvocationOnMock;

import br.com.bradesco.srv.hex.application.model.AnaliseRendaContexto;
import br.com.bradesco.srv.hex.application.model.AnaliseRendaEstrategia;
import br.com.bradesco.srv.hex.application.model.CalibragemPJRequest;
import br.com.bradesco.srv.hex.application.model.CalibragemPJResponse;
import br.com.bradesco.srv.hex.application.model.DadosPJRequest;
import br.com.bradesco.srv.hex.application.model.DocumentosRelacionados;
import br.com.bradesco.srv.hex.application.model.Processamento;
import br.com.bradesco.srv.hex.application.model.ValidaFinResponse;
import br.com.bradesco.srv.hex.application.port.out.calibragem.CalibragemPJPort;
import br.com.bradesco.srv.hex.application.service.inter.AnaliseRendaService;
import br.com.bradesco.srv.hex.application.service.inter.CalibragemTranslatorService;
import br.com.bradesco.srv.hex.util.enumerator.Periodicidade;
import br.com.bradesco.srv.hex.util.enumerator.ResultadoAnalise;
import br.com.bradesco.srv.hex.util.enumerator.TipoPessoa;

class AnaliseRendaPJUseCaseImplTest {

    private static final String CORRELATION_ID = "correlacao-pj-1";
    private static final String ID_PROCESSAMENTO = "id-processamento-1";
    private static final String TERMINAL = "TERMINAL-01";
    private static final String AUTORIZACAO = "Bearer token";
    private static final String CNPJ = "12345678000199";

    private final CalibragemPJPort calibragemPJPort = mock(CalibragemPJPort.class);
    private final CalibragemTranslatorService calibragemTranslator =
            mock(CalibragemTranslatorService.class);
    private final AnaliseRendaService analiseRendaService = mock(AnaliseRendaService.class);

    private final AnaliseRendaPJUseCaseImpl useCase = new AnaliseRendaPJUseCaseImpl(
            calibragemPJPort,
            calibragemTranslator,
            analiseRendaService);

    private static DadosPJRequest requisicao() {
        return DadosPJRequest.builder()
                .centroDeCusto("1234")
                .club("CLUB-01")
                .cnpj(CNPJ)
                .periodicidade(Periodicidade.ANUAL)
                .anoReferencia(2026)
                .valorFaturamentoDeclarado(new BigDecimal("500000.00"))
                .build();
    }

    private static CalibragemPJResponse calibragem() {
        return new CalibragemPJResponse(
                "SIM",
                true,
                new BigDecimal("10"),
                "RECEITA",
                "ANUAL");
    }

    private void configurarCriacaoDocumentoRelacionado() {
        when(analiseRendaService.criarDocumentoRelacionado(
                any(DocumentosRelacionados.Conteudo.class),
                anyString(),
                anyString()))
                .thenAnswer(invocation -> {
                    DocumentosRelacionados.Conteudo conteudo = invocation.getArgument(0);
                    String idProcessamento = invocation.getArgument(1);
                    String correlationId = invocation.getArgument(2);
                    return new DocumentosRelacionados.Documento(
                            null,
                            idProcessamento,
                            correlationId,
                            Instant.now(),
                            conteudo);
                });
    }

    @Test
    void executaAnaliseComSucessoEValidaContextoEEstrategia() throws Throwable {
        DadosPJRequest request = requisicao();
        CalibragemPJResponse resultadoCalibragem = calibragem();
        ValidaFinResponse respostaEsperada = resposta(ResultadoAnalise.APROVADO_SISTEMICAMENTE);

        configurarCriacaoDocumentoRelacionado();
        when(calibragemPJPort.send(any(CalibragemPJRequest.class), eq(AUTORIZACAO)))
                .thenReturn(resultadoCalibragem);
        when(calibragemTranslator.translate(any(CalibragemPJResponse.class)))
                .thenReturn(respostaEsperada);

        when(analiseRendaService.<DadosPJRequest, CalibragemPJResponse>executar(
                any(AnaliseRendaContexto.class),
                any(AnaliseRendaEstrategia.class)))
                .thenAnswer(invocation -> executarEstrategia(invocation, request));

        ValidaFinResponse resultado = useCase.executar(request, TERMINAL, AUTORIZACAO);

        assertThat(resultado).isSameAs(respostaEsperada);
        assertThat(resultado.getResultadoAnalise())
                .isEqualTo(ResultadoAnalise.APROVADO_SISTEMICAMENTE);

        verify(analiseRendaService).<DadosPJRequest, CalibragemPJResponse>executar(
                any(AnaliseRendaContexto.class),
                any(AnaliseRendaEstrategia.class));
        verify(calibragemTranslator).translate(any(CalibragemPJResponse.class));
    }

    private ValidaFinResponse executarEstrategia(
            InvocationOnMock invocation,
            DadosPJRequest request) throws Throwable {

        @SuppressWarnings("unchecked")
        AnaliseRendaContexto<DadosPJRequest> contexto = invocation.getArgument(0);
        @SuppressWarnings("unchecked")
        AnaliseRendaEstrategia<DadosPJRequest, CalibragemPJResponse> estrategia =
                invocation.getArgument(1);

        assertThat(contexto.request()).isSameAs(request);
        assertThat(contexto.terminal()).isEqualTo(TERMINAL);
        assertThat(contexto.authorization()).isEqualTo(AUTORIZACAO);
        assertThat(contexto.tipoPessoa()).isEqualTo(TipoPessoa.PJ);

        Processamento.Requisicao processamento =
                contexto.criarRequisicao().apply(contexto.request());
        assertThat(processamento.centroDeCusto()).isEqualTo("1234");
        assertThat(processamento.club()).isEqualTo("CLUB-01");
        assertThat(processamento.terminal()).isEqualTo(TERMINAL);
        assertThat(processamento.tipoPessoa()).isEqualTo("PJ");
        assertThat(processamento.Documento()).isEqualTo(CNPJ);

        DocumentosRelacionados.Documento documentoPessoa =
                estrategia.criarDocumentoPessoa().criar(
                        request, ID_PROCESSAMENTO, CORRELATION_ID);
        assertThat(documentoPessoa.idProcessamento()).isEqualTo(ID_PROCESSAMENTO);
        assertThat(documentoPessoa.correlationId()).isEqualTo(CORRELATION_ID);
        assertThat(documentoPessoa.conteudo())
                .isInstanceOf(DocumentosRelacionados.PessoaJuridica.class);

        DocumentosRelacionados.PessoaJuridica pessoaJuridica =
                (DocumentosRelacionados.PessoaJuridica) documentoPessoa.conteudo();
        assertThat(pessoaJuridica.cnpj()).isEqualTo(CNPJ);
        assertThat(pessoaJuridica.periodicidade()).isEqualTo(Periodicidade.ANUAL.meses());
        assertThat(pessoaJuridica.anoReferencia()).isEqualTo(2026);
        assertThat(pessoaJuridica.valorFaturamentoDeclarado())
                .isEqualByComparingTo("500000.00");

        CalibragemPJResponse calibragem = estrategia.executarCalibragem()
                .executar(request, TERMINAL, AUTORIZACAO);
        assertThat(calibragem).isEqualTo(calibragem());

        var envio = org.mockito.ArgumentCaptor.forClass(CalibragemPJRequest.class);
        verify(calibragemPJPort).send(envio.capture(), eq(AUTORIZACAO));
        assertThat(envio.getValue().cnpj()).isEqualTo(CNPJ);
        assertThat(envio.getValue().faturamentoAnual())
                .isEqualByComparingTo("500000.00");
        assertThat(envio.getValue().terminal()).isEqualTo(TERMINAL);

        DocumentosRelacionados.Documento documentoCalibragem =
                estrategia.criarDocumentoResultado().criar(
                        calibragem, ID_PROCESSAMENTO, CORRELATION_ID);
        assertThat(documentoCalibragem.idProcessamento()).isEqualTo(ID_PROCESSAMENTO);
        assertThat(documentoCalibragem.correlationId()).isEqualTo(CORRELATION_ID);
        assertThat(documentoCalibragem.conteudo()).isEqualTo(
                new DocumentosRelacionados.Calibragem(
                        calibragem.getValorEnquadrado(),
                        calibragem.identificadoFonte(),
                        calibragem.faturamentoReferencial(),
                        BigDecimal.ZERO,
                        calibragem.fonte(),
                        calibragem.periodicidade()));

        ValidaFinResponse respostaTraduzida = estrategia.traduzirResultado().apply(calibragem);
        assertThat(respostaTraduzida.getResultadoAnalise())
                .isEqualTo(ResultadoAnalise.APROVADO_SISTEMICAMENTE);
        return respostaTraduzida;
    }

    @Test
    void enviaFaturamentoMensalDeclaradoParaCalibragem() throws Throwable {
        DadosPJRequest request = requisicao();
        request.setPeriodicidade(Periodicidade.MENSAL);
        request.setValorFaturamentoDeclarado(new BigDecimal("1000.00"));

        CalibragemPJResponse calibragemMensal = new CalibragemPJResponse(
                "NAO",
                false,
                BigDecimal.ONE,
                "RECEITA",
                "MENSAL");
        ValidaFinResponse respostaEsperada =
                resposta(ResultadoAnalise.SOLICITAR_COMPROVANTE);

        when(calibragemPJPort.send(any(CalibragemPJRequest.class), eq(AUTORIZACAO)))
                .thenReturn(calibragemMensal);
        when(calibragemTranslator.translate(any(CalibragemPJResponse.class)))
                .thenReturn(respostaEsperada);

        when(analiseRendaService.<DadosPJRequest, CalibragemPJResponse>executar(
                any(AnaliseRendaContexto.class),
                any(AnaliseRendaEstrategia.class)))
                .thenAnswer(invocation -> {
                    @SuppressWarnings("unchecked")
                    AnaliseRendaContexto<DadosPJRequest> contexto = invocation.getArgument(0);
                    @SuppressWarnings("unchecked")
                    AnaliseRendaEstrategia<DadosPJRequest, CalibragemPJResponse> estrategia =
                            invocation.getArgument(1);

                    return estrategia.traduzirResultado().apply(
                            estrategia.executarCalibragem().executar(
                                    contexto.request(),
                                    contexto.terminal(),
                                    contexto.authorization()));
                });

        ValidaFinResponse resultado = useCase.executar(request, TERMINAL, AUTORIZACAO);

        assertThat(resultado).isSameAs(respostaEsperada);
        assertThat(resultado.getResultadoAnalise())
                .isEqualTo(ResultadoAnalise.SOLICITAR_COMPROVANTE);

        var envio = org.mockito.ArgumentCaptor.forClass(CalibragemPJRequest.class);
        verify(calibragemPJPort).send(envio.capture(), eq(AUTORIZACAO));
        assertThat(envio.getValue().cnpj()).isEqualTo(CNPJ);
        assertThat(envio.getValue().faturamentoAnual())
                .isEqualByComparingTo("1000.00");
        assertThat(envio.getValue().terminal()).isEqualTo(TERMINAL);
        verify(calibragemTranslator).translate(any(CalibragemPJResponse.class));
    }

    private static ValidaFinResponse resposta(ResultadoAnalise resultadoAnalise) {
        return ValidaFinResponse.builder()
                .resultadoAnalise(resultadoAnalise)
                .build();
    }
}

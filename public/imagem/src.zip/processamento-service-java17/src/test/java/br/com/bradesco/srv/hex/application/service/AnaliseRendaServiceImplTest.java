package br.com.bradesco.srv.hex.application.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.function.Supplier;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

import br.com.bradesco.srv.hex.application.model.AnaliseRendaContexto;
import br.com.bradesco.srv.hex.application.model.AnaliseRendaEstrategia;
import br.com.bradesco.srv.hex.application.model.DocumentosRelacionados;
import br.com.bradesco.srv.hex.application.model.Processamento;
import br.com.bradesco.srv.hex.application.model.ValidaFinResponse;
import br.com.bradesco.srv.hex.application.port.out.bloqueio.BloqueioDocumentoPort;
import br.com.bradesco.srv.hex.application.service.inter.RegistrarDocumentoRelacionadoService;
import br.com.bradesco.srv.hex.application.service.inter.RegistrarStepService;
import br.com.bradesco.srv.hex.application.service.inter.RegistrarValidaFinDocumentService;
import br.com.bradesco.srv.hex.util.ConstantsUtil;
import br.com.bradesco.srv.hex.util.enumerator.EtapaProcessamento;
import br.com.bradesco.srv.hex.util.enumerator.ResultadoAnalise;
import br.com.bradesco.srv.hex.util.enumerator.TipoPessoa;

class AnaliseRendaServiceImplTest {

    private static final String CORRELATION_ID = "correlation-service-test";
    private static final String ID_PROCESSAMENTO = "processamento-service-test";
    private static final String CPF = "12345678901";
    private static final String ERRO_CALIBRAGEM = "Falha na calibragem";

    private final RegistrarValidaFinDocumentService registrarProcessamento =
            mock(RegistrarValidaFinDocumentService.class);
    private final RegistrarStepService registrarStepService =
            mock(RegistrarStepService.class);
    private final RegistrarDocumentoRelacionadoService registrarDocumentoRelacionadoService =
            mock(RegistrarDocumentoRelacionadoService.class);
    private final BloqueioDocumentoPort bloqueioDocumentoPort =
            mock(BloqueioDocumentoPort.class);

    private final AnaliseRendaServiceImpl service = new AnaliseRendaServiceImpl(
            registrarProcessamento,
            registrarStepService,
            registrarDocumentoRelacionadoService,
            bloqueioDocumentoPort);

    @BeforeEach
    void configurarCorrelationId() {
        MDC.put(ConstantsUtil.COORELATION_ID, CORRELATION_ID);
    }

    @AfterEach
    void limparMdc() {
        MDC.clear();
    }

    @Test
    void executaFluxoDentroDoBloqueioDistribuido() {
        when(registrarProcessamento.executar(any(Processamento.class)))
                .thenReturn(ID_PROCESSAMENTO);
        executarCallbackDoBloqueio();

        AnaliseRendaContexto<String> contexto = contexto();
        AnaliseRendaEstrategia<String, String> estrategia = estrategiaSemErro();

        ValidaFinResponse resultado = service.executar(contexto, estrategia);

        assertThat(resultado.getResultadoAnalise())
                .isEqualTo(ResultadoAnalise.APROVADO_SISTEMICAMENTE);

        verify(bloqueioDocumentoPort).<ValidaFinResponse>executarComBloqueio(
                eq(TipoPessoa.PF.name()),
                eq(CPF),
                any());
        verify(registrarProcessamento).executar(any(Processamento.class));
        verify(registrarDocumentoRelacionadoService, org.mockito.Mockito.times(2))
                .executar(any(DocumentosRelacionados.Documento.class));
        verify(registrarStepService).executar(
                eq(ID_PROCESSAMENTO),
                eq(CORRELATION_ID),
                any(Processamento.StepProcessamento.class));
    }

    @Test
    void registraFalhaQuandoCalibragemLancaExcecao() {
        when(registrarProcessamento.executar(any(Processamento.class)))
                .thenReturn(ID_PROCESSAMENTO);
        executarCallbackDoBloqueio();

        AnaliseRendaEstrategia<String, String> estrategia = new AnaliseRendaEstrategia<>(
                (request, id, correlationId) -> documento(
                        id, correlationId,
                        new DocumentosRelacionados.PessoaFisica(request, BigDecimal.ONE)),
                (request, terminal, authorization) -> {
                    throw new IllegalStateException(ERRO_CALIBRAGEM);
                },
                (resultado, id, correlationId) -> documento(
                        id, correlationId,
                        new DocumentosRelacionados.Calibragem(
                                resultado, null, BigDecimal.ZERO, BigDecimal.ZERO, null, null)),
                resultado -> resposta());

        assertThatThrownBy(() -> service.executar(contexto(), estrategia))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage(ERRO_CALIBRAGEM);

        var captor = org.mockito.ArgumentCaptor.forClass(Processamento.StepProcessamento.class);
        verify(registrarStepService).executar(
                eq(ID_PROCESSAMENTO),
                eq(CORRELATION_ID),
                captor.capture());
        assertThat(captor.getValue().status()).isEqualTo(EtapaProcessamento.ERRO.toString());
        assertThat(captor.getValue().mensagem()).isEqualTo(ERRO_CALIBRAGEM);
    }

    private void executarCallbackDoBloqueio() {
        when(bloqueioDocumentoPort.<ValidaFinResponse>executarComBloqueio(
                eq(TipoPessoa.PF.name()), eq(CPF), any()))
                .thenAnswer(invocation -> {
                    @SuppressWarnings("unchecked")
                    Supplier<ValidaFinResponse> processamento = invocation.getArgument(2);
                    return processamento.get();
                });
    }

    private static AnaliseRendaContexto<String> contexto() {
        return new AnaliseRendaContexto<>(
                CPF,
                "TERMINAL-01",
                "Bearer token",
                TipoPessoa.PF,
                documento -> new Processamento.Requisicao(
                        "CENTRO-01", "CLUB-01", "TERMINAL-01", "PF", documento));
    }

    private AnaliseRendaEstrategia<String, String> estrategiaSemErro() {
        return new AnaliseRendaEstrategia<>(
                (request, id, correlationId) -> documento(
                        id, correlationId,
                        new DocumentosRelacionados.PessoaFisica(request, BigDecimal.ONE)),
                (request, terminal, authorization) -> "CALIBRADO",
                (resultado, id, correlationId) -> documento(
                        id, correlationId,
                        new DocumentosRelacionados.Calibragem(
                                resultado, null, BigDecimal.ZERO, BigDecimal.ZERO, null, null)),
                resultado -> resposta());
    }

    private static DocumentosRelacionados.Documento documento(
            String idProcessamento,
            String correlationId,
            DocumentosRelacionados.Conteudo conteudo) {
        return new DocumentosRelacionados.Documento(
                null, idProcessamento, correlationId, java.time.Instant.now(), conteudo);
    }

    private static ValidaFinResponse resposta() {
        return ValidaFinResponse.builder()
                .resultadoAnalise(ResultadoAnalise.APROVADO_SISTEMICAMENTE)
                .build();
    }
}

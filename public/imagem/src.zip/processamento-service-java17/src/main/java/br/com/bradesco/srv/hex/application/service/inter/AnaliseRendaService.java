package br.com.bradesco.srv.hex.application.service.inter;

import br.com.bradesco.srv.hex.application.model.AnaliseRendaContexto;
import br.com.bradesco.srv.hex.application.model.AnaliseRendaEstrategia;
import br.com.bradesco.srv.hex.application.model.DocumentosRelacionados;
import br.com.bradesco.srv.hex.application.model.ValidaFinResponse;

public interface AnaliseRendaService {

    <T, R> ValidaFinResponse executar(
            AnaliseRendaContexto<T> contexto,
            AnaliseRendaEstrategia<T, R> estrategia);

    <T extends DocumentosRelacionados.Conteudo>
    DocumentosRelacionados.Documento criarDocumentoRelacionado(
            T documento,
            String idProcessamento,
            String correlationId);
}

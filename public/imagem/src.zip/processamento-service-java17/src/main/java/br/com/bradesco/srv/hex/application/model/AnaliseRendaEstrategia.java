package br.com.bradesco.srv.hex.application.model;

import java.util.Objects;
import java.util.function.Function;

/**
 * Define as operações específicas de cada modalidade de análise (PF ou PJ).
 *
 * @param criarDocumentoPessoa cria o documento relacionado à pessoa analisada
 * @param executarCalibragem executa a integração com o serviço de calibragem
 * @param criarDocumentoResultado cria o documento com o resultado da calibragem
 * @param traduzirResultado converte o resultado externo para a resposta da API
 * @param <T> tipo da requisição de entrada
 * @param <R> tipo do retorno da calibragem
 */
public record AnaliseRendaEstrategia<T, R>(
        DocumentoPessoaFactory<T> criarDocumentoPessoa,
        CalibragemExecutor<T, R> executarCalibragem,
        DocumentoResultadoFactory<R> criarDocumentoResultado,
        Function<R, ValidaFinResponse> traduzirResultado) {

    public AnaliseRendaEstrategia {
        Objects.requireNonNull(criarDocumentoPessoa, "A criação do documento da pessoa é obrigatória.");
        Objects.requireNonNull(executarCalibragem, "A execução da calibragem é obrigatória.");
        Objects.requireNonNull(criarDocumentoResultado, "A criação do documento de resultado é obrigatória.");
        Objects.requireNonNull(traduzirResultado, "A tradução do resultado é obrigatória.");
    }

    @FunctionalInterface
    public interface DocumentoPessoaFactory<T> {

        DocumentosRelacionados.Documento criar(
                T request,
                String idProcessamento,
                String correlationId);
    }

    @FunctionalInterface
    public interface CalibragemExecutor<T, R> {

        R executar(T request, String terminal, String authorization);
    }

    @FunctionalInterface
    public interface DocumentoResultadoFactory<R> {

        DocumentosRelacionados.Documento criar(
                R resultado,
                String idProcessamento,
                String correlationId);
    }
}

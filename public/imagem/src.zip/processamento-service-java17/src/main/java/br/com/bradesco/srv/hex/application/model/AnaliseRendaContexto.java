package br.com.bradesco.srv.hex.application.model;

import java.util.Objects;
import java.util.function.Function;

import br.com.bradesco.srv.hex.util.enumerator.TipoPessoa;

/**
 * Dados comuns necessários para executar uma análise de renda.
 *
 * @param request requisição original recebida pelo caso de uso
 * @param terminal identificação do terminal de origem
 * @param authorization credencial utilizada na chamada de calibragem
 * @param tipoPessoa tipo de pessoa analisada (PF ou PJ)
 * @param criarRequisicao função que monta os dados persistidos do processamento
 * @param <T> tipo da requisição de entrada
 */
public record AnaliseRendaContexto<T>(
        T request,
        String terminal,
        String authorization,
        TipoPessoa tipoPessoa,
        Function<T, Processamento.Requisicao> criarRequisicao) {

    public AnaliseRendaContexto {
        Objects.requireNonNull(request, "A requisição da análise é obrigatória.");
        Objects.requireNonNull(tipoPessoa, "O tipo de pessoa é obrigatório.");
        Objects.requireNonNull(criarRequisicao, "A função de criação da requisição é obrigatória.");
    }
}
